﻿using AutoMapper;
using Projects.Entities.Membership;
using Projects.Entities.MasterData;
using Projects.Web.Models;
using Projects.Entities.Projects;

namespace Projects.Web.Mappings
{
    public class DomainToViewModelMappingProfile : Profile
    {
        public override string ProfileName
        {
            get { return "DomainToViewModelMappings"; }
        }

        protected override void Configure()
        {
            Mapper.CreateMap <tbl_tenant, TenantViewModel>();
            Mapper.CreateMap<tbl_user, UsersViewModel>();
            Mapper.CreateMap<tbl_roles, RolesViewModel>();
            Mapper.CreateMap<tbl_login_track, LoginTrackViewModel>();
            Mapper.CreateMap<tbl_menu, MenuViewModel>();
            Mapper.CreateMap<tbl_menu_access, MenuAccessViewModel>();
            Mapper.CreateMap<tbl_error, ErrorLogViewModel>();

            Mapper.CreateMap <tbl_reference_master, referencemasterViewModel>();
            Mapper.CreateMap <tbl_country, CountryViewModel>();
            Mapper.CreateMap <tbl_state, StatesViewModel>();
            Mapper.CreateMap<tbl_city, CityViewModel>();
            Mapper.CreateMap<tbl_chartsorder, ChartOrderViewModel>();
            Mapper.CreateMap<tbl_Log, LogViewModel>();
            Mapper.CreateMap<tbl_charts_titles, ChartTitleViewModel>();
            Mapper.CreateMap<tbl_charts_titles, ChartTitlesViewModel>();
            Mapper.CreateMap<tbl_users_profiles, UserProfileViewModel>();
            Mapper.CreateMap<tbl_employee, EmployeeViewModel>();

            Mapper.CreateMap<tbl_project_master, ProjectMasterViewModel>();
            Mapper.CreateMap<tbl_project_master_child, ProjectMasterChildViewModel>();
            Mapper.CreateMap<tbl_project_commercial_data, ProjectCommercialDataViewModel>();
            Mapper.CreateMap<tbl_project_structure, ProjectStructureViewModel>();
            Mapper.CreateMap<tbl_project_structure_main, ProjectStructureMainViewModel>();
            Mapper.CreateMap<tbl_project_technical_data, ProjectTechnicalDataViewModel>();
            Mapper.CreateMap<tbl_project_technical_data_child, ProjectTechnicalDataChildViewModel>();
            Mapper.CreateMap<tbl_part_list, PartListViewModel>();
            Mapper.CreateMap<tbl_part_list_item, PartListItemViewModel>();



            Mapper.CreateMap<tbl_Activity_Check, ActivityCheckViewModel>();
            Mapper.CreateMap<tbl_Activity_Child, ActivityChildViewModel>();
            Mapper.CreateMap<tbl_Activity_Master, ActivityMasterViewModel>();
            Mapper.CreateMap<tbl_Activity_Report, ActivityReportViewModel>();
            Mapper.CreateMap<tbl_APG_Master, APGMasterViewModel>();
            Mapper.CreateMap<tbl_Child_Activity, ChildActivityViewModel>();
            Mapper.CreateMap<tbl_Currency, CurrencyViewModel>();
            Mapper.CreateMap<tbl_Customer_Master, CustomerMasterViewModel>();
            Mapper.CreateMap<tbl_Item_RM_Codes, ItemRMCodesViewModel>();
            Mapper.CreateMap<tbl_Item_RM_Master, ItemRMMasterViewModel>();
            Mapper.CreateMap<tbl_Maker_Master, MakerMasterViewModel>();
            Mapper.CreateMap<tbl_Master_Activity, MasterActivityViewModel>();
            Mapper.CreateMap<tbl_Material_Grades, MaterialGradesViewModel>();
            Mapper.CreateMap<tbl_Resource_Master, ResourceMasterViewModel>();
            Mapper.CreateMap<tbl_SubAssembly_Master, SubAssemblyMasterViewModel>();
            Mapper.CreateMap<tbl_UOM_Master, UOMMasterViewModel>();
            Mapper.CreateMap<tbl_Variant_Master, VariantMasterViewModel>();
            Mapper.CreateMap<tbl_WorkCenter, WorkCenterViewModel>();
            Mapper.CreateMap<tbl_ProjectSector_Master, ProjectSectorViewModel>();
            Mapper.CreateMap<tbl_ProjectSector_Master, ProjectTechSpecsViewModel>();




            //var config = new MapperConfiguration(cfg => {
            //    cfg.CreateMap<UsersViewModel, tbl_user>();
            //    cfg.CreateMap<ClientsViewModel, tbl_clients_master>();
            //    cfg.CreateMap<ProjectsViewModel, tbl_projects_master>();
            //    cfg.CreateMap<ProjectModulesViewModel, tbl_project_modules>();
            //    cfg.CreateMap<tbl_qa_checklist_master,QACheckListQuestionsViewModel >();
            //});
        }
    }
}