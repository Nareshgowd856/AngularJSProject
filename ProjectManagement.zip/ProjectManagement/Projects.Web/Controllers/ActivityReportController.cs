﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
     [RoutePrefix("api/ActivityReport")]
    public class ActivityReportController: ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_Activity_Report> _activityReportRepository;

        public ActivityReportController(IEntityBaseRepository<tbl_Activity_Report> activityReportRepository,
            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _activityReportRepository = activityReportRepository;
        }


        [HttpGet]
        [Route("GetActivityReportList")]
        public HttpResponseMessage GetActivityReportList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var activityReportList = _activityReportRepository.GetAll();
                IEnumerable<ActivityReportViewModel> activityReportvm = Mapper.Map<IEnumerable<tbl_Activity_Report>, IEnumerable<ActivityReportViewModel>>(activityReportList);
                response = request.CreateResponse<IEnumerable<ActivityReportViewModel>>(HttpStatusCode.OK, activityReportvm);
                return response;
            });
        }

        [HttpPost]
        [Route("CreateActivityReport")]
        public HttpResponseMessage CreateActivityReport(HttpRequestMessage request, ActivityReportViewModel activityReport)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    tbl_Activity_Report newActivityReport = new tbl_Activity_Report();
                    newActivityReport.Activity_Code = activityReport.Activity_Code;
                    newActivityReport.Activity_Description = activityReport.Activity_Description;
                     newActivityReport.Activity_Part_No = activityReport.Activity_Part_No;
                    newActivityReport.Actual_Completiondate = activityReport.Actual_Completiondate;
                     newActivityReport.Actual_Duration = activityReport.Actual_Duration;
                    newActivityReport.Actual_StartDate = activityReport.Actual_StartDate;
                     newActivityReport.Main_Work_Center = activityReport.Main_Work_Center;
                    newActivityReport.Part_Sl_No = activityReport.Part_Sl_No;
                    newActivityReport.Person_Rep = activityReport.Person_Rep;
                     newActivityReport.Planned_CompletionDate = activityReport.Planned_CompletionDate;
                    newActivityReport.Planned_Duration = activityReport.Planned_Duration;
                     newActivityReport.Planned_StartDate = activityReport.Planned_StartDate;
                    newActivityReport.Project_Code = activityReport.Project_Code;
                     newActivityReport.Ref_Doc_No = activityReport.Ref_Doc_No;
                    newActivityReport.Remarks = activityReport.Remarks;
                     newActivityReport.Report_No = activityReport.Report_No;
                    newActivityReport.Resion = activityReport.Resion;
                     newActivityReport.Status = activityReport.Status;
                    newActivityReport.Work_Center = activityReport.Work_Center;
                    newActivityReport.tenant_id = activityReport.tenant_id;
                    newActivityReport.CompID = activityReport.CompID;
                    newActivityReport.Modified_On = null;
                    newActivityReport.Modified_By = null;
                    newActivityReport.Created_By = activityReport.Created_By;
                    newActivityReport.Created_On = DateTime.Now;
                    _activityReportRepository.Add(newActivityReport);
                    _unitOfWork.Commit();

                    response = request.CreateResponse<ActivityReportViewModel>(HttpStatusCode.Created, activityReport);
                }

                return response;
            });
        }

        [Route("UpdateActivityReport")]
        [HttpPost]
        public HttpResponseMessage UpdateActivityReport(HttpRequestMessage request, ActivityReportViewModel activityReport)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingActivityReport = _activityReportRepository.GetSingle(activityReport.id);
                    existingActivityReport.Activity_Code = activityReport.Activity_Code;
                    existingActivityReport.Activity_Description = activityReport.Activity_Description;
                    existingActivityReport.Activity_Part_No = activityReport.Activity_Part_No;
                    existingActivityReport.Actual_Completiondate = activityReport.Actual_Completiondate;
                    existingActivityReport.Actual_Duration = activityReport.Actual_Duration;
                    existingActivityReport.Actual_StartDate = activityReport.Actual_StartDate;
                    existingActivityReport.Main_Work_Center = activityReport.Main_Work_Center;
                    existingActivityReport.Part_Sl_No = activityReport.Part_Sl_No;
                    existingActivityReport.Person_Rep = activityReport.Person_Rep;
                    existingActivityReport.Planned_Duration = activityReport.Planned_Duration;
                    existingActivityReport.Planned_StartDate = activityReport.Planned_StartDate;
                    existingActivityReport.Project_Code = activityReport.Project_Code;
                    existingActivityReport.Ref_Doc_No = activityReport.Ref_Doc_No;
                    existingActivityReport.Remarks = activityReport.Remarks;
                    existingActivityReport.Report_No = activityReport.Report_No;
                    existingActivityReport.Resion = activityReport.Resion;
                    existingActivityReport.Status = activityReport.Status;
                    existingActivityReport.Work_Center = activityReport.Work_Center;
                    existingActivityReport.Modified_On = DateTime.Now;
                    _activityReportRepository.Edit(existingActivityReport);
                    _unitOfWork.Commit();
                    response = request.CreateResponse(HttpStatusCode.OK);

                }
                return response;
            });

        }
        [HttpPost]
        [Route("DeleteActivityReport/{id:int}")]
        public HttpResponseMessage DeleteActivityReport(HttpRequestMessage request, int id)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingActivityReport = _activityReportRepository.GetSingle(id);
                    if (existingActivityReport != null)
                    {
                        _activityReportRepository.Delete(existingActivityReport);
                        _unitOfWork.Commit();
                        response = request.CreateResponse(HttpStatusCode.OK);
                    }
                }
                return response;
            });
        }


    }
}