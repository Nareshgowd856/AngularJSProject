﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
    [RoutePrefix("api/ActivityMaster")]
    public class ActivityController : ApiControllerBase
    {
          public readonly IEntityBaseRepository<tbl_Activity_Master> _activityMasterRepository;

            public ActivityController(IEntityBaseRepository<tbl_Activity_Master> activityMasterRepository,
                IEntityBaseRepository<tbl_error> _errorsRepository,
                IUnitOfWork _unitOfWork)
                : base(_errorsRepository, _unitOfWork)
            {
                _activityMasterRepository = activityMasterRepository;
            }


            [HttpGet]
            [Route("GetActivityMasterList")]
            public HttpResponseMessage GetActivityMasterList(HttpRequestMessage request)
            {
                return CreateHttpResponse(request, () =>
                {
                    HttpResponseMessage response = null;
                    var activityMasterList = _activityMasterRepository.GetAll();
                    IEnumerable<ActivityMasterViewModel> activityMastervm = Mapper.Map<IEnumerable<tbl_Activity_Master>, IEnumerable<ActivityMasterViewModel>>(activityMasterList);
                    response = request.CreateResponse<IEnumerable<ActivityMasterViewModel>>(HttpStatusCode.OK, activityMastervm);
                    return response;
                });
            }

            [HttpPost]
            [Route("CreateActivity")]
            public HttpResponseMessage CreateActivity(HttpRequestMessage request, ActivityMasterViewModel activity)
            {
                return CreateHttpResponse(request, () =>
                {
                    HttpResponseMessage response = null;
                    if (!ModelState.IsValid)
                    {
                        response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                    }
                    else
                    {
                        tbl_Activity_Master newactivity = new tbl_Activity_Master();
                        
                        newactivity.Activity_Code = activity.Activity_Code ;
                       
                        newactivity.CompID = activity.CompID;
                        
                        _activityMasterRepository.Add(newactivity);
                        _unitOfWork.Commit();

                        response = request.CreateResponse<ActivityMasterViewModel>(HttpStatusCode.Created, activity);
                    }

                    return response;
                });
            }
        }
    }

