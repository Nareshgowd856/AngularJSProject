﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
    [RoutePrefix("api/Currency")]
    public class CurrencyController : ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_Currency> _currencyRepository;

        public CurrencyController(IEntityBaseRepository<tbl_Currency> currencyRepository,
            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _currencyRepository = currencyRepository;
        }


        [HttpGet]
        [Route("GetCurrencyList")]
        public HttpResponseMessage GetCurrencyList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var currencyList = _currencyRepository.GetAll();
                IEnumerable<CurrencyViewModel> currencyvm = Mapper.Map<IEnumerable<tbl_Currency>, IEnumerable<CurrencyViewModel>>(currencyList);
                response = request.CreateResponse<IEnumerable<CurrencyViewModel>>(HttpStatusCode.OK, currencyvm);
                return response;
            });
        }

        [HttpPost]
        [Route("CreateCurrency")]
        public HttpResponseMessage CreateCurrency(HttpRequestMessage request, CurrencyViewModel currency)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    tbl_Currency newCurrency = new tbl_Currency();
                    newCurrency.Currency_Id = currency.Currency_Id;
                    newCurrency.Currency_Name = currency.Currency_Name;
                    newCurrency.tenant_id = currency.tenant_id;
                    newCurrency.CompID = currency.CompID;
                    newCurrency.Modified_On = null;
                    newCurrency.Modified_By = null;
                    newCurrency.Created_By = currency.Created_By;
                    newCurrency.Created_On = DateTime.Now;
                    _currencyRepository.Add(newCurrency);
                    _unitOfWork.Commit();

                    response = request.CreateResponse<CurrencyViewModel>(HttpStatusCode.Created, currency);
                }

                return response;
            });
        }

        [Route("UpdateCurrency")]
        [HttpPost]
        public HttpResponseMessage UpdateCurrency(HttpRequestMessage request, CurrencyViewModel currency)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingCurrency = _currencyRepository.GetSingle(currency.id);
                    existingCurrency.Currency_Id = currency.Currency_Id;
                    existingCurrency.Currency_Name = currency.Currency_Name;
                    existingCurrency.Modified_On = DateTime.Now;
                    _currencyRepository.Edit(existingCurrency);
                    _unitOfWork.Commit();
                    response = request.CreateResponse(HttpStatusCode.OK);

                }
                return response;
            });

        }
        [HttpPost]
        [Route("DeleteCurrency/{id:int}")]
        public HttpResponseMessage DeleteCurrency(HttpRequestMessage request, int id)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingCurrency = _currencyRepository.GetSingle(id);
                    if (existingCurrency != null)
                    {
                        _currencyRepository.Delete(existingCurrency);
                        _unitOfWork.Commit();
                        response = request.CreateResponse(HttpStatusCode.OK);
                    }
                }
                return response;
            });
        }


    }

}