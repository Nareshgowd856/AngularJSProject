﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
     [RoutePrefix("api/APGMaster")]
    public class APGController: ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_APG_Master> _aPGMasterRepository;

        public APGController(IEntityBaseRepository<tbl_APG_Master> aPGMasterRepository,
            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _aPGMasterRepository = aPGMasterRepository;
        }


        [HttpGet]
        [Route("GetAPGMasterList")]
        public HttpResponseMessage GetAPGMasterList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var aPGMasterList = _aPGMasterRepository.GetAll();
                IEnumerable<APGMasterViewModel> aPGMastervm = Mapper.Map<IEnumerable<tbl_APG_Master>, IEnumerable<APGMasterViewModel>>(aPGMasterList);
                response = request.CreateResponse<IEnumerable<APGMasterViewModel>>(HttpStatusCode.OK, aPGMastervm);
                return response;
            });
        }

        [HttpPost]
        [Route("CreateAPG")]
        public HttpResponseMessage CreateAPG(HttpRequestMessage request, APGMasterViewModel aPGMaster)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    tbl_APG_Master newAPGMaster = new tbl_APG_Master();
                    newAPGMaster.APG_No = aPGMaster.APG_No;
                    newAPGMaster.APG_Description = aPGMaster.APG_Description;
                    newAPGMaster.APG_ApplicableTo = aPGMaster.APG_ApplicableTo;
                    newAPGMaster.tenant_id = aPGMaster.tenant_id;
                    newAPGMaster.CompID = aPGMaster.CompID;
                    newAPGMaster.Modified_On = null;
                    newAPGMaster.Modified_By = null;
                    newAPGMaster.Created_By = aPGMaster.Created_By;
                    newAPGMaster.Created_On = DateTime.Now;
                    _aPGMasterRepository.Add(newAPGMaster);
                    _unitOfWork.Commit();

                    response = request.CreateResponse<APGMasterViewModel>(HttpStatusCode.Created, aPGMaster);
                }

                return response;
            });
        }

        [Route("UpdateAPG")]
        [HttpPost]
        public HttpResponseMessage UpdateAPG(HttpRequestMessage request, APGMasterViewModel aPGMaster)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingMaker = _aPGMasterRepository.GetSingle(aPGMaster.id);
                    existingMaker.APG_No = aPGMaster.APG_No;
                    existingMaker.APG_Description = aPGMaster.APG_Description;
                    existingMaker.Modified_On = DateTime.Now;
                    _aPGMasterRepository.Edit(existingMaker);
                    _unitOfWork.Commit();
                    response = request.CreateResponse(HttpStatusCode.OK);

                }
                return response;
            });

        }
        [HttpPost]
        [Route("DeleteAPG/{id:int}")]
        public HttpResponseMessage DeleteAPG(HttpRequestMessage request, int id)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingApg = _aPGMasterRepository.GetSingle(id);
                    if (existingApg != null)
                    {
                        _aPGMasterRepository.Delete(existingApg);
                        _unitOfWork.Commit();
                        response = request.CreateResponse(HttpStatusCode.OK);
                    }
                }
                return response;
            });
        }



    }
}

   
