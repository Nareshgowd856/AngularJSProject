﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
    [RoutePrefix("api/UOMMaster")]
    public class UOMMasterController : ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_UOM_Master> _uomRepository;

        public UOMMasterController(IEntityBaseRepository<tbl_UOM_Master> uomRepository,
            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _uomRepository = uomRepository;
        }


        [HttpGet]
        [Route("GetUOMList")]
        public HttpResponseMessage GetUOMList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var uomList = _uomRepository.GetAll();
                IEnumerable<UOMMasterViewModel> uomMastervm = Mapper.Map<IEnumerable<tbl_UOM_Master>, IEnumerable<UOMMasterViewModel>>(uomList);
                response = request.CreateResponse<IEnumerable<UOMMasterViewModel>>(HttpStatusCode.OK, uomMastervm);
                return response;
            });
        }

        [HttpPost]
        [Route("CreateUOM")]
        public HttpResponseMessage CreateUOM(HttpRequestMessage request, UOMMasterViewModel uomMaster)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    tbl_UOM_Master newUOM = new tbl_UOM_Master();
                    newUOM.UOM_Id = uomMaster.UOM_Id;
                    newUOM.UOM_Name = uomMaster.UOM_Name;
                    newUOM.tenant_id = uomMaster.tenant_id;
                    newUOM.CompId = uomMaster.CompId;
                    newUOM.Modified_On = null;
                    newUOM.Modified_By = null;
                    newUOM.Created_By = uomMaster.Created_By;
                    newUOM.Created_On = DateTime.Now;
                    _uomRepository.Add(newUOM);
                    _unitOfWork.Commit();

                    response = request.CreateResponse<UOMMasterViewModel>(HttpStatusCode.Created, uomMaster);
                }

                return response;
            });
        }

        [Route("UpdateUOM")]
        [HttpPost]
        public HttpResponseMessage UpdateUOM(HttpRequestMessage request, UOMMasterViewModel uomMaster)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingUOM = _uomRepository.GetSingle(uomMaster.id);
                    existingUOM.UOM_Id = uomMaster.UOM_Id;
                    existingUOM.UOM_Name = uomMaster.UOM_Name;
                    existingUOM.Modified_On = DateTime.Now;
                    _uomRepository.Edit(existingUOM);
                    _unitOfWork.Commit();
                    response = request.CreateResponse(HttpStatusCode.OK);

                }
                return response;
            });

        }
        [HttpPost]
        [Route("DeleteUOM/{id:int}")]
        public HttpResponseMessage DeleteUOM(HttpRequestMessage request, int id)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingUOM = _uomRepository.GetSingle(id);
                    if (existingUOM != null)
                    {
                        _uomRepository.Delete(existingUOM);
                        _unitOfWork.Commit();
                        response = request.CreateResponse(HttpStatusCode.OK);
                    }
                }
                return response;
            });
        }


    }

}