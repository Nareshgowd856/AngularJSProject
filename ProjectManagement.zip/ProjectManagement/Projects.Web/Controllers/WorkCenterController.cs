﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
namespace Projects.Web.Controllers
{
    [RoutePrefix("api/WorkCenter")]
    public class WorkCenterController: ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_WorkCenter> _workCenterRepository;

        public WorkCenterController(IEntityBaseRepository<tbl_WorkCenter> workCenterRepository,
            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _workCenterRepository = workCenterRepository;
        }


        [HttpGet]
        [Route("GetWorkCenterList")]
        public HttpResponseMessage GetWorkCenterList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var workCenterList = _workCenterRepository.GetAll();
                IEnumerable<WorkCenterViewModel> workCenterVm = Mapper.Map<IEnumerable<tbl_WorkCenter>, IEnumerable<WorkCenterViewModel>>(workCenterList);
                response = request.CreateResponse<IEnumerable<WorkCenterViewModel>>(HttpStatusCode.OK, workCenterVm);
                return response;
            });
        }

        [HttpPost]
        [Route("CreateWorkCenter")]
        public HttpResponseMessage CreateWorkCenter(HttpRequestMessage request, WorkCenterViewModel workCenter)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    tbl_WorkCenter newWorkCenter = new tbl_WorkCenter();
                    newWorkCenter.Work_Center_id = workCenter.Work_Center_id;
                    newWorkCenter.Work_Center = workCenter.Work_Center;
                    newWorkCenter.tenant_id = workCenter.tenant_id;
                    newWorkCenter.CompID = workCenter.CompID;
                    newWorkCenter.Modified_On = null;
                    newWorkCenter.Modified_By = null;
                    newWorkCenter.Created_By = workCenter.Created_By;
                    newWorkCenter.Created_On = DateTime.Now;
                    _workCenterRepository.Add(newWorkCenter);
                    _unitOfWork.Commit();

                    response = request.CreateResponse<WorkCenterViewModel>(HttpStatusCode.Created, workCenter);
                }

                return response;
            });
        }

        [Route("UpdateWorkCenter")]
        [HttpPost]
        public HttpResponseMessage UpdateWorkCenter(HttpRequestMessage request, WorkCenterViewModel workCenter)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingWorkCenter = _workCenterRepository.GetSingle(workCenter.id);
                    existingWorkCenter.Work_Center = workCenter.Work_Center;
                    existingWorkCenter.Work_Center_id = workCenter.Work_Center_id;
                   
                    existingWorkCenter.Modified_On = DateTime.Now;
                    _workCenterRepository.Edit(existingWorkCenter);
                    _unitOfWork.Commit();
                    response = request.CreateResponse(HttpStatusCode.OK);

                }
                return response;
            });

        }
        [HttpPost]
        [Route("DeleteWorkCenter/{id:int}")]
        public HttpResponseMessage DeleteWorkCenter(HttpRequestMessage request, int id)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingWorkCenter = _workCenterRepository.GetSingle(id);
                    if (existingWorkCenter != null)
                    {
                        _workCenterRepository.Delete(existingWorkCenter);
                        _unitOfWork.Commit();
                        response = request.CreateResponse(HttpStatusCode.OK);
                    }
                }
                return response;
            });
        }

    }   
}