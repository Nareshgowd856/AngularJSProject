﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
     [RoutePrefix("api/Variant")]
    public class VariantController: ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_Variant_Master> _variantMasterRepository;

        public VariantController(IEntityBaseRepository<tbl_Variant_Master> variantMasterRepository,
            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _variantMasterRepository = variantMasterRepository;
        }


        [HttpGet]
        [Route("GetVariantMasterList")]
        public HttpResponseMessage GetVariantMasterList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var variantMasterList = _variantMasterRepository.GetAll();
                IEnumerable<VariantMasterViewModel> variantMasterVm = Mapper.Map<IEnumerable<tbl_Variant_Master>, IEnumerable<VariantMasterViewModel>>(variantMasterList);
                response = request.CreateResponse<IEnumerable<VariantMasterViewModel>>(HttpStatusCode.OK, variantMasterVm);
                return response;
            });
        }

        [HttpPost]
        [Route("CreateVariant")]
        public HttpResponseMessage CreateVariant(HttpRequestMessage request, VariantMasterViewModel variant)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    tbl_Variant_Master newvariantMaster = new tbl_Variant_Master();
                    newvariantMaster.Variant_ID = variant.Variant_ID;
                    newvariantMaster.Variant_Name = variant.Variant_Name;
                    newvariantMaster.Sub_Assembly_Name = variant.Sub_Assembly_Name;
                    newvariantMaster.tenant_id = variant.tenant_id;
                    newvariantMaster.CompID = variant.CompID;
                    newvariantMaster.Modified_On = null;
                    newvariantMaster.Modified_By = null;
                    newvariantMaster.Created_By = variant.Created_By;
                    newvariantMaster.Created_On = DateTime.Now;
                    _variantMasterRepository.Add(newvariantMaster);
                    _unitOfWork.Commit();

                    response = request.CreateResponse<VariantMasterViewModel>(HttpStatusCode.Created, variant);
                }

                return response;
            });
        }



    }   
}