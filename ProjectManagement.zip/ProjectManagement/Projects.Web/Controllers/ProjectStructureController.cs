﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
    public class projectStructureFormModel
    {
        public int id { get; set; }
        public int tenant_id { get; set; }
        public string CompID { get; set; }
        public string Project_Code { get; set; }
        public string Maker_No { get; set; }
        public string Maker_Name { get; set; }
        public List<string> APGIDsList { get; set; }

    }
    [RoutePrefix("api/ProjectStructure")]
    public class ProjectStructureController : ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_project_structure_main> _projectStructureMainRepository;
        public readonly IEntityBaseRepository<tbl_APG_Master> _apgMasterRepository;


        public ProjectStructureController(IEntityBaseRepository<tbl_project_structure_main> projectStructureMainRepository,
                   IEntityBaseRepository<tbl_APG_Master> apgMasterRepository,
            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _projectStructureMainRepository = projectStructureMainRepository;
            _apgMasterRepository = apgMasterRepository;
        }


        [HttpGet]
        [Route("GetProjectStructureMainList")]
        public HttpResponseMessage GetProjectStructureMainList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var projectStructureMainList = _projectStructureMainRepository.GetAll().Distinct();
                IEnumerable<ProjectStructureMainViewModel> projectStructureMainVm = Mapper.Map<IEnumerable<tbl_project_structure_main>, IEnumerable<ProjectStructureMainViewModel>>(projectStructureMainList);
                response = request.CreateResponse<IEnumerable<ProjectStructureMainViewModel>>(HttpStatusCode.OK, projectStructureMainVm);
                return response;
            });
        }

        [HttpGet]
        [Route("GetAPGMasterList")]
        public HttpResponseMessage GetAPGMasterList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var apgMasterList = _apgMasterRepository.GetAll().Distinct();
                IEnumerable<APGMasterViewModel> apgMasterVm = Mapper.Map<IEnumerable<tbl_APG_Master>, IEnumerable<APGMasterViewModel>>(apgMasterList);
                response = request.CreateResponse<IEnumerable<APGMasterViewModel>>(HttpStatusCode.OK, apgMasterVm);
                return response;
            });
        }

        [HttpPost]
        [Route("CreateProjectStructrure")]
        public HttpResponseMessage CreateProjectStructrure(HttpRequestMessage request, projectStructureFormModel projectStructure)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    tbl_project_structure_main newProjectStructure = new tbl_project_structure_main();
                    newProjectStructure.Project_Code = projectStructure.Project_Code;
                    newProjectStructure.Maker_No = projectStructure.Maker_No;
                    newProjectStructure.Maker_Name = projectStructure.Maker_Name;
                    newProjectStructure.Full_Project_Code = null;
                    newProjectStructure.tenant_id = projectStructure.tenant_id;
                    newProjectStructure.CompID = "0001";
                    newProjectStructure.Created_By = projectStructure.tenant_id.ToString();
                    newProjectStructure.Created_On = DateTime.Now;
                    newProjectStructure.Modified_By = null;
                    newProjectStructure.Modified_On = null;
                    _projectStructureMainRepository.Add(newProjectStructure);

                    foreach (var item in projectStructure.APGIDsList)
                    {
                        int apgId = Convert.ToInt32(item);
                        var apgMasterData = _apgMasterRepository.GetAll().Where(x => x.id == apgId).FirstOrDefault();
                        if (apgMasterData.id != 0)
                        {
                            tbl_project_structure_main newProjectStructureChild = new tbl_project_structure_main();
                            newProjectStructureChild.tenant_id = projectStructure.tenant_id;
                            newProjectStructureChild.Project_Code = projectStructure.Project_Code;
                            newProjectStructureChild.APG_Name = apgMasterData.APG_Description;
                            newProjectStructureChild.CompID = "0001";
                            newProjectStructureChild.Apg_No = apgMasterData.APG_No;
                            newProjectStructureChild.Full_Project_Code = null;
                            newProjectStructureChild.Created_By = projectStructure.tenant_id.ToString();
                            newProjectStructureChild.Created_On = DateTime.Now;
                            newProjectStructureChild.Modified_By = null;
                            newProjectStructureChild.Modified_On = null;
                            _projectStructureMainRepository.Add(newProjectStructure);
                        }
                    }
                

                        _unitOfWork.Commit();

                        response = request.CreateResponse<projectStructureFormModel>(HttpStatusCode.Created, projectStructure);
                    }
                    return response;
                
            });

        }
    }
}


//[HttpPost]
//[Route("CreatePro")]
//public HttpResponseMessage CreateMakers(HttpRequestMessage request, MakerMasterViewModel maker)
//{
//    return CreateHttpResponse(request, () =>
//    {
//        HttpResponseMessage response = null;
//        if (!ModelState.IsValid)
//        {
//            response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
//        }
//        else
//        {
//            tbl_Maker_Master newMakerMaster = new tbl_Maker_Master();
//            newMakerMaster.Maker_No = maker.Maker_No;
//            newMakerMaster.Maker_Description = maker.Maker_Description;
//            newMakerMaster.tenant_id = maker.tenant_id;
//            newMakerMaster.CompID = maker.CompID;
//            newMakerMaster.Modified_On = null;
//            newMakerMaster.Modified_By = null;
//            newMakerMaster.Created_By = maker.Created_By;
//            newMakerMaster.Created_On = DateTime.Now;
//            _makerMasterRepository.Add(newMakerMaster);
//            _unitOfWork.Commit();

//            response = request.CreateResponse<MakerMasterViewModel>(HttpStatusCode.Created, maker);
//        }

//        return response;
//    });
//}





