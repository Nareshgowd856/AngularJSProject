﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
    [RoutePrefix("api/ItemMaster")]
   
        public  class ItemMasterController : ApiControllerBase
        {
            public readonly IEntityBaseRepository<tbl_Item_RM_Master> _itemMasterRepository;
        public readonly IEntityBaseRepository<tbl_Item_RM_Codes> _itemRMCodesRepository;
        public readonly IEntityBaseRepository<tbl_UOM_Master> _uomRepository;
        public readonly IEntityBaseRepository<tbl_Material_Grades> _materialGradesRepository;
        public readonly IEntityBaseRepository<tbl_Group_Master> _groupMasterRepository;


        public ItemMasterController(IEntityBaseRepository<tbl_Item_RM_Master>  itemMasterRepository,
                IEntityBaseRepository<tbl_error> _errorsRepository,
                IEntityBaseRepository<tbl_Item_RM_Codes> itemRMCodesRepository,
                    IEntityBaseRepository<tbl_UOM_Master> uomRepository,
                       IEntityBaseRepository<tbl_Material_Grades> materialGradesRepository,
                             IEntityBaseRepository<tbl_Group_Master> groupMasterRepository,
                IUnitOfWork _unitOfWork)
                : base(_errorsRepository, _unitOfWork)
        {
            _itemMasterRepository = itemMasterRepository;
            _itemRMCodesRepository = itemRMCodesRepository;
            _uomRepository = uomRepository;
            _materialGradesRepository = materialGradesRepository;
            _groupMasterRepository = groupMasterRepository;
        }
        [HttpPost]
        [Route("CreateItemChild")]
        public HttpResponseMessage CreateItemChild(HttpRequestMessage request, ItemRMCodesViewModel rmCodes)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    tbl_Item_RM_Codes newRMcodes = new tbl_Item_RM_Codes();
                    newRMcodes.Item_Spec = rmCodes.Item_Spec;
                    newRMcodes.Item_Dia = rmCodes.Item_Dia;
                    newRMcodes.Item_UWt = rmCodes.Item_UWt;
                    newRMcodes.tenant_id = rmCodes.tenant_id;
                    newRMcodes.Item_WT = rmCodes.Item_WT;
                    newRMcodes.Item_LongText = rmCodes.Item_LongText;
                    newRMcodes.Item_Code = rmCodes.Item_Code;
                    newRMcodes.Item_SchNo = rmCodes.Item_SchNo;
                    newRMcodes.Item_Description = rmCodes.Item_Description; 
                    newRMcodes.CompID = "0001";
                    newRMcodes.Created_By = rmCodes.tenant_id.ToString();
                    newRMcodes.Created_On = DateTime.Now;
                    newRMcodes.Modified_By = null;
                    newRMcodes.Modified_On = null;
                    _itemRMCodesRepository.Add(newRMcodes); 

                    _unitOfWork.Commit();

                    response = request.CreateResponse<ItemRMCodesViewModel>(HttpStatusCode.Created, rmCodes);
                }

                return response;
            });
        }

        [HttpGet]
        [Route("GetUomList")]
        public HttpResponseMessage GetUomList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var currencyList = _uomRepository.GetAll().Where(x => x.CompId == "0001");
                IEnumerable<UOMMasterViewModel> currencyvm = Mapper.Map<IEnumerable<tbl_UOM_Master>, IEnumerable<UOMMasterViewModel>>(currencyList);
                response = request.CreateResponse<IEnumerable<UOMMasterViewModel>>(HttpStatusCode.OK, currencyvm);
                return response;
            });
        }


        [HttpGet]
        [Route("GetSpecificationList")]
        public HttpResponseMessage GetSpecificationList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var specificationList = _materialGradesRepository.GetAll().Where(x=>x.CompID=="0001");
                IEnumerable<MaterialGradesViewModel> currencyvm = Mapper.Map<IEnumerable<tbl_Material_Grades>, IEnumerable<MaterialGradesViewModel>>(specificationList);
                response = request.CreateResponse<IEnumerable<MaterialGradesViewModel>>(HttpStatusCode.OK, currencyvm);
                return response;
            });
        }

        [HttpGet]
        [Route("GetGroupMasterList")]
        public HttpResponseMessage GetGroupMasterList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var groupMasterList = _groupMasterRepository.GetAll().Where(x => x.CompID == "0001");
                IEnumerable<GroupMasterViewModel> currencyvm = Mapper.Map<IEnumerable<tbl_Group_Master>, IEnumerable<GroupMasterViewModel>>(groupMasterList);
                response = request.CreateResponse<IEnumerable<GroupMasterViewModel>>(HttpStatusCode.OK, currencyvm);
                return response;
            });
        }


        //[Route("GetMyUsers/{tenantid:int}")]
        //public IHttpActionResult GetMyUsers(HttpRequestMessage request, int tenantid)
        //{
        //    if (tenantid == 1)
        //    {
        //        var myUsers = from u in _userRepository.GetAll().AsQueryable()
        //                      join ur in _userrolesRepository.GetAll().AsQueryable() on u.id equals ur.id into p
        //                      from ur in p.DefaultIfEmpty()
        //                      join r in _rolesRepository.GetAll().AsQueryable() on ur.RoleId equals r.id into pr
        //                      from r in pr.DefaultIfEmpty()
        //                      where (u.tenant_id == 1 && u.is_tenant == false)
        //                      select new
        //                      {
        //                          id = u.id,
        //                          tenant_id = u.tenant_id,
        //                          userid = u.userid,
        //                          user_name = u.user_name,
        //                          email = u.email,
        //                          roleid = r.id,
        //                          role = r.Name,
        //                          IsLocked = u.is_locked,
        //                          IsTenant = u.is_tenant,
        //                          DateCreated = u.date_created,
        //                          DateModified = u.date_modified
        //                      };
        //        return Ok(myUsers);
        //    }
        //    else
        //    {
        //        var myUsers = from u in _userRepository.GetAll().AsQueryable()
        //                      join ur in _userrolesRepository.GetAll().AsQueryable() on u.id equals ur.id into p
        //                      from ur in p.DefaultIfEmpty()
        //                      join r in _rolesRepository.GetAll().AsQueryable() on ur.RoleId equals r.id into pr
        //                      from r in pr.DefaultIfEmpty()
        //                      where (u.tenant_id == tenantid && u.is_tenant == false)
        //                      select new
        //                      {
        //                          id = u.id,
        //                          tenant_id = u.tenant_id,
        //                          userid = u.userid,
        //                          user_name = u.user_name,
        //                          email = u.email,
        //                          roleid = r.id,
        //                          role = r.Name,
        //                          IsLocked = u.is_locked,
        //                          IsTenant = u.is_tenant,
        //                          DateCreated = u.date_created,
        //                          DateModified = u.date_modified
        //                      };
        //        return Ok(myUsers);
        //    }
        //}

        //[HttpGet]
        //[Route("GetBindDiaDataList")]
        //public HttpResponseMessage GetBindDiaDataList(HttpRequestMessage request)
        //{
        //    return CreateHttpResponse(request, () =>
        //    {
        //        HttpResponseMessage response = null;
        //        var groupMasterList = _groupMasterRepository.GetAll().Where(x => x.CompID == "0001");
        //        IEnumerable<GroupMasterViewModel> currencyvm = Mapper.Map<IEnumerable<tbl_Group_Master>, IEnumerable<GroupMasterViewModel>>(groupMasterList);
        //        response = request.CreateResponse<IEnumerable<GroupMasterViewModel>>(HttpStatusCode.OK, currencyvm);
        //        return response;
        //    });
        //}



        [HttpPost]
        [Route("getGroup")]
        public HttpResponseMessage getGroup(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                
                var groupMasterList = _groupMasterRepository.GetAll().Where(x => x.CompID == "0001");
                IEnumerable<GroupMasterViewModel> currencyvm = Mapper.Map<IEnumerable<tbl_Group_Master>, IEnumerable<GroupMasterViewModel>>(groupMasterList);
                response = request.CreateResponse<IEnumerable<GroupMasterViewModel>>(HttpStatusCode.OK, currencyvm);
                return response;
            });
        }

        //[HttpGet]
        //[Route("getSpecData")]
        //public HttpResponseMessage getSpecData(string Item_Group)
        //{
        //    return CreateHttpResponse(Item_Group, () =>
        //    {
        //        HttpResponseMessage response = null;
        //        HttpResponseMessage request = null;
        //        var groupMasterList = _groupMasterRepository.GetAll().Where(x => x.CompID == "0001").Where(x => x.Group_Name == Item_Group);
        //        IEnumerable<GroupMasterViewModel> currencyvm = Mapper.Map<IEnumerable<tbl_Group_Master>, IEnumerable<GroupMasterViewModel>>(groupMasterList);
        //        response = request.CreateResponse<IEnumerable<GroupMasterViewModel>>(HttpStatusCode.OK, currencyvm);
        //        return response;
        //    });
        //}


    }
}



   