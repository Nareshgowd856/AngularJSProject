﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
    [RoutePrefix("api/ItemMaster")]
   
        public  class ItemMasterController : ApiControllerBase
        {
            public readonly IEntityBaseRepository<tbl_Item_RM_Master> _itemMasterRepository;

            public ItemMasterController(IEntityBaseRepository<tbl_Item_RM_Master>  itemMasterRepository,
                IEntityBaseRepository<tbl_error> _errorsRepository,
                IUnitOfWork _unitOfWork)
                : base(_errorsRepository, _unitOfWork)
            {
                _itemMasterRepository = itemMasterRepository;
            }
        }
}



   