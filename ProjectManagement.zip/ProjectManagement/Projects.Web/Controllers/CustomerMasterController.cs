﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
    [RoutePrefix("api/CustomerMaster")]
    public class CustomerMasterController : ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_Customer_Master> _customerMasterRepository;

        public CustomerMasterController(IEntityBaseRepository<tbl_Customer_Master> customerMasterRepository,
            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _customerMasterRepository = customerMasterRepository;
        }


        [HttpGet]
        [Route("GetCustomerMasterList")]
        public HttpResponseMessage GetCustomerMasterList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var customerMasterList = _customerMasterRepository.GetAll();
                IEnumerable<CustomerMasterViewModel> customerMastervm = Mapper.Map<IEnumerable<tbl_Customer_Master>, IEnumerable<CustomerMasterViewModel>>(customerMasterList);
                response = request.CreateResponse<IEnumerable<CustomerMasterViewModel>>(HttpStatusCode.OK, customerMastervm);
                return response;
            });
        }

        [HttpPost]
        [Route("CreateCustomers")]
        public HttpResponseMessage CreateCustomers(HttpRequestMessage request, CustomerMasterViewModel customer)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    tbl_Customer_Master newCustomerMaster = new tbl_Customer_Master();
                    newCustomerMaster.Customer_Id = customer.Customer_Id;
                    newCustomerMaster.Customer_Name = customer.Customer_Name;
                    newCustomerMaster.tenant_id = customer.tenant_id;
                    newCustomerMaster.CompID = customer.CompID;
                    newCustomerMaster.Modified_On = null;
                    newCustomerMaster.Modified_By = null;
                    newCustomerMaster.Created_By = customer.Created_By;
                    newCustomerMaster.Created_On = DateTime.Now;
                    _customerMasterRepository.Add(newCustomerMaster);
                    _unitOfWork.Commit();

                    response = request.CreateResponse<CustomerMasterViewModel>(HttpStatusCode.Created, customer);
                }

                return response;
            });
        }

        [Route("UpdateCustomer")]
        [HttpPost]
        public HttpResponseMessage UpdateCustomer(HttpRequestMessage request, CustomerMasterViewModel customer)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingCustomer = _customerMasterRepository.GetSingle(customer.id);
                    existingCustomer.Customer_Id = customer.Customer_Id;
                    existingCustomer.Customer_Name = customer.Customer_Name;
                    existingCustomer.Modified_On = DateTime.Now;
                    _customerMasterRepository.Edit(existingCustomer);
                    _unitOfWork.Commit();
                    response = request.CreateResponse(HttpStatusCode.OK);

                }
                return response;
            });

        }
        [HttpPost]
        [Route("DeleteCustomer/{id:int}")]
        public HttpResponseMessage DeleteCustomer(HttpRequestMessage request, int id)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingCustomer = _customerMasterRepository.GetSingle(id);
                    if (existingCustomer != null)
                    {
                        _customerMasterRepository.Delete(existingCustomer);
                        _unitOfWork.Commit();
                        response = request.CreateResponse(HttpStatusCode.OK);
                    }
                }
                return response;
            });
        }



    }
}