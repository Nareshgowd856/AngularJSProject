﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
namespace Projects.Web.Controllers
{
    [RoutePrefix("api/PTS")]
    public class ProjectTechSpecsController : ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_Project_Tech_Specs> _ptsRepository;

        public ProjectTechSpecsController(IEntityBaseRepository<tbl_Project_Tech_Specs> ptsRepository,
            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _ptsRepository = ptsRepository;
        }


        [HttpGet]
        [Route("GetPTSList")]
        public HttpResponseMessage GetPTSList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var ptsList = _ptsRepository.GetAll();
                IEnumerable<ProjectTechSpecsViewModel> ptsvm = Mapper.Map<IEnumerable<tbl_Project_Tech_Specs>, IEnumerable<ProjectTechSpecsViewModel>>(ptsList);
                response = request.CreateResponse<IEnumerable<ProjectTechSpecsViewModel>>(HttpStatusCode.OK, ptsvm);
                return response;
            });
        }

        [HttpPost]
        [Route("CreatePTS")]
        public HttpResponseMessage CreatePTS(HttpRequestMessage request, ProjectTechSpecsViewModel pts)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    tbl_Project_Tech_Specs newPts = new tbl_Project_Tech_Specs();
                    newPts.ProjectTechSpecs_Id = pts.ProjectTechSpecs_Id;
                    newPts.ProjectTechSpecs_Name = pts.ProjectTechSpecs_Name;
                    newPts.tenant_id = pts.tenant_id;
                    newPts.CompID = pts.CompID;
                    newPts.Modified_On = null;
                    newPts.Modified_By = null;
                    newPts.Created_By = pts.Created_By;
                    newPts.Created_On = DateTime.Now;
                    _ptsRepository.Add(newPts);
                    _unitOfWork.Commit();

                    response = request.CreateResponse<ProjectTechSpecsViewModel>(HttpStatusCode.Created, pts);
                }

                return response;
            });
        }

        [Route("UpdatePTS")]
        [HttpPost]
        public HttpResponseMessage UpdatePTS(HttpRequestMessage request, ProjectTechSpecsViewModel pts)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingPts = _ptsRepository.GetSingle(pts.id);
                    existingPts.ProjectTechSpecs_Id = pts.ProjectTechSpecs_Id;
                    existingPts.ProjectTechSpecs_Name = pts.ProjectTechSpecs_Name;
                    existingPts.Modified_On = DateTime.Now;
                    _ptsRepository.Edit(existingPts);
                    _unitOfWork.Commit();
                    response = request.CreateResponse(HttpStatusCode.OK);

                }
                return response;
            });

        }
        [HttpPost]
        [Route("DeletePTS/{id:int}")]
        public HttpResponseMessage DeletePTS(HttpRequestMessage request, int id)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingPts = _ptsRepository.GetSingle(id);
                    if (existingPts != null)
                    {
                        _ptsRepository.Delete(existingPts);
                        _unitOfWork.Commit();
                        response = request.CreateResponse(HttpStatusCode.OK);
                    }
                }
                return response;
            });
        }


    }

}