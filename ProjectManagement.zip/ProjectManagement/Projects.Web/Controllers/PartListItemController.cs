﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
    public class partListItemFormModel
    {
        public int id { get; set; }
        public int tenant_id { get; set; }
        public string CompID { get; set; }
        public string Project_Code { get; set; }
        public string Maker_No { get; set; }
        public string Apg_No { get; set; }
        public string Part_Equipment_Name { get; set; }
        public DateTime Version_Change { get; set; }
        public string Partlist_No { get; set; }
        public string Status { get; set; }
        public string Version_No { get; set; }
        public bool IBR { get; set; }
        public bool EN { get; set; }
        public bool MTC { get; set; }
        public string Drawing_NO { get; set; }
        public string Part_Sl_No { get; set; }
        public string Part_Name { get; set; }
        public string Part_Rm_Type { get; set; }
        public string Part_Group { get; set; }
        public string ProjectTechSpecs_Id { get; set; }
        //public string Main Assembly { get; set; }
        public string Main_Drwaing_No { get; set; }
        public string Qty { get; set; }
        public string Part_UOM { get; set; }
        public string Part_Spec_Id { get; set; }
        public string Part_Rm_WThick { get; set; }
        public string Part_Rm_Density { get; set; }
        public string Part_RM_Code { get; set; }
        // public string Part_Rm_Type { get; set; }
        public string Part_Spl_Notes { get; set; }
        public string Part_Desription { get; set; }
        public string Material_Shape_Finished { get; set; }
        public string Part_Dia { get; set; }
        public string Part_W2 { get; set; }
        public string OD { get; set; }
       // public string Part_Rm_WThick { get; set; }
        public string Part_Length { get; set; }
        public string Part_Fg_wt { get; set; }
        public string Part_Dai_Finished { get; set; }
        public string Part_W2_Finished { get; set; }
        public string Part_OD_Finished { get; set; }
        public string Part_WThick_Finished { get; set; }
        public string Part_Length_Finished { get; set; }
        public string Part_D_Wt { get; set; }


    }
    [RoutePrefix("api/PartListItem")]
    public class PartListItemController : ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_part_list_item> _partListItemRepository;
        public readonly IEntityBaseRepository<tbl_Item_RM_Codes> _itemRMCodesRepository;
        public readonly IEntityBaseRepository<tbl_Item_RM_Master> _itemRMMasterRepository;
        public readonly IEntityBaseRepository<tbl_part_list> _partListRepository;
        public readonly IEntityBaseRepository<tbl_Material_Grades> _materialGradesRepository;
        public readonly IEntityBaseRepository<tbl_SubAssembly_Master> _subAssemblyRepository;

        public PartListItemController(IEntityBaseRepository<tbl_part_list_item> partListItemRepository,
             IEntityBaseRepository<tbl_Item_RM_Codes> itemRMCodesRepository,
             IEntityBaseRepository<tbl_Item_RM_Master> itemRMMasterRepository,
             IEntityBaseRepository<tbl_part_list> partListRepository,
             IEntityBaseRepository<tbl_Material_Grades> materialGradesRepository,
             IEntityBaseRepository<tbl_SubAssembly_Master> subAssemblyRepository,

            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _partListItemRepository = partListItemRepository;
            _itemRMCodesRepository = itemRMCodesRepository;
            _itemRMMasterRepository = itemRMMasterRepository;
            _partListRepository = partListRepository;
            _materialGradesRepository = materialGradesRepository;
            _subAssemblyRepository = subAssemblyRepository;
        }


        [HttpGet]
        [Route("GetPartListItemList")]
        public HttpResponseMessage GetPartListItemList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var partListItemList = _partListItemRepository.GetAll();
                IEnumerable<PartListItemViewModel> PartListItemvm = Mapper.Map<IEnumerable<tbl_part_list_item>, IEnumerable<PartListItemViewModel>>(partListItemList);
                response = request.CreateResponse<IEnumerable<PartListItemViewModel>>(HttpStatusCode.OK, PartListItemvm);
                return response;
            });

        }
        [HttpGet]
        [Route("GetMaterialGradesList")]
        public HttpResponseMessage GetMaterialGradesList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var materialGradeList = _materialGradesRepository.GetAll();
                IEnumerable<MaterialGradesViewModel> materialGradesVm = Mapper.Map<IEnumerable<tbl_Material_Grades>, IEnumerable<MaterialGradesViewModel>>(materialGradeList);
                response = request.CreateResponse<IEnumerable<MaterialGradesViewModel>>(HttpStatusCode.OK, materialGradesVm);
                return response;
            });
        }
        [Route("GetSubAssemblyList")]
        public HttpResponseMessage GetSubAssemblyList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var subAssemblyList = _subAssemblyRepository.GetAll();
                IEnumerable<SubAssemblyMasterViewModel> subAssemblyVm = Mapper.Map<IEnumerable<tbl_SubAssembly_Master>, IEnumerable<SubAssemblyMasterViewModel>>(subAssemblyList);
                response = request.CreateResponse<IEnumerable<SubAssemblyMasterViewModel>>(HttpStatusCode.OK, subAssemblyVm);
                return response;
            });
        }

        [HttpPost]
        [Route("CreatePartListItem")]
        public HttpResponseMessage CreatePartListItem(HttpRequestMessage request, PartListItemViewModel partListItem)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    tbl_part_list_item newPartListItemForm = new tbl_part_list_item();
                    newPartListItemForm.tenant_id = partListItem.tenant_id;
                    newPartListItemForm.Project_Code = partListItem.Project_Code;
                    newPartListItemForm.Activity_Part_No = partListItem.Activity_Part_No;
                    newPartListItemForm.Apg_Name = partListItem.Apg_Name;
                    newPartListItemForm.Maker_No = partListItem.Maker_No;
                    newPartListItemForm.Apg_No = partListItem.Apg_No;
                    newPartListItemForm.Drawing_NO = partListItem.Drawing_NO;
                    newPartListItemForm.CompId = partListItem.CompId;
                    newPartListItemForm.Main_Drwaing_No = partListItem.Main_Drwaing_No;
                    newPartListItemForm.Material_Shape_Finished = partListItem.Material_Shape_Finished;
                    newPartListItemForm.Material_Shape_RM = partListItem.Material_Shape_RM;
                    newPartListItemForm.OD = partListItem.OD;
                    newPartListItemForm.Partlist_No = partListItem.Partlist_No;
                    newPartListItemForm.Part_Dai_Finished = partListItem.Part_Dai_Finished;
                    newPartListItemForm.Part_Desription = partListItem.Part_Desription;
                    newPartListItemForm.Part_Dia = partListItem.Part_Dia;
                    newPartListItemForm.Part_D_Wt = partListItem.Part_D_Wt;
                    newPartListItemForm.Part_Engg_Code = partListItem.Part_Engg_Code;
                    newPartListItemForm.Part_EN_Cert = partListItem.Part_EN_Cert;
                    newPartListItemForm.Part_Equipment_Name = partListItem.Part_Equipment_Name;
                    newPartListItemForm.Part_Fg_wt = partListItem.Part_Fg_wt;
                    newPartListItemForm.Part_Group = partListItem.Part_Group;
                    newPartListItemForm.Part_IBR_Cert = partListItem.Part_IBR_Cert;
                    newPartListItemForm.Part_Length = partListItem.Part_Length;
                    newPartListItemForm.Part_Length_Finished = partListItem.Part_Length_Finished;
                    newPartListItemForm.Part_Mtc_Cert = partListItem.Part_Mtc_Cert;
                    newPartListItemForm.Part_Name = partListItem.Part_Name;
                    newPartListItemForm.Part_OD_Finished = partListItem.Part_OD_Finished;
                    newPartListItemForm.Part_RM_Code = partListItem.Part_RM_Code;
                    newPartListItemForm.Part_Rm_Density = partListItem.Part_Rm_Density;
                    newPartListItemForm.Part_Rm_Type = partListItem.Part_Rm_Type;
                    newPartListItemForm.Part_Rm_Wt = partListItem.Part_Rm_Wt;
                    newPartListItemForm.Part_Rm_WThick = partListItem.Part_Rm_WThick;
                    newPartListItemForm.Part_Sl_No = partListItem.Part_Sl_No;
                    newPartListItemForm.Part_Spec_Id = partListItem.Part_Spec_Id;
                    newPartListItemForm.Part_Spl_Notes = partListItem.Part_Spl_Notes;
                    newPartListItemForm.Part_UOM = partListItem.Part_UOM;
                    newPartListItemForm.Part_variant = partListItem.Part_variant;
                    newPartListItemForm.Part_W2 = partListItem.Part_W2;
                    newPartListItemForm.Part_W2_Finished = partListItem.Part_W2_Finished;
                    newPartListItemForm.Part_Wt = partListItem.Part_Wt;
                    newPartListItemForm.Part_WThick_Finished = partListItem.Part_WThick_Finished;
                    newPartListItemForm.PTS_NO = partListItem.PTS_NO;
                    newPartListItemForm.Qty = partListItem.Qty;
                    newPartListItemForm.Status = partListItem.Status;
                    newPartListItemForm.Version_Change = partListItem.Version_Change;
                    newPartListItemForm.Version_Date = partListItem.Version_Date;
                    newPartListItemForm.Version_No = partListItem.Version_No;
                    newPartListItemForm.Modified_On = null;
                    newPartListItemForm.Modified_By = null;
                    newPartListItemForm.Created_By = partListItem.Created_By;
                    newPartListItemForm.Created_On = DateTime.Now;
                    _partListItemRepository.Add(newPartListItemForm);
                    _unitOfWork.Commit();

                    response = request.CreateResponse<PartListItemViewModel>(HttpStatusCode.Created, partListItem);
                }

                return response;
            });
        }
        [HttpPost]
        [Route("DeletePartListItem/{id:int}")]
        public HttpResponseMessage DeletePartListItem(HttpRequestMessage request, int id)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingProject = _partListItemRepository.GetSingle(id);
                    if (existingProject != null)
                    {
                        _partListItemRepository.Delete(existingProject);
                        _unitOfWork.Commit();
                        response = request.CreateResponse(HttpStatusCode.OK);
                    }
                }
                return response;
            });
        }


    }
}