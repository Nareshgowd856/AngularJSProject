﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
    [RoutePrefix("api/MaterialGrade")]
    public class MaterialGradeController : ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_Material_Grades> _materialGradesRepository;

        public MaterialGradeController(IEntityBaseRepository<tbl_Material_Grades> materialGradesRepository,
            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _materialGradesRepository = materialGradesRepository;
        }


        [HttpGet]
        [Route("GetMaterialGradeList")]
        public HttpResponseMessage GetMaterialGradeList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var materialGradeList = _materialGradesRepository.GetAll();
                IEnumerable<MaterialGradesViewModel> materialGradesVm = Mapper.Map<IEnumerable<tbl_Material_Grades>, IEnumerable<MaterialGradesViewModel>>(materialGradeList);
                response = request.CreateResponse<IEnumerable<MaterialGradesViewModel>>(HttpStatusCode.OK, materialGradesVm);
                return response;
            });
        }

        [HttpPost]
        [Route("CreateMaterialGrade")]
        public HttpResponseMessage CreateMaterialGrade(HttpRequestMessage request, MaterialGradesViewModel materialGrades)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    tbl_Material_Grades newMaterialGrade = new tbl_Material_Grades();
                    newMaterialGrade.Material_Grad = materialGrades.Material_Grad;
                    newMaterialGrade.Material_Density = materialGrades.Material_Density;
                    newMaterialGrade.Material_Color = materialGrades.Material_Color;
                    newMaterialGrade.Material_Group = materialGrades.Material_Group;
                    newMaterialGrade.tenant_id = materialGrades.tenant_id;
                    newMaterialGrade.CompID = materialGrades.CompID;
                    newMaterialGrade.Modified_On = null;
                    newMaterialGrade.Modified_By = null;
                    newMaterialGrade.Created_By = materialGrades.Created_By;
                    newMaterialGrade.Created_On = DateTime.Now;
                    _materialGradesRepository.Add(newMaterialGrade);
                    _unitOfWork.Commit();

                    response = request.CreateResponse<MaterialGradesViewModel>(HttpStatusCode.Created, materialGrades);
                }

                return response;
            });
        }




    }
}