﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
    [RoutePrefix("api/MakerMaster")]
    public class MakerMasterController : ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_Maker_Master> _makerMasterRepository;

        public MakerMasterController(IEntityBaseRepository<tbl_Maker_Master> makerMasterRepository,
            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _makerMasterRepository = makerMasterRepository;
        }


        [HttpGet]
        [Route("GetMakerMasterList")]
        public HttpResponseMessage GetMakerMasterList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var makerMasterList = _makerMasterRepository.GetAll();
                IEnumerable<MakerMasterViewModel> makerMastervm = Mapper.Map<IEnumerable<tbl_Maker_Master>, IEnumerable<MakerMasterViewModel>>(makerMasterList);
                response = request.CreateResponse<IEnumerable<MakerMasterViewModel>>(HttpStatusCode.OK, makerMastervm);
                return response;
            });
        }

        [HttpPost]
        [Route("CreateMakers")]
        public HttpResponseMessage CreateMakers(HttpRequestMessage request, MakerMasterViewModel maker)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    tbl_Maker_Master newMakerMaster = new tbl_Maker_Master();
                    newMakerMaster.Maker_No = maker.Maker_No;
                    newMakerMaster.Maker_Description = maker.Maker_Description;
                    newMakerMaster.tenant_id = maker.tenant_id;
                    newMakerMaster.CompID = maker.CompID;
                    newMakerMaster.Modified_On = null;
                    newMakerMaster.Modified_By = null;
                    newMakerMaster.Created_By = maker.Created_By;
                    newMakerMaster.Created_On = DateTime.Now;
                    _makerMasterRepository.Add(newMakerMaster);
                    _unitOfWork.Commit();

                    response = request.CreateResponse<MakerMasterViewModel>(HttpStatusCode.Created, maker);
                }

                return response;
            });
        }

        [Route("UpdateMaker")]
        [HttpPost]
        public HttpResponseMessage UpdateMaker(HttpRequestMessage request, MakerMasterViewModel maker)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingMaker = _makerMasterRepository.GetSingle(maker.id);
                    existingMaker.Maker_No = maker.Maker_No;
                    existingMaker.Maker_Description = maker.Maker_Description;
                    existingMaker.Modified_On = DateTime.Now;
                    _makerMasterRepository.Edit(existingMaker);
                    _unitOfWork.Commit();
                    response = request.CreateResponse(HttpStatusCode.OK);

                }
                return response;
            });

        }
        [HttpPost]
        [Route("DeleteMaker/{id:int}")]
        public HttpResponseMessage DeleteMaker(HttpRequestMessage request, int id)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingMaker = _makerMasterRepository.GetSingle(id);
                    if (existingMaker != null)
                    {
                        _makerMasterRepository.Delete(existingMaker);
                        _unitOfWork.Commit();
                        response = request.CreateResponse(HttpStatusCode.OK);
                    }
                }
                return response;
            });
        }



    }   
}