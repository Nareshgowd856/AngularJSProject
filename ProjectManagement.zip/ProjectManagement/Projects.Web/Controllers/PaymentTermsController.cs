﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
    [RoutePrefix("api/PaymentTerms")]
    public class PaymentTermsController : ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_project_technical_data_child> _paymentTermsRepository;

        public PaymentTermsController(IEntityBaseRepository<tbl_project_technical_data_child> paymentTermsRepository,
            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _paymentTermsRepository = paymentTermsRepository;
        }


        [HttpGet]
        [Route("GetPaymentTermsList")]
        public HttpResponseMessage GetPaymentTermsList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
               HttpResponseMessage response = null;
              var paymentTermsList = _paymentTermsRepository.GetAll();
                  IEnumerable<ProjectTechnicalDataChildViewModel> technicalDataChildVm = Mapper.Map<IEnumerable<tbl_project_technical_data_child>, IEnumerable<ProjectTechnicalDataChildViewModel>>(paymentTermsList);
                response = request.CreateResponse<IEnumerable<ProjectTechnicalDataChildViewModel>>(HttpStatusCode.OK, technicalDataChildVm);
                return response;
            });
        }

        [HttpPost]
        [Route("CreatePaymentTerms")]
        public HttpResponseMessage CreatePaymentTerms(HttpRequestMessage request, ProjectTechnicalDataChildViewModel payment)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    tbl_project_technical_data_child newProjecttechnicalDataChild = new tbl_project_technical_data_child();
                    newProjecttechnicalDataChild.Project_Code = payment.Project_Code;
                    newProjecttechnicalDataChild.Mile_Stone = payment.Mile_Stone;
                    newProjecttechnicalDataChild.Per_Payments = payment.Per_Payments;
                    newProjecttechnicalDataChild.TriggeringPoint = payment.TriggeringPoint;
                    newProjecttechnicalDataChild.tenant_id = payment.tenant_id;
                    newProjecttechnicalDataChild.CompID = payment.CompID;
                    newProjecttechnicalDataChild.Modified_On = null;
                    newProjecttechnicalDataChild.Modified_By = null;
                    newProjecttechnicalDataChild.Created_By = payment.Created_By;
                    newProjecttechnicalDataChild.Created_On = DateTime.Now;
                    _paymentTermsRepository.Add(newProjecttechnicalDataChild);
                    _unitOfWork.Commit();

                    response = request.CreateResponse<ProjectTechnicalDataChildViewModel>(HttpStatusCode.Created, payment);
                }

                return response;
            });
        }



    }
}