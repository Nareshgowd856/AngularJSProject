﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
    [RoutePrefix("api/SubAssembly")]
    public class SubAssemblyController: ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_SubAssembly_Master> _subAssemblyMasterRepository;

        public SubAssemblyController(IEntityBaseRepository<tbl_SubAssembly_Master> subAssemblyMasterRepository,
            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _subAssemblyMasterRepository = subAssemblyMasterRepository;
        }


        [HttpGet]
        [Route("GetSubAssemblyMasterList")]
        public HttpResponseMessage GetSubAssemblyMasterList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var subAssemblyMasterList = _subAssemblyMasterRepository.GetAll();
                IEnumerable<SubAssemblyMasterViewModel> subAssemblyVm = Mapper.Map<IEnumerable<tbl_SubAssembly_Master>, IEnumerable<SubAssemblyMasterViewModel>>(subAssemblyMasterList);
                response = request.CreateResponse<IEnumerable<SubAssemblyMasterViewModel>>(HttpStatusCode.OK, subAssemblyVm);
                return response;
            });
        }

        [HttpPost]
        [Route("CreateSubAssembly")]
        public HttpResponseMessage CreateSubAssembly(HttpRequestMessage request, SubAssemblyMasterViewModel subAssembly)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    tbl_SubAssembly_Master newSubAssemblyMaster = new tbl_SubAssembly_Master();
                    newSubAssemblyMaster.Sub_Assembly_ID = subAssembly.Sub_Assembly_ID;
                    newSubAssemblyMaster.Sub_Assembly_Name = subAssembly.Sub_Assembly_Name;
                    newSubAssemblyMaster.tenant_id = subAssembly.tenant_id;
                    newSubAssemblyMaster.CompID = subAssembly.CompID;
                    newSubAssemblyMaster.Modified_On = null;
                    newSubAssemblyMaster.Modified_By = null;
                    newSubAssemblyMaster.Created_By = subAssembly.Created_By;
                    newSubAssemblyMaster.Created_On = DateTime.Now;
                    _subAssemblyMasterRepository.Add(newSubAssemblyMaster);
                    _unitOfWork.Commit();

                    response = request.CreateResponse<SubAssemblyMasterViewModel>(HttpStatusCode.Created, subAssembly);
                }

                return response;
            });
        }
        [Route("UpdateSubAssembly")]
        [HttpPost]
        public HttpResponseMessage UpdateSubAssembly(HttpRequestMessage request, SubAssemblyMasterViewModel subAssembly)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingSub = _subAssemblyMasterRepository.GetSingle(subAssembly.id);
                    existingSub.Sub_Assembly_ID = subAssembly.Sub_Assembly_ID;
                    existingSub.Sub_Assembly_Name = subAssembly.Sub_Assembly_Name;
                    existingSub.Modified_On = DateTime.Now;
                    _subAssemblyMasterRepository.Edit(existingSub);
                    _unitOfWork.Commit();
                    response = request.CreateResponse(HttpStatusCode.OK);

                }
                return response;
            });

        }
        [HttpPost]
        [Route("DeleteSubAssembly/{id:int}")]
        public HttpResponseMessage DeleteSubAssembly(HttpRequestMessage request, int id)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingSub = _subAssemblyMasterRepository.GetSingle(id);
                    if (existingSub != null)
                    {
                        _subAssemblyMasterRepository.Delete(existingSub);
                        _unitOfWork.Commit();
                        response = request.CreateResponse(HttpStatusCode.OK);
                    }
                }
                return response;
            });
        }



    }
}