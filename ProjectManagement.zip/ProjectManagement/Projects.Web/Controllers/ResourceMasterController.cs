﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
    [RoutePrefix("api/ResourceMaster")]
    public class ResourceMasterController: ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_Resource_Master> _resourceMasterRepository;

        public ResourceMasterController(IEntityBaseRepository<tbl_Resource_Master> resourceMasterRepository,
            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _resourceMasterRepository = resourceMasterRepository;
        }


        [HttpGet]
        [Route("GetresourceMasterList")]
        public HttpResponseMessage GetresourceMasterList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var resourceMasterList = _resourceMasterRepository.GetAll();
                IEnumerable<ResourceMasterViewModel> resourceMastervm = Mapper.Map<IEnumerable<tbl_Resource_Master>, IEnumerable<ResourceMasterViewModel>>(resourceMasterList);
                response = request.CreateResponse<IEnumerable<ResourceMasterViewModel>>(HttpStatusCode.OK, resourceMastervm);
                return response;
            });
        }

        [HttpPost]
        [Route("CreateResource")]
        public HttpResponseMessage CreateResource(HttpRequestMessage request, ResourceMasterViewModel resource)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    tbl_Resource_Master newResourceMaster = new tbl_Resource_Master();
                    newResourceMaster.Resource_Id = resource.Resource_Id;
                    newResourceMaster.Resource_Name = resource.Resource_Name;
                    newResourceMaster.Skill_Set = resource.Skill_Set;
                    newResourceMaster.tenant_id = resource.tenant_id;
                    newResourceMaster.CompID = resource.CompID;
                    newResourceMaster.Modified_On = null;
                    newResourceMaster.Modified_By = null;
                    newResourceMaster.Created_By = resource.Created_By;
                    newResourceMaster.Created_On = DateTime.Now;
                    _resourceMasterRepository.Add(newResourceMaster);
                    _unitOfWork.Commit();

                    response = request.CreateResponse<ResourceMasterViewModel>(HttpStatusCode.Created, resource);
                }

                return response;
            });
        }



    }   
}