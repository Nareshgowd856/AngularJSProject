﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
    [RoutePrefix("api/Sector")]
    public class ProjectSectorController : ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_ProjectSector_Master> _sectorRepository;

        public ProjectSectorController(IEntityBaseRepository<tbl_ProjectSector_Master> sectorRepository,
            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _sectorRepository = sectorRepository;
        }


        [HttpGet]
        [Route("GetSectorList")]
        public HttpResponseMessage GetSectorList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var sectorList = _sectorRepository.GetAll();
                IEnumerable<ProjectSectorViewModel> sectorvm = Mapper.Map<IEnumerable<tbl_ProjectSector_Master>, IEnumerable<ProjectSectorViewModel>>(sectorList);
                response = request.CreateResponse<IEnumerable<ProjectSectorViewModel>>(HttpStatusCode.OK, sectorvm);
                return response;
            });
        }

        [HttpPost]
        [Route("CreateSector")]
        public HttpResponseMessage CreateSector(HttpRequestMessage request, ProjectSectorViewModel sector)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    tbl_ProjectSector_Master newSector = new tbl_ProjectSector_Master();
                    newSector.Sector_Id = sector.Sector_Id;
                    newSector.Sector_Name = sector.Sector_Name;
                    newSector.tenant_id = sector.tenant_id;
                    newSector.CompID = sector.CompID;
                    newSector.Modified_On = null;
                    newSector.Modified_By = null;
                    newSector.Created_By = sector.Created_By;
                    newSector.Created_On = DateTime.Now;
                    _sectorRepository.Add(newSector);
                    _unitOfWork.Commit();

                    response = request.CreateResponse<ProjectSectorViewModel>(HttpStatusCode.Created, sector);
                }

                return response;
            });
        }

        [Route("UpdateSector")]
        [HttpPost]
        public HttpResponseMessage UpdateSector(HttpRequestMessage request, ProjectSectorViewModel sector)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingSector = _sectorRepository.GetSingle(sector.id);
                    existingSector.Sector_Id = sector.Sector_Id;
                    existingSector.Sector_Name = sector.Sector_Name;
                    existingSector.Modified_On = DateTime.Now;
                    _sectorRepository.Edit(existingSector);
                    _unitOfWork.Commit();
                    response = request.CreateResponse(HttpStatusCode.OK);

                }
                return response;
            });

        }
        [HttpPost]
        [Route("DeleteSector/{id:int}")]
        public HttpResponseMessage DeleteSector(HttpRequestMessage request, int id)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingSector = _sectorRepository.GetSingle(id);
                    if (existingSector != null)
                    {
                        _sectorRepository.Delete(existingSector);
                        _unitOfWork.Commit();
                        response = request.CreateResponse(HttpStatusCode.OK);
                    }
                }
                return response;
            });
        }


    }

}