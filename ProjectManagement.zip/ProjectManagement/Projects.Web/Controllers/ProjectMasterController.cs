﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
    public class projectCreationFormModel
    {
        public int id { get; set; }
        public int tenant_id { get; set; }
        public string CompID { get; set; }
        public string Project_Code { get; set; }
        public string Project_Description { get; set; }
        public string Customer_Name { get; set; }
        public string Currency_Name { get; set; }
        public DateTime Project_DeliveryDate { get; set; }
        public List<string> MakerIDsList { get; set; }
        public string ProjectCodeConstruction { get; set; }
        public string Full_Project_Code { get; set; }
        public string SMR { get; set; }
        public string warrenty { get; set; }
        public bool CEM { get; set; }
        public bool TPIA { get; set; }
        public bool IAC { get; set; }
        public bool CIBTS { get; set; }
        public bool CWLR { get; set; }
        public bool CDGOST { get; set; }
        public bool QAPApproval { get; set; }
        public bool IAI { get; set; }
        public bool IAABC { get; set; }
        public bool CRONC { get; set; }
        public string Project_Classification { get; set; }
        public string Project_Sector { get; set; }
        public string Currency { get; set; }
        public string DDE { get; set; }
        public string DDD { get; set; }
       
    }

    [RoutePrefix("api/ProjectMaster")]
    public class ProjectMasterController : ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_project_master> _projectMasterRepository;
        public readonly IEntityBaseRepository<tbl_project_master_child> _projectMasterChildRepository;
        public readonly IEntityBaseRepository<tbl_project_commercial_data> _projectCommercialRepository;
        public readonly IEntityBaseRepository<tbl_Maker_Master> _makerMasterRepository;
        public readonly IEntityBaseRepository<tbl_project_technical_data> _projectTechnicalDataRepository;
        public readonly IEntityBaseRepository<tbl_Customer_Master> _customerMasterRepository;
        public readonly IEntityBaseRepository<tbl_Currency> _currencyRepository;
        public readonly IEntityBaseRepository<tbl_project_structure_main> _projectStructureMainRepository;
        public readonly IEntityBaseRepository<tbl_APG_Master> _apgMasterRepository;



        public ProjectMasterController(IEntityBaseRepository<tbl_project_master> projectMasterRepository,
            IEntityBaseRepository<tbl_project_master_child> projectMasterChildRepository,
            IEntityBaseRepository<tbl_project_commercial_data> projectCommercialRepository,
            IEntityBaseRepository<tbl_project_technical_data> projectTechnicalDataRepository,
            IEntityBaseRepository<tbl_Maker_Master> makerMasterRepository,
            IEntityBaseRepository<tbl_project_structure_main> projectStructureMainRepository,
             IEntityBaseRepository<tbl_Customer_Master>  customerMasterRepository,
              IEntityBaseRepository<tbl_Currency> currencyRepository,
              IEntityBaseRepository<tbl_APG_Master> apgMasterRepository,


            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _projectMasterRepository = projectMasterRepository;
            _projectMasterChildRepository = projectMasterChildRepository;
            _projectCommercialRepository = projectCommercialRepository;
            _makerMasterRepository = makerMasterRepository;
            _projectTechnicalDataRepository = projectTechnicalDataRepository;
            _customerMasterRepository = customerMasterRepository;
            _currencyRepository = currencyRepository;
            _projectStructureMainRepository = projectStructureMainRepository;
            _apgMasterRepository = apgMasterRepository;
        }

        [HttpGet]
        [Route("GetProjectMasterList")]
        public HttpResponseMessage GetProjectMasterList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var projectMasterList = _projectMasterRepository.GetAll();
                IEnumerable<ProjectMasterViewModel> projectMastervm = Mapper.Map<IEnumerable<tbl_project_master>, IEnumerable<ProjectMasterViewModel>>(projectMasterList);
                response = request.CreateResponse<IEnumerable<ProjectMasterViewModel>>(HttpStatusCode.OK, projectMastervm);
                return response;
            });
        }
        [HttpGet]
        [Route("GetCustomerMasterList")]
        public HttpResponseMessage GetCustomerMasterList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var customerMasterList = _customerMasterRepository.GetAll();
                IEnumerable<CustomerMasterViewModel> customerMastervm = Mapper.Map<IEnumerable<tbl_Customer_Master>, IEnumerable<CustomerMasterViewModel>>(customerMasterList);
                response = request.CreateResponse<IEnumerable<CustomerMasterViewModel>>(HttpStatusCode.OK, customerMastervm);
                return response;
            });
        }

        [HttpGet]
        [Route("GetCurrencyList")]
        public HttpResponseMessage GetCurrencyList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var currencyList = _currencyRepository.GetAll();
                IEnumerable<CurrencyViewModel> currencyvm = Mapper.Map<IEnumerable<tbl_Currency>, IEnumerable<CurrencyViewModel>>(currencyList);
                response = request.CreateResponse<IEnumerable<CurrencyViewModel>>(HttpStatusCode.OK, currencyvm);
                return response;
            });
        }

        [HttpGet]
        [Route("GetProjectCommercialList")]
        public HttpResponseMessage GetProjectCommercialList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var projectCommercialList = _projectCommercialRepository.GetAll();
                IEnumerable<ProjectCommercialDataViewModel> projectCommercialvm = Mapper.Map<IEnumerable<tbl_project_commercial_data>, IEnumerable<ProjectCommercialDataViewModel>>(projectCommercialList);
                response = request.CreateResponse<IEnumerable<ProjectCommercialDataViewModel>>(HttpStatusCode.OK, projectCommercialvm);
                return response;
            });
        }

        [HttpPost]
        [Route("CreateProjectMaster")]
        public HttpResponseMessage CreateProjectMaster(HttpRequestMessage request, projectCreationFormModel projectCreation)
        {
            return CreateHttpResponse(request, () =>           {
            HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    tbl_project_master newProjectMaster = new tbl_project_master();
                    newProjectMaster.Project_Code = projectCreation.Project_Code;
                    newProjectMaster.Project_Description = projectCreation.Project_Description;
                    newProjectMaster.Project_Client = projectCreation.Customer_Name;
                    newProjectMaster.Project_DeliveryDate = projectCreation.Project_DeliveryDate;
                    newProjectMaster.tenant_id = projectCreation.tenant_id;
                    newProjectMaster.CompID = "0001";
                    newProjectMaster.Created_By = projectCreation.tenant_id.ToString();
                    newProjectMaster.Created_On = DateTime.Now;
                    newProjectMaster.Modified_By = null;
                    newProjectMaster.Modified_On = null;
                    _projectMasterRepository.Add(newProjectMaster);

                    foreach (var item in projectCreation.MakerIDsList)
                    {
                        int makerId = Convert.ToInt32(item);
                        var makerMasterData = _makerMasterRepository.GetAll().Where(x => x.id == makerId).FirstOrDefault();
                        if (makerMasterData.id != 0)
                        {
                            tbl_project_master_child newProjectMasterChild = new tbl_project_master_child();
                            newProjectMasterChild.tenant_id = projectCreation.tenant_id;
                            newProjectMasterChild.Project_Code = projectCreation.Project_Code;
                            newProjectMasterChild.Project_Equp_Name = makerMasterData.Maker_Description;
                            newProjectMasterChild.CompID = "0001";
                            newProjectMasterChild.Maker_No = makerMasterData.Maker_No;
                            newProjectMasterChild.Full_Project_Code = projectCreation.Project_Code + "." + makerMasterData.Maker_No;
                            newProjectMasterChild.Created_By = projectCreation.tenant_id.ToString();
                            newProjectMasterChild.Created_On = DateTime.Now;
                            newProjectMasterChild.Modified_By = null;
                            newProjectMasterChild.Modified_On = null;
                            _projectMasterChildRepository.Add(newProjectMasterChild);
                        }


                        _unitOfWork.Commit();
                    }

                    tbl_project_technical_data newPTData = new tbl_project_technical_data();
                    newPTData.tenant_id = projectCreation.tenant_id;
                    newPTData.Project_Code = projectCreation.Project_Code;
                    newPTData.Special_Mtrl_Requ_Chk = projectCreation.SMR.ToString();
                    newPTData.Special_Mtrl_Requ = projectCreation.SMR.ToString();
                    newPTData.Warranty_Period = projectCreation.warrenty.ToString();
                    newPTData.CE_Marking = projectCreation.CEM.ToString();
                    newPTData.Insp_TPIA = projectCreation.TPIA.ToString();
                    newPTData.ASME_Code = "ASME 1";
                    newPTData.National_Board_Reg = "National_Board_Reg 1";
                    newPTData.InspectonBy_CIB = projectCreation.CIBTS.ToString();
                    newPTData.Comp_With_Loc_Reg = projectCreation.CWLR.ToString();
                    newPTData.Comp_With_Doc_To_Gost = projectCreation.CDGOST.ToString();
                    newPTData.QAP_Approve = projectCreation.QAPApproval.ToString();
                    newPTData.Insp_by_Auth_Insp = projectCreation.IAI.ToString();
                    newPTData.Insp_by_Accep_Client = projectCreation.IAABC.ToString();
                    newPTData.Concession_Requeist_Client = projectCreation.CRONC.ToString();
                    newPTData.CompID = "0001";
                    newPTData.ProjectCodeConstruction = projectCreation.ProjectCodeConstruction;
                    newPTData.Created_By = projectCreation.tenant_id.ToString();
                    newPTData.Created_On = DateTime.Now;
                    newPTData.Modified_By = null;
                    newPTData.Modified_On = null;
                    _projectTechnicalDataRepository.Add(newPTData);

                    tbl_project_commercial_data newPCData = new tbl_project_commercial_data();
                    newPCData.Project_Code = projectCreation.Project_Code;
                    newPCData.Project_Currency = projectCreation.Currency_Name;
                    newPCData.Project_Sector = projectCreation.Project_Sector;
                    newPCData.LDfor_Delyed_Deliveryfor_Draw = projectCreation.DDD;
                    newPCData.LDfor_Delyed_Deliveryfor_Equp = projectCreation.DDE;
                    newPCData.Mile_Stone = null;
                    newPCData.Per_Payments = null;
                    newPCData.TriggeringPoint = null;
                    newPCData.Project_Clasificaton = projectCreation.Project_Classification;
                    newPCData.tenant_id = projectCreation.tenant_id;
                    newPCData.CompID = "0001";
                    newPCData.Created_By = projectCreation.tenant_id.ToString();
                    newPCData.Created_On = DateTime.Now;
                    newPCData.Modified_By = null;
                    newPCData.Modified_On = null;
                    _projectCommercialRepository.Add(newPCData);


                    tbl_project_structure_main newPSData = new tbl_project_structure_main();
                    newPSData.Project_Code = projectCreation.Project_Code;
                    newPSData.APG_Name = null;
                    newPSData.Apg_No = null;
                    // newPSData.Maker_Name = projectCreation.MakerIDsList.ToString();
                    // newPSData.Maker_No = projectCreation.MakerIDsList.ToString();
                    newPSData.Full_Project_Code = projectCreation.Full_Project_Code;
                    newPSData.tenant_id = projectCreation.tenant_id;
                    newPSData.CompID = "0001";
                    newPSData.Created_By = projectCreation.tenant_id.ToString();
                    newPSData.Created_On = DateTime.Now;

                    newPSData.Modified_By = null;
                    newPSData.Modified_On = null;
                    _projectStructureMainRepository.Add(newPSData);

                    foreach (var item in projectCreation.MakerIDsList)
                    {
                        int makerId = Convert.ToInt32(item);
                        var makerMasterData = _makerMasterRepository.GetAll().Where(x => x.id == makerId).FirstOrDefault();
                        if (makerMasterData.id != 0)
                        {
                            tbl_project_structure_main newProjectStructureChild = new tbl_project_structure_main();
                            newProjectStructureChild.tenant_id = projectCreation.tenant_id;
                            newProjectStructureChild.Project_Code = projectCreation.Project_Code;
                            newProjectStructureChild.CompID = "0001";
                            newProjectStructureChild.Maker_No = makerMasterData.Maker_No;
                            newProjectStructureChild.Maker_Name = makerMasterData.Maker_Description;
                            newProjectStructureChild.Full_Project_Code = projectCreation.Project_Code + "." + makerMasterData.Maker_No;
                            newProjectStructureChild.Created_By = projectCreation.tenant_id.ToString();
                            newProjectStructureChild.Created_On = DateTime.Now;
                            newProjectStructureChild.Modified_By = null;
                            newProjectStructureChild.Modified_On = null;
                            _projectStructureMainRepository.Add(newProjectStructureChild);
                        }
                    }

                        _unitOfWork.Commit();

                        response = request.CreateResponse<projectCreationFormModel>(HttpStatusCode.Created, projectCreation);
                    }
                    return response;
                
            });
       
        }

        [HttpGet]
        [Route("GetProjectMasterChildList")]
        public HttpResponseMessage GetProjectMasterChildList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var projectMasterChildList = _projectMasterChildRepository.GetAll();
                IEnumerable<ProjectMasterChildViewModel> projectMasterChildvm = Mapper.Map<IEnumerable<tbl_project_master_child>, IEnumerable<ProjectMasterChildViewModel>>(projectMasterChildList);
                response = request.CreateResponse<IEnumerable<ProjectMasterChildViewModel>>(HttpStatusCode.OK, projectMasterChildvm);
                return response;
            });
        }

        [HttpGet]
        [Route("GetProjectStructureMainList")]
        public HttpResponseMessage GetProjectStructureMainList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var projectStructureMainList = _projectStructureMainRepository.GetAll().Distinct();
                IEnumerable<ProjectStructureMainViewModel> projectStructureMainVm = Mapper.Map<IEnumerable<tbl_project_structure_main>, IEnumerable<ProjectStructureMainViewModel>>(projectStructureMainList);
                response = request.CreateResponse<IEnumerable<ProjectStructureMainViewModel>>(HttpStatusCode.OK, projectStructureMainVm);
                return response;
            });
        }

        [Route("UpdateProjectMaster")]
        [HttpPost]
        public HttpResponseMessage UpdateProjectMaster(HttpRequestMessage request, projectCreationFormModel project)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingProject = _projectMasterRepository.GetSingle(project.id);
                    existingProject.Project_Code = project.Project_Code;
                    existingProject.Project_Description = project.Project_Description;
                    existingProject.Project_DeliveryDate = DateTime.Now;
                    existingProject.Modified_On = DateTime.Now;
                    _projectMasterRepository.Edit(existingProject);

                    var existingCM = _customerMasterRepository.GetSingle(project.id);
                    existingCM.Customer_Name = project.Customer_Name;
                    existingCM.Modified_On = DateTime.Now;
                    _projectMasterRepository.Edit(existingProject);

                    var existingCurrency = _currencyRepository.GetSingle(project.id);
                    existingCurrency.Currency_Name = project.Currency_Name;
                    existingCurrency.Modified_On = DateTime.Now;
                    _projectMasterRepository.Edit(existingProject);
                    _unitOfWork.Commit();
                    response = request.CreateResponse(HttpStatusCode.OK);

                  
                }
                return response;
            });

        }

        [HttpPost]
        [Route("DeleteProjectMaster/{id:int}")]
        public HttpResponseMessage DeleteProjectMaster(HttpRequestMessage request, int id)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingProject = _projectMasterRepository.GetSingle(id);
                    if (existingProject != null)
                    {
                        _projectMasterRepository.Delete(existingProject);
                        _unitOfWork.Commit();
                        response = request.CreateResponse(HttpStatusCode.OK);
                    }
                }
                return response;
            });
        }

    }
}