﻿(function (app) {
    'use strict';
    app.controller('partListCtrl', partListCtrl);
    partListCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function partListCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal) {

        $scope.partListItem = {};
        $scope.subAssemblyList = [];
        $scope.materialGradeList = [];
        $scope.PartListItemList = [];
        $scope.showform = true;
        $scope.showGrid = true;

        $scope.shownewPartListItemForm = function () {
            $scope.showForm = true;
            $scope.showGrid = true;
        };

        $scope.MaterialShapeFinishedList = [{ text: "Rectangle", value: "1" }, { text: "Circle", value: "2" }, { text: "Square", value: "2" }];
        $scope.MaterialShapeRMList = [{ text: "Rectangle", value: "1" }, { text: "Circle", value: "2" }, { text: "Square", value: "2" }];

        $scope.showform = function () {
            $scope.showGrid = false;
            $scope.showform = false;
        };
        $scope.hideForm = function () {
            $scope.showGrid = true;
            $scope.showform = true;
        };
        $scope.hidePartListItemform = function () {
            $scope.partListItem = {};
            $scope.showForm = false;
            $scope.showGrid = true;
        };
        function savePartListItemComplete(response) {
            notificationService.displaySuccess("PartList data saved successfully");
            $scope.showGrid = true;
            $scope.showform = true;
            $scope.partListItem = {};
            LoadPartListItemList();
        }
        function savePartListItemFailed() {
            notificationService.displayError("Unable to save PartList");
        }

        LoadPartListItemList();
        function LoadPartListItemList() {

            apiService.get('api/PartListItem/GetPartListItemList', null, partListItemLoadComplete, partListItemLoadFailed);
            apiService.get('api/PartListItem/GetMaterialGradesList', null, materialGradesLoadComplete, materialGradesLoadFailed);
            apiService.get('api/PartListItem/GetSubAssemblyList', null, subAssemblyLoadComplete, subAssemblyLoadFailed);

        };
        function partListItemLoadComplete(response) {
            $scope.PartListItemList = response.data;
        }
        function partListItemLoadFailed() {
            notificationService.displayError("Unable to Get PartList Data");
        }
        function materialGradesLoadComplete(response) {
            $scope.materialGradeList = response.data;
        }
        function materialGradesLoadFailed() {
            notificationService.displayError("Unable to Get PartList Data");
        }
        function subAssemblyLoadComplete(response) {
            $scope.subAssemblyList = response.data;
        }
        function subAssemblyLoadFailed() {
            notificationService.displayError("Unable to Get PartList Data");
        }

        $scope.DeletePartListItem = function (pli) {
            alertify.confirm("Delete", "Are You Sure to Delete ", function () {
                apiService.post('api/PartListItem/DeletePartListItem/' + pli.id, null, DeleteUserComplete, DeleteUserFailed);
            },
                function () { }).set('reverseButtons', false);
        }
        function DeleteUserComplete(response) {
            notificationService.displaySuccess('Deleted Successfully.');
            LoadPartListItemList();
        }
        function DeleteUserFailed(response) {
            notificationService.displayError(' Deleted  Failed !');
        }
        //$scope.saveMakers = function saveMakers() {
        //    apiService.post('api/MakerMaster/CreateMakers', $scope.makerMaster, saveMakersComplete, saveMakersFailed);
        //};
        //function saveMakersComplete(response) {
        //    notificationService.displaySuccess("Maker created Successfully");
        //    $scope.makerMaster = {};
        //    LoadMakerMasterList();
        //}
        //function saveMakersFailed() {
        //    notificationService.displayError("Unable to Create Maker");
        //    $scope.showForm = true;
        //    $scope.showGrid = false;
        //}



    }
})(angular.module('common.core'));