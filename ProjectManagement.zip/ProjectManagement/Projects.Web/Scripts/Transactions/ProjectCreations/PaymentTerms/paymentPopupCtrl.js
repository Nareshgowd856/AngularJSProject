﻿(function (app) {
    'use strict';
    app.controller('paymentPopupctrl', paymentPopupctrl);
    projectCreationsCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$route', '$modal', '$modalInstance'];
    function paymentPopupctrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $route, $modal, $modalInstance)
    {

        $scope.paymentTerms = {};


        $scope.closePaymentTermsmodal = function closePaymentTermsmodal() {
            $modalInstance.close();
        };

        $scope.savePaymentTerms = function savePaymentTerms() {
            apiService.post('api/PaymentTerms/CreatePaymentTerms', $scope.paymentTerms, savePaymentTermsComplete, savePaymentTermsFailed);
        };
        function savePaymentTermsComplete(response) {
            notificationService.displaySuccess("Payment Terms created Successfully");
            $scope.paymentTerms = {};
            apiService.get('api/PaymentTerms/GetPaymentTermsList', null, paymentTermsLoadComplete, paymentTermsLoadFailed);
            $modalInstance.close();
        }
        function savePaymentTermsFailed() {
            notificationService.displayError("Unable to Create Payments");
        }
        function paymentTermsLoadComplete(response) {
            $rootScope.paymentTermsList = response.data;
            $modalInstance.close();
        }
        function paymentTermsLoadFailed() {
            notificationService.displayError("Unable to Get Payments Data");
            $modalInstance.close();
        }

      
    }
})(angular.module('common.core'));