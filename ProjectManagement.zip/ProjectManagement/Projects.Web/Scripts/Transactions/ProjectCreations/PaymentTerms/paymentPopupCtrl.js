﻿(function (app) {
    'use strict';
    app.controller('paymentPopupCtrl', paymentPopupCtrl);
    paymentPopupCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$route', '$modal', '$modalInstance','projectCode'];
    function paymentPopupCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $route, $modal, $modalInstance, projectCode) {

        $scope.paymentTerms = {};
        $scope.project_code = projectCode;

        $scope.closePaymentTermsmodal = function closePaymentTermsmodal() {
            $modalInstance.close();
        };

        $scope.savePaymentTerms = function savePaymentTerms() {
            $scope.paymentTerms.Project_Code = $scope.project_code;
            $scope.paymentTerms.tenant_id = $rootScope.tenant.tenant_id;
            apiService.post('api/PaymentTerms/CreatePaymentTerms', $scope.paymentTerms, savePaymentTermsComplete, savePaymentTermsFailed);
        };
        function savePaymentTermsComplete(response) {
            notificationService.displaySuccess("Payment Terms created Successfully");
            $scope.paymentTerms = {};
            apiService.get('api/PaymentTerms/GetPaymentTermsListById', $scope.project_code, paymentTermsLoadComplete, paymentTermsLoadFailed);
            $modalInstance.close();
        }
        function savePaymentTermsFailed() {
            notificationService.displayError("Unable to Create Payments");
        }

        function paymentTermsLoadComplete(response) {
            $rootScope.paymentTermsList = response.data;
            $modalInstance.close();
        }
        function paymentTermsLoadFailed() {
            notificationService.displayError("Unable to Get Payments Data");
            $modalInstance.close();
        }


    }
})(angular.module('common.core'));