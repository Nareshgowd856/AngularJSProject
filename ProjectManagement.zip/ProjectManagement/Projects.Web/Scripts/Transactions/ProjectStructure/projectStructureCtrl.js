﻿
(function (app) {
    'use strict';
    app.controller('projectStructureCtrl', projectStructureCtrl);
    projectStructureCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function projectStructureCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal , ) {

        $scope.apgMasterList = [];
        $scope.projectStructureMainList = [];
        $scope.projectMasterList = [];
        $scope.projectStructure = {};
        $scope.checkedIds = [];
        $scope.showGrid = true;
        $scope.showform = true;

        $scope.showform = function (psItem) {
            $scope.showGrid = false;
            $scope.showform = false;
            $scope.projectStructure.Project_Code = psItem.Project_Code;
            $scope.projectStructure.Maker_No = psItem.Maker_No;
            $scope.projectStructure.Maker_Name = psItem.Maker_Name;
            $route.reload();
        };
        $scope.hideForm = function () {
            $scope.showGrid = true;
            $scope.showform = true;
        };
        $scope.addProjectStructure = function () {
            $scope.checkedIds = [];
            $scope.projectStructure.tenant_id = $rootScope.tenant.tenant_id;
            for (var i = 0; i < $rootScope.apgMasterList.length; i++) {
                $scope.checkedIds.push($rootScope.apgMasterList[i].id);
            }
            $scope.projectStructure.APGIDsList = $scope.checkedIds;
            apiService.post('api/ProjectStructure/CreateProjectStructure', $scope.projectStructure, saveProjectStructureComplete, saveProjectStructureFailed);
        };
        function saveProjectStructureComplete(response) {
            notificationService.displaySuccess("Project Structure data saved successfully");
            $scope.showGrid = true;
            $scope.showform = true;
            $scope.projectStructure = {};
            LoadProjectStructureList();
        }
        function saveProjectStructureFailed() {
            notificationService.displayError("Unable to save Project Structure");
        }
        //$scope.showPartListItemform = function () {
        //    $scope.showForm = true;
        //    $scope.showGrid = true;
        //};
        LoadAPGMasterList();
        function LoadAPGMasterList() {
            apiService.get('api/ProjectStructure/GetAPGMasterList', null, apgMasterLoadComplete, apgMasterLoadFailed);
            apiService.get('api/ProjectStructure/GetProjectStructureMainList', null, projectStructureMainLoadComplete, projectStructureMainLoadFailed);

        };

        function projectStructureMainLoadComplete(response) {
            $scope.projectStructureMainList = response.data;
        }

        function projectStructureMainLoadFailed(response) {
            notificationService.displayError("Unable to  Get  Data");
        }

        function apgMasterLoadComplete(response) {
            $scope.apgMasterList = response.data;
        }
        function apgMasterLoadFailed(response) {
            notificationService.displayError("Unable to Get APG Data");
        }

        $scope.closeAPGMastermodal = function closeAPGMastermodal() {
            $modalInstance.close();
        };
        LoadprojectStructureMainList();
        function LoadprojectStructureMainList() {
            apiService.get('api/ProjectStructure/GetProjectStructureMainList', null, projectStructureLoadComplete, projectStructureLoadFailed);
        };
        function projectStructureLoadComplete(response) {
            $scope.projectStructureMainList = response.data;
        }

        function projectStructureLoadFailed(response) {
            notificationService.displayError("Unable to Get Project Structure Data");
        }
        $scope.apgPopup1 = function () {
            var modalInstance = $modal.open({
                templateUrl: 'Scripts/Master/ProjectGroups/apgPopup.html',
                controller: 'apgPopupCtrl',
                scope: $scope,
            });
        };
        $scope.makersPopup2 = function () {
            var modalInstance = $modal.open({
                templateUrl: 'Scripts/Master/ProjectGroups/apgPopup.html',
                controller: 'apgPopupCtrl',
                scope: $scope,
            });
        };
        $scope.selectAPGPopUp = function () {
            var modalInstance = $modal.open({
                templateUrl: 'Scripts/Master/ProjectGroups/apgPopup.html',
                controller: 'apgPopupCtrl',
                scope: $scope
            });
        };

    }

})(angular.module('common.core'));