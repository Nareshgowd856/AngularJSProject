﻿(function (app) {
    'use strict';
    app.controller('customerCtrl', customerCtrl);
    customerCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function customerCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal) {

        $scope.customerMasterList = [];
        $scope.customerMaster = {};
        $scope.showform = false;
        $scope.showGrid = true;
        $scope.customer = {};

        $scope.showCustomersform = function () {
            $scope.showForm = true;
            $scope.showGrid = false;
        };
        $scope.hideCustomersform = function () {
            $scope.customerMaster = {};
            $scope.showForm = false;
            $scope.showGrid = true;
        };

        LoadCustomerMasterList();
        function LoadCustomerMasterList() {
            apiService.get('api/CustomerMaster/GetCustomerMasterList', null, customerMasterLoadComplete, customerMasterLoadFailed);
        };
        function customerMasterLoadComplete(response) {
            $scope.customerMasterList = response.data;
            if ($scope.customerMasterList.length > 0) {
                $scope.showForm = false;
                $scope.showGrid = true;
            }
        }
        function customerMasterLoadFailed(response) {
            notificationService.displayError("Unable to Get Customer Master Data");
        }

        $scope.saveCustomers = function saveCustomers() {
            apiService.post('api/CustomerMaster/CreateCustomers', $scope.customerMaster, saveCustomersComplete, saveCustomersFailed);
        };
        function saveCustomersComplete(response) {
            notificationService.displaySuccess(" created Successfully");
            $scope.customerMaster = {};
            LoadCustomerMasterList();
        }
        function saveCustomersFailed() {
            notificationService.displayError("Unable to Create Client");
            $scope.showForm = true;
            $scope.showGrid = false;
        }
        $scope.editCall = function (rowform) {
            if ($(".checkVisible").is(":visible")) {
                rowform.$cancel();
            }
            else {
                rowform.$show();
            }
        };

        $scope.updateUser = function (data, id) {
            angular.extend(data, { id: id });
            $scope.customer.id = data.id;
            $scope.customer.Customer_Id = data.cmid;
            $scope.customer.Customer_Name = data.cmname;
            apiService.post('api/CustomerMaster/UpdateCustomer', $scope.customer, UpdateUserComplete, UpdateUserFailed);

        };
        function UpdateUserComplete() {
            notificationService.displaySuccess(" Updated Successfully");
            LoadCustomerMasterList();
        }
        function UpdateUserFailed() {
            notificationService.displayError("  Update Failed !");
        }
        $scope.DeleteCustomer = function (cm) {
            alertify.confirm("Delete", "Are You Sure to Delete ", function () {
                apiService.post('api/CustomerMaster/DeleteCustomer/' + cm.id, null, DeleteUserComplete, DeleteUserFailed);
            },
                function () { }).set('reverseButtons', false);
        }
        function DeleteUserComplete(response) {
            notificationService.displaySuccess('Deleted Successfully.');
            LoadCustomerMasterList();
        }
        function DeleteUserFailed(response) {
            notificationService.displayError(' Deleted  Failed !');
        }

    }
})(angular.module('common.core'));