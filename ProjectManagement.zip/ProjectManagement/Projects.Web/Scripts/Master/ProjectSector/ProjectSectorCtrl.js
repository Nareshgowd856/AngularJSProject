﻿(function (app) {
    'use strict';
    app.controller('ProjectSectorCtrl', ProjectSectorCtrl);
    ProjectSectorCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function ProjectSectorCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal) {

        $scope.sectorList = [];
        $scope.sector = {};
        $scope.showform = false;
        $scope.showGrid = true;


        $scope.showSectorform = function () {
            $scope.showForm = true;
            $scope.showGrid = false;
        };
        $scope.hideSectorform = function () {
            $scope.currency = {};
            $scope.showForm = false;
            $scope.showGrid = true;
        };

        LoadSectorList();
        function LoadSectorList() {
            apiService.get('api/Sector/GetSectorList', null, sectorLoadComplete, sectorLoadComplete);
        };
        function sectorLoadComplete(response) {
            $scope.sectorList = response.data;
            if ($scope.sectorList.length > 0) {
                $scope.showForm = false;
                $scope.showGrid = true;
            }
        }
        function sectorLoadComplete(response) {
            notificationService.displayError("Unable to Get  Data");
        }

        $scope.saveSector = function saveSector() {
            apiService.post('api/Sector/CreateSector', $scope.sector, saveSectorComplete, saveSectorFailed);
        };
        function saveSectorComplete(response) {
            notificationService.displaySuccess(" created Successfully");
            $scope.sector = {};
            LoadSectorList();
        }
        function saveSectorFailed() {
            notificationService.displayError("Unable to Create ");
            $scope.showForm = true;
            $scope.showGrid = false;
        }
        $scope.editCall = function (rowform) {
            if ($(".checkVisible").is(":visible")) {
                rowform.$cancel();
            }
            else {
                rowform.$show();
            }
        };

        $scope.updateUser = function (data, id) {
            angular.extend(data, { id: id });
            $scope.sector.id = data.id;
            $scope.sector.Sector_Id = data.psid;
            $scope.sector.Sector_Name = data.psname;
            apiService.post('api/Sector/UpdateSector', $scope.sector, UpdateUserComplete, UpdateUserFailed);

        };
        function UpdateUserComplete() {
            notificationService.displaySuccess(" Updated Successfully");
            LoadSectorList();
        }
        function UpdateUserFailed() {
            notificationService.displayError("  Update Failed !");
        }
        $scope.DeleteSector = function (mm) {
            alertify.confirm("Delete", "Are You Sure to Delete ", function () {
                apiService.post('api/Sector/DeleteSector/' + psm.id, null, DeleteUserComplete, DeleteUserFailed);
            },
                function () { }).set('reverseButtons', false);
        }
        function DeleteUserComplete(response) {
            notificationService.displaySuccess('Deleted Successfully.');
            LoadSectorList();
        }
        function DeleteUserFailed(response) {
            notificationService.displayError(' Deleted  Failed !');
        }

    }
})(angular.module('common.core'));