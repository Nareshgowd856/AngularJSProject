﻿(function (app) {
    'use strict';
    app.controller('itemMasterCtrl', itemMasterCtrl);
    itemMasterCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function itemMasterCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal) {

        $scope.partListItemList = [];
        $scope.partListItem = {};
        $scope.ItemchildTerms = {};
        $scope.Item_Spec = {};
        $scope.showform = true;
        $scope.showGrid = true;
        $scope.showchild = false;
        $scope.readOnlyStatus = false;

        LoadItemtMasterList();

        $scope.showDupGrid = function () {
            $scope.showchild = false;
            $scope.showGrid = true;
        };
        $scope.hidegrid = function () {
            $scope.showchild = true;
            $scope.showGrid = false;
        };

        $scope.haiFunc = function (item) {
            console.log($scope.Item_Spec);
            console.log(item);
        };

        function LoadItemtMasterList() {
            apiService.get('api/itemMaster/GetUomList', null, currencyLoadComplete, currrencyLoadFailed);
            apiService.get('api/itemMaster/GetSpecificationList', null, specLoadComplete, specLoadFailed);
            apiService.get('api/itemMaster/GetGroupMasterList', null, groupLoadComplete, groupLoadFailed);
        };
        function currencyLoadComplete(response) {
            $scope.currencyList = response.data;
        }
        function currrencyLoadFailed() {
            notificationService.displayError("Unable to  Get Project Customers Data");
        }
        function specLoadComplete(response) {
            $scope.specificationList = response.data;
        }
        function specLoadFailed() {
            notificationService.displayError("Unable to  Get Project Customers Data");
        }

        function groupLoadComplete(response) {
            $scope.groupMasterList = response.data;
        }
        function groupLoadFailed() {
            notificationService.displayError("Unable to  Get Project Customers Data");
        }
        $scope.showPartListItemform = function () {
            $scope.showForm = true;
            $scope.showGrid = true;
        };
        $scope.getGroup = function (itemDia) {
            alert($scope.ItemchildTerms.Item_Group.Group_Name, $scope.Item_Spec.Spec_Code, itemDia, "mm");
            //$scope.ItemchildTerms.Item_SchNo = $scope.ItemchildTerms
        };


        $scope.ItemchildPopup1 = function () {
          
            var modalInstance = $modal.open({
                templateUrl: 'Scripts/Master/ItemMaster/ItemChildPopup/ItemchildPopup.html',
                controller: 'ItemchildPopupCtrl',
                scope: $scope,
                resolve: {
                    gettype: function () {
                        return $scope.getTypeDetails
                    }
                }
            });
        };

    }
})(angular.module('common.core'));