﻿(function (app) {
    'use strict';
    app.controller('ItemchildPopupCtrl', ItemchildPopupCtrl);
    ItemchildPopupCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$route', '$modal', '$modalInstance'];
    function ItemchildPopupCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $route, $modal, $modalInstance) {

        $scope.ItemchildTerms = {};

        $scope.closePaymentTermsmodal = function closePaymentTermsmodal() {
            $modalInstance.close();
        };

        $scope.saveRMCodes = function saveRMCodes() {
       
            $scope.ItemchildTerms.tenant_id = $rootScope.tenant.tenant_id;
            apiService.post('api/ItemMaster/CreateItemChild', $scope.ItemchildTerms, saveRMCodesComplete, saveRmcodesFailed);
        };
        function saveRMCodesComplete(response) {
            notificationService.displaySuccess("RM Codes created Successfully");
            $scope.ItemchildTerms = {};
            apiService.get('api/ItemMaster/GetPaymentTermsList', null, rmCodesLoadComplete, rmCodesLoadFailed);
            $modalInstance.close();
        }
        function saveRmcodesFailed() {
            notificationService.displayError("Unable to Create RM Codes");
        }

        function rmCodesLoadComplete(response) {
            $rootScope.paymentTermsList = response.data;
            $modalInstance.close();
        }
        function rmCodesLoadFailed() {
            notificationService.displayError("Unable to Get RM Codes");
            $modalInstance.close();
        }

    }
})(angular.module('common.core'));