﻿(function (app) {
    'use strict';
    app.controller('activityReportCtrl', activityReportCtrl);
    activityReportCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function activityReportCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal) {

        $scope.activityReportList = [];
        $scope.activityReport = {};
        $scope.showform = false;
        $scope.showGrid = true;
        $scope.activityReport = {};

        $scope.showActivityReportform = function () {
            $scope.showForm = true;
            $scope.showGrid = false;
        };
        $scope.hideActivityReportform = function () {
            $scope.activityReport = {};
            $scope.showForm = false;
            $scope.showGrid = true;
        };

        LoadActivityReportList();
        function LoadActivityReportList() {
            apiService.get('api/ActivityReport/GetActivityReportList', null, activityReportLoadComplete, activityReportLoadFailed);
        };
        function activityReportLoadComplete(response) {
            $scope.activityReportList = response.data;
            if ($scope.activityReportList.length > 0) {
                $scope.showForm = false;
                $scope.showGrid = true;
            }
        }
        function activityReportLoadFailed(response) {
            notificationService.displayError("Unable to Get Activity report Data");
        }

        $scope.saveActivityReport = function saveActivityReport() {
            debugger;
            apiService.post('api/ActivityReport/CreateActivityReport', $scope.activityReport, saveActivityReportComplete, saveActivityReportFailed);
        };
        function saveActivityReportComplete(response) {
            notificationService.displaySuccess("Activity report created Successfully");
            $scope.activityReport = {};
            LoadActivityReportList();
        }
        function saveActivityReportFailed() {
            notificationService.displayError("Unable to Create Activity report");
            $scope.showForm = true;
            $scope.showGrid = false;
        }

        $scope.editCall = function (rowform) {
            if ($(".checkVisible").is(":visible")) {
                rowform.$cancel();
            }
            else {
                rowform.$show();
            }
        };

        $scope.updateUser = function (data, id) {
            angular.extend(data, { id: id });
            $scope.activityReport.id = data.id;
            $scope.activityReport.Activity_Code = data.arActivityCode;
            $scope.activityReport.Activity_Description = data.arDescription;
            $scope.activityReport.Activity_Part_No = data.arActivityPartNo;
            //$scope.activityReport.Actual_Completiondate = data.mmDescription;
            //$scope.activityReport.Actual_Duration = data.mmUserName;
            //$scope.activityReport.Actual_StartDate = data.mmDescription;
            //$scope.activityReport.Main_Work_Center = data.mmUserName;
            //$scope.activityReport.Part_Sl_No = data.mmDescription;
            //$scope.activityReport.Person_Rep = data.mmUserName;
            //$scope.activityReport.Planned_Duration = data.mmDescription;
            //$scope.activityReport.Planned_StartDate = data.mmUserName;
            //$scope.activityReport.Project_Code = data.mmDescription;
            //$scope.activityReport.Ref_Doc_No = data.mmUserName;
            //$scope.activityReport.Remarks = data.mmDescription;
            //$scope.activityReport.Report_No = data.mmDescription;
            //$scope.activityReport.Resion = data.mmUserName;
            //$scope.activityReport.Status = data.mmDescription;
            //$scope.activityReport.Work_Center = data.mmUserName;
           
            apiService.post('api/ActivityReport/UpdateActivityReport', $scope.activityReport, UpdateUserComplete, UpdateUserFailed);

        };
        function UpdateUserComplete() {
            notificationService.displaySuccess("Activity report Updated Successfully");
            LoadActivityReportList();
        }
        function UpdateUserFailed() {
            notificationService.displayError(" Activity report Update Failed !");
        }
        $scope.DeleteActivityReport = function (ar) {
            alertify.confirm("Delete", "Are You Sure to Delete Activity Report", function () {
                apiService.post('api/ActivityReport/DeleteActivityReport/' + ar.id, null, DeleteUserComplete, DeleteUserFailed);
            },
                function () { }).set('reverseButtons', false);
        }
        function DeleteUserComplete(response) {
            notificationService.displaySuccess('Deleted Successfully.');
            LoadActivityReportList();
        }
        function DeleteUserFailed(response) {
            notificationService.displayError(' Deleted  Failed !');
        }



    }
})(angular.module('common.core'));

   