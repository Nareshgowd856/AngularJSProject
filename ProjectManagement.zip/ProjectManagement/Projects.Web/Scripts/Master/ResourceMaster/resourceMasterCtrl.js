﻿(function (app) {
    'use strict';
    app.controller('resourceMasterCtrl', resourceMasterCtrl);
    resourceMasterCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function resourceMasterCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal) {

        $scope.resourceMasterList = [];
        $scope.resource = {};
        $scope.showform = false;
        $scope.showGrid = true;

        $scope.showResourceform = function () {
            $scope.showForm = true;
            $scope.showGrid = false;
        };
        $scope.hideResourceform = function () {
            $scope.resource = {};
            $scope.showForm = false;
            $scope.showGrid = true;
        };

        LoadresourceMasterList();
        function LoadresourceMasterList() {
            apiService.get('api/ResourceMaster/GetresourceMasterList', null, resourceMasterLoadComplete, resourceMasterLoadFailed);
        };
        function resourceMasterLoadComplete(response) {
            $scope.resourceMasterList = response.data;
            if ($scope.resourceMasterList.length > 0) {
                $scope.showForm = false;
                $scope.showGrid = true;
            }
        }
        function resourceMasterLoadFailed(response) {
            notificationService.displayError("Unable to Get Resource Master Data");
        }

        $scope.saveResourceform = function saveResourceform() {
            apiService.post('api/ResourceMaster/CreateResource', $scope.resourceMaster, saveResourceComplete, saveResourceFailed);
        };
        function saveResourceComplete(response) {
            notificationService.displaySuccess("Resource created Successfully");
            $scope.resourceMaster = {};
            LoadresourceMasterList();
        }
        function saveResourceFailed() {
            notificationService.displayError("Unable to Create Resource");
            $scope.showForm = true;
            $scope.showGrid = false;
        }



    }
})(angular.module('common.core'));


