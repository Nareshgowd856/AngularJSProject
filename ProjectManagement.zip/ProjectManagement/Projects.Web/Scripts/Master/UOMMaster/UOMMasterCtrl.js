﻿(function (app) {
    'use strict';
    app.controller('UOMMasterCtrl', UOMMasterCtrl);
    UOMMasterCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function UOMMasterCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal) {

        $scope.uomList = [];
        $scope.showform = false;
        $scope.showGrid = true;
        $scope.uomMaster = {};

        $scope.showUOMform = function () {
            $scope.showForm = true;
            $scope.showGrid = false;
        };
        $scope.hideUOMform = function () {
            $scope.uomMaster = {};
            $scope.showForm = false;
            $scope.showGrid = true;
        };



        LoadUOMList();
        function LoadUOMList() {
            apiService.get('api/UOMMaster/GetUOMList', null, uomLoadComplete, uomLoadFailed);
        };
        function uomLoadComplete(response) {
            $scope.uomList = response.data;
            if ($scope.uomList.length > 0) {
                $scope.showForm = false;
                $scope.showGrid = true;
            }
        }
        function uomLoadFailed(response) {
            notificationService.displayError("Unable to Get  Data");
        }

        $scope.saveUOM = function saveUOM() {
            apiService.post('api/UOMMaster/CreateUOM', $scope.uomMaster, saveUOMComplete, saveUOMFailed);
        };
        function saveUOMComplete(response) {
            notificationService.displaySuccess(" created Successfully");
            $scope.uomMaster = {};
            LoadUOMList();
        }
        function saveUOMFailed() {
            notificationService.displayError("Unable to Create ");
            $scope.showForm = true;
            $scope.showGrid = false;
        }
        $scope.editCall = function (rowform) {
            if ($(".checkVisible").is(":visible")) {
                rowform.$cancel();
            }
            else {
                rowform.$show();
            }
        };

        $scope.updateUser = function (data, id) {
            angular.extend(data, { id: id });
            $scope.uomMaster.id = data.id;
            $scope.uomMaster.UOM_Id = data.uomid;
            $scope.uomMaster.UOM_Name = data.uomname;
            apiService.post('api/UOMMaster/UpdateUOM', $scope.uomMaster, UpdateUserComplete, UpdateUserFailed);

        };
        function UpdateUserComplete() {
            notificationService.displaySuccess(" Updated Successfully");
            LoadUOMList();
        }
        function UpdateUserFailed() {
            notificationService.displayError("  Update Failed !");
        }
        $scope.DeleteUOM = function (uom) {
            alertify.confirm("Delete", "Are You Sure to Delete ", function () {
                apiService.post('api/UOMMaster/DeleteUOM/' + uom.id, null, DeleteUserComplete, DeleteUserFailed);
            },
                function () { }).set('reverseButtons', false);
        }
        function DeleteUserComplete(response) {
            notificationService.displaySuccess('Deleted Successfully.');
            LoadUOMList();
        }
        function DeleteUserFailed(response) {
            notificationService.displayError(' Deleted  Failed !');
        }

    }
})(angular.module('common.core'));