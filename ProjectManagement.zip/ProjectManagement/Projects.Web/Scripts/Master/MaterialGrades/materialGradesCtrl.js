﻿(function (app) {
    'use strict';
    app.controller('materialGradesCtrl', materialGradesCtrl);
    materialGradesCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function materialGradesCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal) {

        $scope.materialGradeList = [];
        $scope.materialGrade = {};
        $scope.showform = false;
        $scope.showGrid = true;

        $scope.showMaterialGradesForm = function () {
            $scope.showForm = true;
            $scope.showGrid = false;
        };
        $scope.hideMaterialGradeform = function () {
            $scope.materialGrade = {};
            $scope.showForm = false;
            $scope.showGrid = true;
        };

        LoadMaterialGradeList();
        function LoadMaterialGradeList() {
            apiService.get('api/MaterialGrade/GetMaterialGradeList', null, materialGradeLoadComplete, materialGradeLoadFailed);
        }
        function materialGradeLoadComplete(response) {
            $scope.materialGradeList = response.data;
            if ($scope.materialGradeList.length > 0) {
                $scope.showForm = false;
                $scope.showGrid = true;
            }
        }
        function materialGradeLoadFailed(response) {
            notificationService.displayError("Unable to Get Maters Grade Data");
        }

        $scope.saveMaterialGrade = function saveMaterialGrade() {
            debugger;
            $scope.materialGrade.tenant_id = $rootScope.tenant.tenant_id;
            $scope.materialGrade.Created_By = $rootScope.tenant.tenant_id;
            apiService.post('api/MaterialGrade/CreateMaterialGrade', $scope.materialGrade, saveMaterialGradeComplete, saveMaterialGradeFailed);
        };
        function saveMaterialGradeComplete(response) {
            notificationService.displaySuccess("Material Grade created Successfully");
            $scope.showForm = false;
            $scope.showGrid = true;
            $scope.materialGrade = {};
            LoadMaterialGradeList();
        }
        function saveMaterialGradeFailed() {
            notificationService.displayError("Unable to Create Material Grade");
            $scope.showForm = false;
            $scope.showGrid = true;
        }



    }
})(angular.module('common.core'));