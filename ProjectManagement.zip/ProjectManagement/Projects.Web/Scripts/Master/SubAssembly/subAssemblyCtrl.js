﻿(function (app) {
    'use strict';
    app.controller('subAssemblyCtrl', subAssemblyCtrl);
    subAssemblyCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function subAssemblyCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal) {

        $scope.subAssemblyMasterList = [];
        $scope.subAssemblyMaster = {};
        $scope.showform = false;
        $scope.showGrid = true;
        $scope.subAssembly = {};

        $scope.showSubAssemblyform = function () {
            $scope.showForm = true;
            $scope.showGrid = false;
        };
        $scope.hideSubAssemblyform = function () {
            $scope.subAssemblyMaster = {};
            $scope.showForm = false;
            $scope.showGrid = true;
        };

        LoadSubAssemblyMasterList();
        function LoadSubAssemblyMasterList() {
            apiService.get('api/SubAssembly/GetSubAssemblyMasterList', null, subAssemblyMasterLoadComplete, subAssemblyMasterLoadFailed);
        }
        function subAssemblyMasterLoadComplete(response) {
            $scope.subAssemblyMasterList = response.data;
            if ($scope.subAssemblyMasterList.length > 0) {
                $scope.showForm = false;
                $scope.showGrid = true;
            }
        }
        function subAssemblyMasterLoadFailed(response) {
            notificationService.displayError("Unable to Get Sub Assembly Data");
        }

        $scope.saveSubAssembly = function saveSubAssembly() {
            $scope.subAssemblyMaster.tenant_id = $rootScope.tenant.tenant_id;
            $scope.subAssemblyMaster.Created_By = $rootScope.tenant.tenant_id;
            apiService.post('api/SubAssembly/CreateSubAssembly', $scope.subAssemblyMaster, saveSubAssemblyComplete, saveSubAssemblyFailed);
        };
        function saveSubAssemblyComplete(response) {
            notificationService.displaySuccess("SubAssembly created Successfully");
            $scope.subAssemblyMaster = {};
            LoadSubAssemblyMasterList();
        }
        function saveSubAssemblyFailed() {
            notificationService.displayError("Unable to Create SubAssembly");
            $scope.showForm = true;
            $scope.showGrid = false;
        }

        $scope.editCall = function (rowform) {
            if ($(".checkVisible").is(":visible")) {
                rowform.$cancel();
            }
            else {
                rowform.$show();
            }
        };

        $scope.updateUser = function (data, id) {
            angular.extend(data, { id: id });
            $scope.subAssembly.id = data.id;
            $scope.subAssembly.Sub_Assembly_ID = data.saSubAssembly;
            $scope.subAssembly.Sub_Assembly_Name = data.saName;
            apiService.post('api/SubAssembly/UpdateSubAssembly', $scope.subAssembly, UpdateUserComplete, UpdateUserFailed);

        };
        function UpdateUserComplete() {
            notificationService.displaySuccess("SubAssembly Updated Successfully");
            LoadSubAssemblyMasterList();
        }
        function UpdateUserFailed() {
            notificationService.displayError(" Sub Assembly Update Failed !");
        }
        $scope.DeleteSubAssembly = function (sa) {
            alertify.confirm("Delete", "Are You Sure to Delete Sub Assembly", function () {
                apiService.post('api/SubAssembly/DeleteSubAssembly/' + sa.id, null, DeleteUserComplete, DeleteUserFailed);
            },
                function () { }).set('reverseButtons', false);
        }
        function DeleteUserComplete(response) {
            notificationService.displaySuccess('Deleted Successfully.');
            LoadSubAssemblyMasterList();
        }
        function DeleteUserFailed(response) {
            notificationService.displayError(' Deleted  Failed !');
        }

    }

    
})(angular.module('common.core'));