﻿(function (app) {
    'use strict';
    app.controller('activityCtrl', activityCtrl);
    activityCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function activityCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal) {

        $scope.activityMasterList = [];
        $scope.activityMaster = {};
        $scope.showform = false;
        $scope.showGrid = true;

        $scope.showactivityform = function () {
            $scope.showForm = true;
            $scope.showGrid = false;
        };
        $scope.hideactivityform = function () {
            $scope.activityMaster = {};
            $scope.showForm = false;
            $scope.showGrid = true;
        };

        LoadactivityMasterList();
        function LoadactivityMasterList() {
            apiService.get('api/Activity/GetActivityMasterList', null, activityMasterLoadComplete, activityMasterLoadFailed);
        };
        function activityMasterLoadComplete(response) {
            $scope.activityMasterList = response.data;
            if ($scope.activityMasterList.length > 0) {
                $scope.showForm = false;
                $scope.showGrid = true;
            }
        }
        function activityMasterLoadFailed(response) {
            notificationService.displayError("Unable to Get Maker Master Data");
        }

        $scope.saveactivity = function saveActivity() {
            apiService.post('api/ActivityMaster/CreateActivity', $scope.activityMaster, saveactivityComplete, saveactivityFailed);
        };
        function saveactivityComplete(response) {
            notificationService.displaySuccess("activity created Successfully");
            $scope.showForm = false;
            $scope.showGrid = true;
            $scope.activityMaster = {};
            LoadactivityMasterList();
        }
        function saveactivityFailed() {
            notificationService.displayError("Unable to Create activity");
            $scope.showForm = true;
            $scope.showGrid = false;
        }



    }
})(angular.module('common.core'));