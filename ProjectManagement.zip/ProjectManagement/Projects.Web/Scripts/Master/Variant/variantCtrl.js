﻿(function (app) {
    'use strict';
    app.controller('variantCtrl', variantCtrl);
    variantCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function variantCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal) {

        $scope.variantMasterList = [];
        $scope.variant = {};
        $scope.showform = false;
        $scope.showGrid = true;

        $scope.showVariantform = function () {
            $scope.showForm = true;
            $scope.showGrid = false;
        };
        $scope.hideVariantform = function () {
            $scope.variant = {};
            $scope.showForm = false;
            $scope.showGrid = true;
        };

        LoadvariantMasterList();
        function LoadvariantMasterList() {
            apiService.get('api/Variant/GetVariantMasterList', null, variantMasterLoadComplete, variantMasterLoadFailed);
        };
        function variantMasterLoadComplete(response) {
            $scope.variantMasterList = response.data;
            if ($scope.variantMasterList.length > 0) {
                $scope.showForm = false;
                $scope.showGrid = true;
            }
        }
        function variantMasterLoadFailed(response) {
            notificationService.displayError("Unable to Get Variant Master Data");
        }

        $scope.saveVariantform = function saveVariantform() {
            apiService.post('api/Variant/CreateVariant', $scope.variantMaster, saveVariantComplete, saveVariantFailed);
        };
        function saveVariantComplete(response) {
            notificationService.displaySuccess("Variant created Successfully");
            $scope.variantMaster = {};
            LoadvariantMasterList();
        }
        function saveVariantFailed() {
            notificationService.displayError("Unable to Create Variant");
            $scope.showForm = true;
            $scope.showGrid = false;
        }



    }
})(angular.module('common.core'));

       

