﻿(function (app) {
    'use strict';
    app.controller('currencyCtrl', currencyCtrl);
    currencyCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function currencyCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal) {

        $scope.currencyList = [];
        $scope.currency = {};
        $scope.showform = false;
        $scope.showGrid = true;
       

        $scope.showCurrencyform = function () {
            $scope.showForm = true;
            $scope.showGrid = false;
        };
        $scope.hideCurrencyform = function () {
            $scope.currency = {};
            $scope.showForm = false;
            $scope.showGrid = true;
        };

        LoadCurrencyList();
        function LoadCurrencyList() {
            apiService.get('api/Currency/GetCurrencyList', null, currencyLoadComplete, currencyLoadFailed);
        };
        function currencyLoadComplete(response) {
            $scope.currencyList = response.data;
            if ($scope.currencyList.length > 0) {
                $scope.showForm = false;
                $scope.showGrid = true;
            }
        }
        function currencyLoadFailed(response) {
            notificationService.displayError("Unable to Get  Data");
        }

        $scope.saveCurrency = function saveCurrency() {
            apiService.post('api/Currency/CreateCurrency', $scope.currency, saveCurrencyComplete, saveCurrencyFailed);
        };
        function saveCurrencyComplete(response) {
            notificationService.displaySuccess(" created Successfully");
            $scope.currency = {};
            LoadCurrencyList();
        }
        function saveCurrencyFailed() {
            notificationService.displayError("Unable to Create ");
            $scope.showForm = true;
            $scope.showGrid = false;
        }
        $scope.editCall = function (rowform) {
            if ($(".checkVisible").is(":visible")) {
                rowform.$cancel();
            }
            else {
                rowform.$show();
            }
        };

        $scope.updateUser = function (data, id) {
            angular.extend(data, { id: id });
            $scope.currency.id = data.id;
            $scope.currency.Currency_Id = data.clcid;
            $scope.currency.Currency_Name = data.clname;
            apiService.post('api/Currency/UpdateCurrency', $scope.currency, UpdateUserComplete, UpdateUserFailed);

        };
        function UpdateUserComplete() {
            notificationService.displaySuccess(" Updated Successfully");
            LoadCurrencyList();
        }
        function UpdateUserFailed() {
            notificationService.displayError("  Update Failed !");
        }
        $scope.DeleteCurrency = function (cl) {
            alertify.confirm("Delete", "Are You Sure to Delete ", function () {
                apiService.post('api/Currency/DeleteCurrency/' + cl.id, null, DeleteUserComplete, DeleteUserFailed);
            },
                function () { }).set('reverseButtons', false);
        }
        function DeleteUserComplete(response) {
            notificationService.displaySuccess('Deleted Successfully.');
            LoadCurrencyList();
        }
        function DeleteUserFailed(response) {
            notificationService.displayError(' Deleted  Failed !');
        }

    }
})(angular.module('common.core'));