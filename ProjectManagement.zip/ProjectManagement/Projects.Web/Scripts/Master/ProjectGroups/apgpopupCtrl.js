﻿(function (app) {
    'use strict';
    app.controller('apgPopupCtrl', apgPopupCtrl);
    apgPopupCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal', '$modalInstance'];
    function apgPopupCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal, $modalInstance) {

        $scope.apgMaster = {};
        $scope.SelectedAPGList = [];
        $scope.NewSelectedAPGList = [];
        $rootScope.SelectedAPG = [];

        $scope.closeAPGMastermodal = function closeAPGMastermodal() {
            $modalInstance.close();
        };
        LoadAPGMaster();
        function LoadAPGMaster() {
            apiService.get('api/APGMaster/GetAPGMasterList', null, apgMasterLoadComplete, apgMasterLoadFailed);
        }
        function apgMasterLoadComplete(response) {
            $scope.APGList = response.data;
            if ($rootScope.apgMasterList == undefined) {
                $scope.NewSelectedAPGList = $scope.APGList;
            } else {
                if ($rootScope.apgMasterList.length > 0) {
                    for (var i = 0; i < $scope.APGList.length; i++) {
                        for (var j = 0; j < $rootScope.apgMasterList.length; j++) {
                            if ($scope.APGList[i].id == $rootScope.apgMasterList[j].id) {
                                $scope.APGList[i].PSCheckbox = true;
                            }
                        }
                    }
                    $scope.NewSelectedAPGList = $scope.APGList;
                }
            }
        }
        function apgMasterLoadFailed() {
            notificationService.displayError("Unable to Get APG Master Data");
        }

        $scope.checkFunc = function (MMobject, isChecked) {
            if (isChecked) {
                for (var i = 0; i < $scope.NewSelectedAPGList.length; i++) {
                    if (MMobject.id == $scope.NewSelectedAPGList[i].id) {
                        $scope.NewSelectedAPGList[i].PSCheckbox = true;
                    }
                }
            } else {
                for (var i = 0; i < $scope.NewSelectedAPGList.length; i++) {
                    if (MMobject.id == $scope.NewSelectedAPGList[i].id) {
                        $scope.NewSelectedAPGList[i].PSCheckbox = false;
                    }
                }
            }
        };

        $scope.saveAPGList = function () {
            $rootScope.apgMasterList = [];
            for (var i = 0; i < $scope.NewSelectedAPGList.length; i++) {
                if ($scope.NewSelectedAPGList[i].PSCheckbox == true) {
                    $rootScope.apgMasterList.push($scope.NewSelectedAPGList[i]);
                }
            }
            if ($rootScope.apgMasterList.length > 0) {
                $modalInstance.close();
            } else {
                notificationService.displayError("Please check atleast one APG");
            }
        };


    }
})(angular.module('common.core'));