﻿(function (app) {
    'use strict';
    app.controller('makersPopupCtrl', makersPopupCtrl);
    makersPopupCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal', '$modalInstance'];
    function makersPopupCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal, $modalInstance) {

        $scope.makerMaster = {};
        $scope.SelectedMakerList = [];
        $scope.NewSelectedMakerList = [];
        $rootScope.SelectedMakers = [];        

        $scope.closeMakerMastermodal = function closeMakerMastermodal() {
            $modalInstance.close();
        };
        LoadMakerMaster();
        function LoadMakerMaster() {
            apiService.get('api/MakerMaster/GetMakerMasterList', null, makerMasterLoadComplete, makerMasterLoadFailed);
        }
        function makerMasterLoadComplete(response) {
            $scope.MakerList = response.data;
            if ($rootScope.makerMasterList == undefined) {
                $scope.NewSelectedMakerList = $scope.MakerList;
            } else {
                if ($rootScope.makerMasterList.length > 0) {
                    for (var i = 0; i < $scope.MakerList.length; i++) {
                        for (var j = 0; j < $rootScope.makerMasterList.length; j++) {
                            if ($scope.MakerList[i].id == $rootScope.makerMasterList[j].id) {
                                $scope.MakerList[i].PCCheckbox = true;
                            }
                        }
                    }
                    $scope.NewSelectedMakerList = $scope.MakerList;
                }
            }
        }
        function makerMasterLoadFailed() {
            notificationService.displayError("Unable to Get Maker Master Data");
        }

        $scope.checkFunc = function (MMobject, isChecked) {
            if (isChecked) {
                for (var i = 0; i < $scope.NewSelectedMakerList.length; i++) {
                    if (MMobject.id == $scope.NewSelectedMakerList[i].id) {
                        $scope.NewSelectedMakerList[i].PCCheckbox = true;
                    }
                }
            } else {
                for (var i = 0; i < $scope.NewSelectedMakerList.length; i++) {
                    if (MMobject.id == $scope.NewSelectedMakerList[i].id) {
                        $scope.NewSelectedMakerList[i].PCCheckbox = false;
                    }
                }
            }
        };

        $scope.saveMakersList = function () {
            $rootScope.makerMasterList = [];
            for (var i = 0; i < $scope.NewSelectedMakerList.length; i++) {
                if ($scope.NewSelectedMakerList[i].PCCheckbox == true) {
                    $rootScope.makerMasterList.push($scope.NewSelectedMakerList[i]);
                }
            }
            if ($rootScope.makerMasterList.length > 0) {
                $modalInstance.close();
            } else {
                notificationService.displayError("Please check atleast one maker");
            }
        };


    }
})(angular.module('common.core'));