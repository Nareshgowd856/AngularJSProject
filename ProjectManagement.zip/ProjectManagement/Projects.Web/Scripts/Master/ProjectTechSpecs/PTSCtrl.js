﻿(function (app) {
    'use strict';
    app.controller('ptsCtrl', ptsCtrl);
    ptsCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function ptsCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal) {

        $scope.ptsList = [];
        $scope.pts = {};
        $scope.showform = false;
        $scope.showGrid = true;


        $scope.showPtsform = function () {
            $scope.showForm = true;
            $scope.showGrid = false;
        };
        $scope.hidePtsform = function () {
            $scope.pts = {};
            $scope.showForm = false;
            $scope.showGrid = true;
        };

        LoadPtsList();
        function LoadPtsList() {
            apiService.get('api/PTS/GetPTSList', null, ptsLoadComplete, ptsLoadFailed);
        };
        function ptsLoadComplete(response) {
            $scope.ptsList = response.data;
            if ($scope.ptsList.length > 0) {
                $scope.showForm = false;
                $scope.showGrid = true;
            }
        }
        function ptsLoadFailed(response) {
            notificationService.displayError("Unable to Get  Data");
        }

        $scope.savePts = function savePts() {
            apiService.post('api/PTS/CreatePTS', $scope.pts, savePtsComplete, savePtsFailed);
        };
        function savePtsComplete(response) {
            notificationService.displaySuccess(" created Successfully");
            $scope.pts = {};
            LoadPtsList();
        }
        function savePtsFailed() {
            notificationService.displayError("Unable to Create ");
            $scope.showForm = true;
            $scope.showGrid = false;
        }
        $scope.editCall = function (rowform) {
            if ($(".checkVisible").is(":visible")) {
                rowform.$cancel();
            }
            else {
                rowform.$show();
            }
        };

        $scope.updateUser = function (data, id) {
            angular.extend(data, { id: id });
            $scope.pts.id = data.id;
            $scope.pts.Currency_Id = data.ptsid;
            $scope.pts.Currency_Name = data.ptsname;
            apiService.post('api/PTS/UpdatePTS', $scope.pts, UpdateUserComplete, UpdateUserFailed);

        };
        function UpdateUserComplete() {
            notificationService.displaySuccess(" Updated Successfully");
            LoadPtsList();
        }
        function UpdateUserFailed() {
            notificationService.displayError("  Update Failed !");
        }
        $scope.DeletePTS = function (pts) {
            alertify.confirm("Delete", "Are You Sure to Delete ", function () {
                apiService.post('api/PTS/DeletePTS/' + pts.id, null, DeleteUserComplete, DeleteUserFailed);
            },
                function () { }).set('reverseButtons', false);
        }
        function DeleteUserComplete(response) {
            notificationService.displaySuccess('Deleted Successfully.');
            LoadPtsList();
        }
        function DeleteUserFailed(response) {
            notificationService.displayError(' Deleted  Failed !');
        }

    }
})(angular.module('common.core'));