﻿(function (app) {
    'use strict';
    app.controller('workCenterCtrl', workCenterCtrl);
    workCenterCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function workCenterCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal) {

        $scope.workCenterList = [];
        $scope.workCenter = {};
        $scope.showform = false;
        $scope.showGrid = true;
        $scope.workCenter = {};

        $scope.showWorkCenterform = function () {
            $scope.showForm = true;
            $scope.showGrid = false;
        };
        $scope.hideWorkCenterform = function () {
            $scope.workCenter = {};
            $scope.showForm = false;
            $scope.showGrid = true;
        };

        LoadWorkCenterList();
        function LoadWorkCenterList() {
            apiService.get('api/WorkCenter/GetWorkCenterList', null, workCenterLoadComplete, workCenterLoadFailed);
        }
        function workCenterLoadComplete(response) {
            $scope.workCenterList = response.data;
            if ($scope.workCenterList.length > 0) {
                $scope.showForm = false;
                $scope.showGrid = true;
            }
        }
        function workCenterLoadFailed(response) {
            notificationService.displayError("Unable to Get Work Center Data");
        }

        $scope.saveWorkCenter = function saveWorkCenter() {
            $scope.workCenter.tenant_id = $rootScope.tenant.tenant_id;
            $scope.workCenter.Created_By = $rootScope.tenant.tenant_id;
            apiService.post('api/WorkCenter/CreateWorkCenter', $scope.workCenter, saveWorkCenterComplete, saveWorkCenterFailed);
        };
        function saveWorkCenterComplete(response) {
            notificationService.displaySuccess("Work Center created Successfully");
            $scope.showForm = false;
            $scope.showGrid = true;
            $scope.workCenter = {};
            LoadWorkCenterList();
        }
        function saveWorkCenterFailed() {
            notificationService.displayError("Unable to Create WorkCenter");
            $scope.showForm = false;
            $scope.showGrid = true;
        }
        $scope.editCall = function (rowform) {
            if ($(".checkVisible").is(":visible")) {
                rowform.$cancel();
            }
            else {
                rowform.$show();
            }
        };

        $scope.updateUser = function (data, id) {
            angular.extend(data, { id: id });
            $scope.workCenter.id = data.id;
            $scope.workCenter.Work_Center_id = data.wcWorkCenter;
            $scope.workCenter.Work_Center = data.wcName;
            apiService.post('api/WorkCenter/UpdateWorkCenter', $scope.workCenter, UpdateUserComplete, UpdateUserFailed);

        };
        function UpdateUserComplete() {
            notificationService.displaySuccess("Work Center Updated Successfully");
            LoadWorkCenterList();
        }
        function UpdateUserFailed() {
            notificationService.displayError(" Work Center Update Failed !");
        }
        $scope.DeleteWorkCenter = function (wc) {
            alertify.confirm("Delete", "Are You Sure to Delete Work Center", function () {
                apiService.post('api/WorkCenter/DeleteWorkCenter/' + wc.id, null, DeleteUserComplete, DeleteUserFailed);
            },
                function () { }).set('reverseButtons', false);
        }
        function DeleteUserComplete(response) {
            notificationService.displaySuccess('Deleted Successfully.');
            LoadWorkCenterList();
        }
        function DeleteUserFailed(response) {
            notificationService.displayError(' Deleted  Failed !');
        }



    }
})(angular.module('common.core'));