﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class ProjectTechSpecsEntityExtension
    {
        public static void AddPTS(this tbl_Project_Tech_Specs pts, ProjectTechSpecsViewModel ptsvm)
        {
            pts.tenant_id = ptsvm.tenant_id;
            pts.ProjectTechSpecs_Id = ptsvm.ProjectTechSpecs_Id;
            pts.ProjectTechSpecs_Name = ptsvm.ProjectTechSpecs_Name;
            pts.CompID = ptsvm.CompID;
            pts.Created_On = DateTime.Now;
            pts.Created_By = ptsvm.Created_By;
            pts.Modified_On = DateTime.Now;
            pts.Modified_By = ptsvm.Modified_By;
        }
    }
}