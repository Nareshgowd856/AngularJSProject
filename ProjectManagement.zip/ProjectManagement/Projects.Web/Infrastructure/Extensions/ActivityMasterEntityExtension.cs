﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class ActivityMasterEntityExtension
    {
        public static void AddActivityMaster(this tbl_Activity_Master activityMaster, ActivityMasterViewModel activityMasterVm)
        {
            activityMaster.tenant_id = activityMasterVm.tenant_id;
            activityMaster.Activity_Code = activityMasterVm.Activity_Code;
            activityMaster.Activity_Description = activityMasterVm.Activity_Description;
            activityMaster.Activity_Document = activityMasterVm.Activity_Document;
            activityMaster.Activity_Exe_Time = activityMasterVm.Activity_Exe_Time;
            activityMaster.CompID = activityMasterVm.CompID;
            activityMaster.Activity_Group = activityMasterVm.Activity_Group;
            activityMaster.Activity_Level = activityMasterVm.Activity_Level;
            activityMaster.Activity_Predessor = activityMasterVm.Activity_Predessor;
            activityMaster.Created_On = DateTime.Now;
            activityMaster.Created_By = activityMasterVm.Created_By;
            activityMaster.Modified_on = DateTime.Now;
            activityMaster.Modified_By = activityMasterVm.Modified_By;
            activityMaster.Activity_Predessor = activityMasterVm.CompID;
            activityMaster.Activity_Type = activityMasterVm.Activity_Type;
            activityMaster.Applicable_Equipments = activityMasterVm.Applicable_Equipments;
            activityMaster.C_Duration_Day = activityMasterVm.C_Duration_Day;
            activityMaster.Duration_Time = activityMasterVm.Duration_Time;
            activityMaster.Intermediate_Activity = activityMasterVm.Intermediate_Activity;
            activityMaster.Resp_Dept = activityMasterVm.Resp_Dept;
            activityMaster.Time_Unit = activityMasterVm.Time_Unit;
        }
    }
}