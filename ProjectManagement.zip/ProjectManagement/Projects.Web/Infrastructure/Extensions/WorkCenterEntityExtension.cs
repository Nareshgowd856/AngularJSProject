﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class WorkCenterEntityExtension
    {
        public static void AddWorkCenter(this tbl_WorkCenter workCenter, WorkCenterViewModel workCenterVm)
        {
            workCenter.tenant_id = workCenterVm.tenant_id;
            workCenter.Work_Center = workCenterVm.Work_Center;
            workCenter.Work_Center_id = workCenterVm.Work_Center_id;
            workCenter.CompID = workCenterVm.CompID;
            workCenter.Created_On = DateTime.Now;
            workCenter.Created_By = workCenterVm.Created_By;
            workCenter.Modified_On = DateTime.Now;
            workCenter.Modified_By = workCenterVm.Modified_By;
        }
    }
}