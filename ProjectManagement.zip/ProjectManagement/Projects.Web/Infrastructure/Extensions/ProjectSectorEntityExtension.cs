﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class ProjectSectorEntityExtension
    {
        public static void AddProjectSector(this tbl_ProjectSector_Master sector, ProjectSectorViewModel sectorvm)
        {
            sector.tenant_id = sectorvm.tenant_id;
            sector.Sector_Id = sectorvm.Sector_Id;
            sector.Sector_Name = sectorvm.Sector_Name;
            sector.CompID = sectorvm.CompID;
            sector.Created_On = DateTime.Now;
            sector.Created_By = sectorvm.Created_By;
            sector.Modified_On = DateTime.Now;
            sector.Modified_By = sectorvm.Modified_By;
        }
    }
}