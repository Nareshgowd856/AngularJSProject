﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class CurrencyEntityExtension
    {
        public static void AddCurrency(this tbl_Currency currency, CurrencyViewModel currencyvm)
        {
            currency.tenant_id = currencyvm.tenant_id;
            currency.Currency_Id = currencyvm.Currency_Id;
            currency.Currency_Name = currencyvm.Currency_Name;
            currency.CompID = currencyvm.CompID;
            currency.Created_On = DateTime.Now;
            currency.Created_By = currencyvm.Created_By;
            currency.Modified_On = DateTime.Now;
            currency.Modified_By = currencyvm.Modified_By;
        }
    }
}