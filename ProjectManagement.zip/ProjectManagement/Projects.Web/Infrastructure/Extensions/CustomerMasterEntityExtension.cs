﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class CustomerMasterEntityExtension
    {
        public static void AddCustomerMaster(this tbl_Customer_Master customerMaster, CustomerMasterViewModel customerMastervm)
        {
            customerMaster.tenant_id = customerMastervm.tenant_id;
            customerMaster.Customer_Id = customerMastervm.Customer_Id;
            customerMaster.Customer_Name = customerMastervm.Customer_Name;
            customerMaster.CompID = customerMastervm.CompID;
            customerMaster.Created_On = DateTime.Now;
            customerMaster.Created_By = customerMastervm.Created_By;
            customerMaster.Modified_On = DateTime.Now;
            customerMaster.Modified_By = customerMastervm.Modified_By;
        }
    }
}