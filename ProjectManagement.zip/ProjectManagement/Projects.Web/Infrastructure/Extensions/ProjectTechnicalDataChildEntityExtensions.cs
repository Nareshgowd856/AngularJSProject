﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class ProjectTechnicalDataChildEntityExtensions
    {
        public static void AddTechnicaldatachild(this tbl_project_technical_data_child technicalDataChild, ProjectTechnicalDataChildViewModel technicalDataChildVm)
        {
            technicalDataChild.tenant_id = technicalDataChildVm.tenant_id;
            technicalDataChild.Project_Code = technicalDataChildVm.Project_Code;
            technicalDataChild.Mile_Stone = technicalDataChildVm.Mile_Stone;
            technicalDataChild.Per_Payments = technicalDataChildVm.Per_Payments;
            technicalDataChild.TriggeringPoint = technicalDataChildVm.TriggeringPoint;
            technicalDataChild.CompID = technicalDataChildVm.CompID;
            technicalDataChild.Created_On = DateTime.Now;
            technicalDataChild.Created_By = technicalDataChildVm.Created_By;
            technicalDataChild.Modified_On = DateTime.Now;
            technicalDataChild.Modified_By = technicalDataChildVm.Modified_By;
        }
    }
}