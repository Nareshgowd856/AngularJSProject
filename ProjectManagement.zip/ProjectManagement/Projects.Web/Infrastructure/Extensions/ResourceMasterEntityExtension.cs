﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class ResourceMasterEntityExtension
    {
        public static void AddResourceMaster(this tbl_Resource_Master resourceMaster, ResourceMasterViewModel resourceMasterVm)
        {
            resourceMaster.tenant_id = resourceMasterVm.tenant_id;
            resourceMaster.Resource_Id = resourceMasterVm.Resource_Id;
            resourceMaster.Resource_Name = resourceMasterVm.Resource_Name;
            resourceMaster.Skill_Set = resourceMasterVm.Skill_Set;
            resourceMaster.CompID = resourceMasterVm.CompID;
            resourceMaster.Created_On = DateTime.Now;
            resourceMaster.Created_By = resourceMasterVm.Created_By;
            resourceMaster.Modified_On = DateTime.Now;
            resourceMaster.Modified_By = resourceMasterVm.Modified_By;
        }
    }
}