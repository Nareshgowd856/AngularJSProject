﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class MakerMasterEntityExtension
    {
        public static void AddMakerMaster(this tbl_Maker_Master makerMaster, MakerMasterViewModel makerMasterVm)
        {
            makerMaster.tenant_id = makerMasterVm.tenant_id;
            makerMaster.Maker_Description = makerMasterVm.Maker_Description;
            makerMaster.Maker_No = makerMasterVm.Maker_No;
            makerMaster.Created_On = DateTime.Now;
            makerMaster.Created_By = makerMasterVm.Created_By;
            makerMaster.Modified_On = DateTime.Now;
            makerMaster.Modified_By = makerMasterVm.Modified_By;
        }
    }
}