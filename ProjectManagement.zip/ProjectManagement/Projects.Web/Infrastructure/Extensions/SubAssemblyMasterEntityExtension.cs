﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class SubAssemblyMasterEntityExtension
    {
        public static void AddSubAssemblyMaster(this tbl_SubAssembly_Master subAssembly, SubAssemblyMasterViewModel subAssemblyVm)
        {
            subAssembly.tenant_id = subAssemblyVm.tenant_id;
            subAssembly.Sub_Assembly_ID = subAssemblyVm.Sub_Assembly_ID;
            subAssembly.Sub_Assembly_Name = subAssemblyVm.Sub_Assembly_Name;
            subAssembly.GroupName = subAssemblyVm.GroupName;
            subAssembly.CompID = subAssemblyVm.CompID;
            subAssembly.Created_On = DateTime.Now;
            subAssembly.Created_By = subAssemblyVm.Created_By;
            subAssembly.Modified_On = DateTime.Now;
            subAssembly.Modified_By = subAssemblyVm.Modified_By;
        }
    }
}