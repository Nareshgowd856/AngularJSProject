﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class GroupMasterEntityExtension
    {
        public static void AddGroupMaster(this tbl_Group_Master groupMaster, GroupMasterViewModel groupMasterVm)
        {
            groupMaster.tenant_id = groupMasterVm.tenant_id;
            groupMaster.Group_Id= groupMasterVm.Group_Id;
            groupMaster.Group_Name = groupMasterVm.Group_Name;
            groupMaster.Created_On = DateTime.Now;
            groupMaster.Created_By = groupMasterVm.Created_By;
            groupMaster.Modified_On = DateTime.Now;
            groupMaster.Modified_By = groupMasterVm.Modified_By;
            groupMaster.Group_Prefix = groupMasterVm.Group_Prefix;
        }
    }
}