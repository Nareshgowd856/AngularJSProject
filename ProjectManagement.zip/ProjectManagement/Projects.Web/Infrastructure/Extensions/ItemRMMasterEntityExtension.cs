﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class ItemRMMasterEntityExtension
    {
        public static void AddItemRMMaster(this tbl_Item_RM_Master itemRMMaster, ItemRMMasterViewModel itemRMMasterVm)
        {
            itemRMMaster.tenant_id = itemRMMasterVm.tenant_id;
            itemRMMaster.Item_BOM_Req = itemRMMasterVm.Item_BOM_Req;
            itemRMMaster.Item_Critical_Item = itemRMMasterVm.Item_Critical_Item;
            itemRMMaster.Item_Group = itemRMMasterVm.Item_Group;
            itemRMMaster.Item_Iss_UOM = itemRMMasterVm.Item_Iss_UOM;
            itemRMMaster.CompID = itemRMMasterVm.CompID;
            itemRMMaster.Item_PTS = itemRMMasterVm.Item_PTS;
            itemRMMaster.Item_Pur_UOM = itemRMMasterVm.Item_Pur_UOM;
            itemRMMaster.Item_ShelfLife = itemRMMasterVm.Item_ShelfLife;
            itemRMMaster.Item_Spec = itemRMMasterVm.Item_Spec;
            itemRMMaster.Item_Type = itemRMMasterVm.Item_Type;
            itemRMMaster.Created_On = DateTime.Now;
            itemRMMaster.Created_By = itemRMMasterVm.Created_By;
            itemRMMaster.Modified_On = DateTime.Now;
            itemRMMaster.Modified_By = itemRMMasterVm.Modified_By;
        }
    }
}