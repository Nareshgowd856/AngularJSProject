﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class ActivityCheckEntityExtension
    {
        public static void AddActivityCheck(this tbl_Activity_Check activityCheck, ActivityCheckViewModel ActivityCheckAc)
        {
            activityCheck.tenant_id = ActivityCheckAc.tenant_id;
            activityCheck.Applicable_Equipmnts = ActivityCheckAc.Applicable_Equipmnts;
            activityCheck.Created_On = DateTime.Now;
            activityCheck.Created_By = ActivityCheckAc.Created_By;
            activityCheck.Modified_On = DateTime.Now;
            activityCheck.Modified_By = ActivityCheckAc.Modified_By;
        }
    }
}