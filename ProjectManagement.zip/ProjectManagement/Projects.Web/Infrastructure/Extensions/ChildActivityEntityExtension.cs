﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class ChildActivityEntityExtension
    {
        public static void AddChildActivity(this tbl_Child_Activity childActivity, ChildActivityViewModel childActivityVm)
        {
            childActivity.tenant_id = childActivityVm.tenant_id;
            childActivity.Activity_Master_Id = childActivityVm.Activity_Master_Id;
            childActivity.ActivityCode = childActivityVm.ActivityCode;
            childActivity.Applicable_No = childActivityVm.Applicable_No;
            childActivity.Execution_Duration_Date = childActivityVm.Execution_Duration_Date;
            childActivity.CompID = childActivityVm.CompID;
            childActivity.Description = childActivityVm.Description;
            childActivity.Execution_Duration_Time = childActivityVm.Execution_Duration_Time;
            childActivity.Created_On = DateTime.Now;
            childActivity.Created_By = childActivityVm.Created_By;
            childActivity.Modified_On =  DateTime.Now;
            childActivity.Modified_By = childActivityVm.Modified_By;
        }
    }
}