﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class MaterialGradesEntityExtension
    {
        public static void AddMaterialGrades(this tbl_Material_Grades materialGrades, MaterialGradesViewModel materialGradesVm)
        {
            materialGrades.tenant_id = materialGradesVm.tenant_id;
            materialGrades.Material_Color = materialGradesVm.Material_Color;
            materialGrades.Material_Density = materialGradesVm.Material_Density;
            materialGrades.Material_Grad = materialGradesVm.Material_Grad;
            materialGrades.Material_Group = materialGradesVm.Material_Group;
            materialGrades.CompID = materialGradesVm.CompID;
            materialGrades.Spec_Code = materialGradesVm.Spec_Code;
            materialGrades.Created_On = DateTime.Now;
            materialGrades.Created_By = materialGradesVm.Created_By;
            materialGrades.Modified_On = DateTime.Now;
            materialGrades.Modified_By = materialGradesVm.Modified_By;
            materialGrades.Material_Group_Prefix = materialGradesVm.Material_Group_Prefix;
        }
    }
}