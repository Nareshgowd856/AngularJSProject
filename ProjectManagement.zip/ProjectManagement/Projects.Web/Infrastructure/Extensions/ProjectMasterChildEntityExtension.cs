﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class ProjectMasterChildEntityExtension
    {
        public static void AddProjectMaster(this tbl_project_master_child projectMasterChild, ProjectMasterChildViewModel projectMasterChildVm)
        {
            projectMasterChild.tenant_id = projectMasterChildVm.tenant_id;
            projectMasterChild.Project_Code = projectMasterChildVm.Project_Code;
            projectMasterChild.APG_Name = projectMasterChildVm.APG_Name;
            projectMasterChild.APG_No = projectMasterChildVm.APG_No;
            projectMasterChild.Full_Project_Code = projectMasterChildVm.Full_Project_Code;
            projectMasterChild.CompID = projectMasterChildVm.CompID;
            projectMasterChild.Maker_No = projectMasterChildVm.Maker_No;
            projectMasterChild.Project_Equp_Name = projectMasterChildVm.Project_Equp_Name;
            projectMasterChild.Created_On = DateTime.Now;
            projectMasterChild.Created_By = projectMasterChildVm.Created_By;
            projectMasterChild.Modified_On = DateTime.Now;
            projectMasterChild.Modified_By = projectMasterChildVm.Modified_By;
        }
    }
}