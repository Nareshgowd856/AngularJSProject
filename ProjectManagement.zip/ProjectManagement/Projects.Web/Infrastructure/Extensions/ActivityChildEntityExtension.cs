﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class ActivityChildEntityExtension
    {
        public static void AddActivityChild(this tbl_Activity_Child activityChild, ActivityChildViewModel activityChildVm)
        {
            activityChild.tenant_id = activityChildVm.tenant_id;
            activityChild.Activity_Code = activityChildVm.Activity_Code;
            activityChild.Activity_Res_Id = activityChildVm.Activity_Res_Id;
            activityChild.Act_Res_Skill_Level = activityChildVm.Act_Res_Skill_Level;
            activityChild.Act_Noof_Res = activityChildVm.Act_Noof_Res;
            activityChild.CompID = activityChildVm.CompID;
            activityChild.Act_Res_Cost = activityChildVm.Act_Res_Cost;
            activityChild.Created_On = DateTime.Now;
            activityChild.Created_By = activityChildVm.Created_By;
            activityChild.Modified_On = DateTime.Now;
            activityChild.Modified_By = activityChildVm.Modified_By;
        }
    }
}