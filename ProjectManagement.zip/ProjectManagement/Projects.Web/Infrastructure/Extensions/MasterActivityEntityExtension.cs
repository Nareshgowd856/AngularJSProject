﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class MasterActivityEntityExtension
    {
        public static void AddMasterActivity(this tbl_Master_Activity masterActivity, MasterActivityViewModel masterActivityVm)
        {
            masterActivity.tenant_id = masterActivityVm.tenant_id;
            masterActivity.Activity_Code = masterActivityVm.Activity_Code;
            masterActivity.Activity_Description = masterActivityVm.Activity_Description;
            masterActivity.Activity_Document = masterActivityVm.Activity_Document;
            masterActivity.Activity_Exe_Time = masterActivityVm.Activity_Exe_Time;
            masterActivity.CompID = masterActivityVm.CompID;
            masterActivity.Activity_Group = masterActivityVm.Activity_Group;
            masterActivity.Activity_Level = masterActivityVm.Activity_Level;
            masterActivity.Activity_Type = masterActivityVm.Activity_Type;
            masterActivity.Applicable_Equipments = masterActivityVm.Applicable_Equipments;
            masterActivity.Activity_Predessor = masterActivityVm.Activity_Predessor;
            masterActivity.Resp_Dept = masterActivityVm.Resp_Dept;
            masterActivity.Time_Unit = masterActivityVm.Time_Unit;
            masterActivity.Created_On = DateTime.Now;
            masterActivity.Created_By = masterActivityVm.Created_By;
            masterActivity.Modified_On = DateTime.Now;
            masterActivity.Modified_By = masterActivityVm.Modified_By;
        }
    }
}