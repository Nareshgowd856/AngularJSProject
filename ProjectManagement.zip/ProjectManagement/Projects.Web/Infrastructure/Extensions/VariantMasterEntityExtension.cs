﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class VariantMasterEntityExtension
    {
        public static void AddVariantMaster(this tbl_Variant_Master variantMaster, VariantMasterViewModel variantMasterVm)
        {
            variantMaster.tenant_id = variantMasterVm.tenant_id;
            variantMaster.Variant_ID = variantMasterVm.Variant_ID;
            variantMaster.Variant_Name = variantMasterVm.Variant_Name;
            variantMaster.Sub_Assembly_Name = variantMasterVm.Sub_Assembly_Name;
            variantMaster.CompID = variantMasterVm.CompID;
            variantMaster.Created_On = DateTime.Now;
            variantMaster.Created_By = variantMasterVm.Created_By;
            variantMaster.Modified_On = DateTime.Now;
            variantMaster.Modified_By = variantMasterVm.Modified_By;
        }
    }
}