﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class ActivityReportEntityExtension
    {
        public static void AddActivityReport(this tbl_Activity_Report activityReport, ActivityReportViewModel activityReportVm)
        {
            activityReport.tenant_id = activityReportVm.tenant_id;
            activityReport.Activity_Code = activityReportVm.Activity_Code;
            activityReport.Report_No = activityReportVm.Report_No;
            activityReport.Activity_Description = activityReportVm.Activity_Description;
            activityReport.Activity_Part_No = activityReportVm.Activity_Part_No;
            activityReport.CompID = activityReportVm.CompID;
            activityReport.Actual_Completiondate = activityReportVm.Actual_Completiondate;
            activityReport.Actual_Duration = activityReportVm.Actual_Duration;
            activityReport.Actual_StartDate = activityReportVm.Actual_StartDate;
            activityReport.Activity_Description = activityReportVm.Activity_Description;
            activityReport.Activity_Part_No = activityReportVm.Activity_Part_No;
            activityReport.Main_Work_Center = activityReportVm.Main_Work_Center;
            activityReport.Part_Sl_No = activityReportVm.Part_Sl_No;
            activityReport.PartList_No = activityReportVm.PartList_No;
            activityReport.Created_On = DateTime.Now;
            activityReport.Created_By = activityReportVm.Created_By;
            activityReport.Modified_On = DateTime.Now;
            activityReport.Modified_By = activityReportVm.Modified_By;
        }
    }
}