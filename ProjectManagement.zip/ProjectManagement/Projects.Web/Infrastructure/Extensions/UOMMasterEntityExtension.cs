﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class UOMMasterEntityExtension
    {
        public static void AddUOMMaster(this tbl_UOM_Master uomMaster, UOMMasterViewModel uomMastervm)
        {
            uomMaster.tenant_id = uomMastervm.tenant_id;
            uomMaster.UOM_Id = uomMastervm.UOM_Id;
            uomMaster.UOM_Name = uomMastervm.UOM_Name;
            uomMaster.Created_On = DateTime.Now;
            uomMaster.Created_By = uomMastervm.Created_By;
            uomMaster.Modified_On = DateTime.Now;
            uomMaster.Modified_By = uomMastervm.Modified_By;
        }
    }
}