﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Models
{
    public class ProjectVersionHistoryViewModel
    {
        public int id { get; set; }
        public int tenant_id { get; set; }
        public string Project_Code { get; set; }
        public string Version_No { get; set; }
        public Nullable<System.DateTime> Version_Date { get; set; }
        public string Version_Change { get; set; }
        public string DCN_No { get; set; }
        public string Reviewed_By { get; set; }
        public string Approved_By { get; set; }
        public string CompID { get; set; }
        public string Created_By { get; set; }
        public Nullable<System.DateTime> Created_On { get; set; }
        public string Modified_By { get; set; }
        public Nullable<System.DateTime> Modified_On { get; set; }
    }
}