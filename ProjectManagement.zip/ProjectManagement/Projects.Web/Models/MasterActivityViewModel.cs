﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Models
{
    public class MasterActivityViewModel
    {
        public int id { get; set; }
        public int tenant_id { get; set; }
        public string Activity_Code { get; set; }
        public string Activity_Description { get; set; }
        public string Activity_Group { get; set; }
        public string Activity_Document { get; set; }
        public string Activity_Type { get; set; }
        public string Activity_Predessor { get; set; }
        public string Activity_Exe_Time { get; set; }
        public string CompID { get; set; }
        public string Created_By { get; set; }
        public Nullable<System.DateTime> Created_On { get; set; }
        public string Modified_By { get; set; }
        public Nullable<System.DateTime> Modified_on { get; set; }
        public string Activity_Level { get; set; }
        public string Time_Unit { get; set; }
        public string Resp_Dept { get; set; }
        public string Applicable_Equipments { get; set; }

    }
}