﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Models
{
    public class ChildActivityViewModel
    {
        public int id { get; set; }
        public int tenant_id { get; set; }
        public string ActivityCode { get; set; }
        public string Description { get; set; }
        public Nullable<System.DateTime> Execution_Duration_Date { get; set; }
        public Nullable<System.DateTime> Execution_Duration_Time { get; set; }
        public Nullable<int> Applicable_No { get; set; }
        public string CompID { get; set; }
        public string Created_By { get; set; }
        public Nullable<System.DateTime> Created_On { get; set; }
        public string Modified_By{ get; set; }
        public Nullable<System.DateTime> Modified_On { get; set; }
        public string Activity_Master_Id { get; set; }
    }
}