﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projects.Entities.Projects
{
    public class tbl_Activity_Report : IEntityBase
    {
        public int id { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int tenant_id { get; set; }
        public string Report_No { get; set; }
        public string Date { get; set; }
        public string Main_Work_Center { get; set; }
        public string PartList_No { get; set; }
        public string Project_Code { get; set; }
        public string Activity_Code { get; set; }
        public string Activity_Description { get; set; }
        public string Work_Center { get; set; }
        public string Person_Rep { get; set; }
        public string Planned_StartDate { get; set; }
        public string Planned_CompletionDate { get; set; }
        public string Actual_StartDate { get; set; }
        public string Actual_Completiondate { get; set; }
        public string Planned_Duration { get; set; }
        public string Actual_Duration { get; set; }
        public string CompID { get; set; }
        public string Created_By { get; set; }
        public Nullable<System.DateTime> Created_On { get; set; }
        public string Modified_By { get; set; }
        public Nullable<System.DateTime> Modified_On { get; set; }
        public string Resion { get; set; }
        public string Remarks { get; set; }
        public string Part_Sl_No { get; set; }
        public string Activity_Part_No { get; set; }
        public string Status { get; set; }
        public string Ref_Doc_No { get; set; }
        

    }
}