﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projects.Entities.Projects
{
    public class tbl_Activity_Master : IEntityBase
    {
        public int id { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int tenant_id { get; set; }
        public string Activity_Code { get; set; }
        public string Activity_Description { get; set; }
        public string Activity_Group { get; set; }
        public string Activity_Document { get; set; }
        public string Activity_Type { get; set; }
        public string Activity_Predessor { get; set; }
        public string Activity_Exe_Time { get; set; }
        public string CompID { get; set; }
        public string Created_By { get; set; }
        public Nullable<System.DateTime> Created_On { get; set; }
        public string Modified_By { get; set; }
        public Nullable<System.DateTime> Modified_on { get; set; }
        public string Activity_Level { get; set; }
        public string Time_Unit { get; set; }
        public string Resp_Dept { get; set; }
        public string Applicable_Equipments { get; set; }
        public string C_Duration_Day { get; set; }
        public Nullable<System.DateTime> Duration_Time { get; set; }
        public byte[] Intermediate_Activity { get; set; }

    }
}