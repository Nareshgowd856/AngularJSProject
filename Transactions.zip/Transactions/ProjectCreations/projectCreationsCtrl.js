﻿(function (app) {
    'use strict';
    app.controller('projectCreationsCtrl', projectCreationsCtrl);
    projectCreationsCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$route', '$modal'];
    function projectCreationsCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $route, $modal) {

        $scope.projectCreation = {};
        $scope.projectMasterList = [];
        $scope.customerMasterList = [];
        $scope.sectorList = [];
        $rootScope.paymentTermsList = [];
        $scope.checkedIds = [];
        $scope.project_Code_Name = null;
        $scope.showGrid = true;
        $scope.showform = true;
        $scope.showPaymentAddBtn = false;
        $scope.project = {};
        $scope.showform = function () {
            $scope.showGrid = false;
            $scope.showform = false;
        };
        $scope.hideForm = function () {
            $scope.showGrid = true;
            $scope.showform = true;
        };
        $scope.projectClassificationList = [{ text: "Export", value: "1" }, { text: "Domestic", value: "2" }];
        $scope.ProjectCodeConstructionList = [{ text: "Code 1", value: "1" }, { text: "Code 2", value: "2" }];
        $scope.StatusList = [{ text: "Yes", value: "1" }, { text: "No", value: "2" }];

        $scope.checkNameValidation = function (project_Code) {
            if (project_Code.length > 0) {
                $scope.showPaymentAddBtn = true;
                $scope.project_Code_Name = project_Code;
                apiService.get('api/PaymentTerms/GetPaymentTermsList', null, paymentTermsLoadComplete, paymentTermsLoadFailed);
            } else {
                $scope.showPaymentAddBtn = false;
            }
        };
        function paymentTermsLoadComplete(response) {
            $scope.tempdata = response.data;
            $rootScope.paymentTermsList = response.data;
        }
        function paymentTermsLoadFailed() {
            //notificationService.displayError("Unable to Get Payment Terms Data");
        }

        $scope.removeSelectedMakers = function (smObject) {
            var index = $rootScope.makerMasterList.indexOf(smObject);
            $rootScope.makerMasterList.splice(index, 1);
        };

        $scope.addProjectMaster = function () {
            $scope.checkedIds = [];
            $scope.projectCreation.tenant_id = $rootScope.tenant.tenant_id;
            for (var i = 0; i < $rootScope.makerMasterList.length; i++) {
                $scope.checkedIds.push($rootScope.makerMasterList[i].id);
            }
            $scope.projectCreation.MakerIDsList = $scope.checkedIds;
            apiService.post('api/ProjectMaster/CreateProjectMaster', $scope.projectCreation, saveProjectMasterComplete, saveProjectMasterFailed);
        };
        function saveProjectMasterComplete(response) {
            notificationService.displaySuccess("Project Creation data saved successfully");
            $scope.showGrid = true;
            $scope.showform = true;
            $scope.projectCreation = {};
            LoadProjectMasterList();    
        }
        function saveProjectMasterFailed() {
            notificationService.displayError("Unable to save Project Creation");
        }

        LoadProjectMasterList();
        function LoadProjectMasterList() {
            apiService.get('api/ProjectMaster/GetProjectMasterList', null, projectMasterLoadComplete, projectMasterLoadFailed);
            //apiService.get('api/MakerMaster/GetMakerMasterList', null, makerMasterLoadComplete, makerMasterLoadFailed);
            apiService.get('api/ProjectMaster/GetProjectCommercialList', null, projectCommercialLoadComplete, projectCommercialLoadFailed);
            apiService.get('api/ProjectMaster/GetCustomerMasterList', null, customerMasterLoadComplete, customerMasterLoadFailed);
            apiService.get('api/ProjectMaster/GetCurrencyList', null, currencyLoadComplete, currrencyLoadFailed);
            apiService.get('api/Sector/GetSectorList', null, sectorLoadComplete, sectorLoadFailed);
        };
        function sectorLoadComplete(response) {
            $scope.sectorList = response.data;
        }
        function sectorLoadFailed() {
            notificationService.displayError("Unable to  Get Sector Data");
        }

        function currencyLoadComplete(response) {
            $scope.currencyList = response.data;
        }
        function currrencyLoadFailed() {
            notificationService.displayError("Unable to  Get Project Customers Data");
        }

        function customerMasterLoadComplete(response) {
            $scope.customerMasterList = response.data;
        }
        function customerMasterLoadFailed() {
            notificationService.displayError("Unable to  Get Project Customers Data");
        }
        function projectCommercialLoadComplete(response) {
            $scope.projectCommercialList = response.data;
        }
        function projectCommercialLoadFailed() {
            notificationService.displayError("Unable to  Get Project Commercial Data");
        }
        function projectMasterLoadComplete(response) {
            $scope.projectMasterList = response.data;
        }
        function projectMasterLoadFailed() {
            notificationService.displayError("Unable to Get Project Master Data");
        }
        //function makerMasterLoadComplete(response) {
        //    $rootScope.makerMasterList = response.data;
        //}
        //function makerMasterLoadFailed() {
        //    notificationService.displayError("Unable to Get Maker Master Data");
        //}
        //$scope.editingData = {};

        //for (var i = 0, length = $scope.tabelsData.length; i < length; i++) {
        //    $scope.editingData[$scope.tabelsData[i].id] = false;
        //}

        //$scope.modify = function (pm) {
        //    $scope.editingData[pm.id] = true;
        //};


        //$scope.update = function (pm) {
        //    $scope.editingData[pm.id] = false;
        //};


        $scope.editCall = function (rowform) {
            if ($(".checkVisible").is(":visible")) {
                rowform.$cancel();
            }
            else {
                rowform.$show();
            }
        };
        $scope.updateUser = function (data, id) {
            angular.extend(data, { id: id });
            $scope.project.id = data.id;
            $scope.project.Project_Code = data.pmProjectCode;
            $scope.project.Project_Name = data.pmProjectName;
            $scope.project.Project_Client = data.pmProjectClient;
            apiService.post('api/ProjectMaster/UpdateProjectMaster', $scope.project, UpdateUserComplete, UpdateUserFailed);

        };
        function UpdateUserComplete() {
            notificationService.displaySuccess(" Updated Successfully");
            LoadProjectMasterList();
        }
        function UpdateUserFailed() {
            notificationService.displayError(" Update Failed !");
        }
        $scope.DeleteProjectMaster = function (pm) {
            alertify.confirm("Delete", "Are You Sure to Delete ", function () {
                apiService.post('api/ProjectMaster/DeleteProjectMaster/' + pm.id, null, DeleteUserComplete, DeleteUserFailed);
            },
                function () { }).set('reverseButtons', false);
        }
        function DeleteUserComplete(response) {
            notificationService.displaySuccess('Deleted Successfully.');
            LoadProjectMasterList();
        }
        function DeleteUserFailed(response) {
            notificationService.displayError(' Deleted  Failed !');
        }

        $scope.makersPopup1 = function () {
            var modalInstance = $modal.open({
                templateUrl: 'Scripts/Master/Makers/makersPopup.html',
                controller: 'makersPopupCtrl',
                scope: $scope,
            });
        };
        $scope.makersPopup2 = function () {
            var modalInstance = $modal.open({
                templateUrl: 'Scripts/Master/Makers/makersPopup.html',
                controller: 'makersPopupCtrl',
                scope: $scope,
            });
        };

        $scope.paymentPopup1 = function () {
            var modalInstance = $modal.open({
                templateUrl: 'Scripts/Transactions/ProjectCreations/PaymentTerms/paymentPopup.html',
                controller: 'paymentPopupCtrl',
                scope: $scope,
                resolve: {
                    projectCode: function () { return $scope.project_Code_Name }
                }
            });
        };

        $scope.paymentPopup2 = function () {
            var modalInstance = $modal.open({
                templateUrl: 'Scripts/Transactions/ProjectCreations/PaymentTerms/paymentPopup.html',
                controller: 'paymentPopupCtrl',
                scope: $scope,
                resolve: {
                    projectCode: function () { return $scope.project_Code_Name }
                }
            });
        };

        $scope.selectMakerPopUp = function () {
            var modalInstance = $modal.open({
                templateUrl: 'Scripts/Master/Makers/makersPopup.html',
                controller: 'makersPopupCtrl',
                scope: $scope
            });
        };



    }
})(angular.module('common.core'));