﻿(function (app) {
    'use strict';
    app.controller('projectCreationsCtrl', projectCreationsCtrl);
    projectCreationsCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$route', '$modal'];
    function projectCreationsCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $route, $modal) {

        $scope.projectMasterList = [];
        $rootScope.makerMasterList = [];
        $rootScope.paymentTermsList = [];
        $scope.showGrid = true;
        $scope.showform = true;

        $scope.showform = function () {
            $scope.showGrid = false;
            $scope.showform = false;
        };
        $scope.hideForm = function () {
            $route.reload();
            $scope.showGrid = true;
            $scope.showform = true;
        };

        LoadProjectMasterList();
        function LoadProjectMasterList() {
            apiService.get('api/ProjectMaster/GetProjectMasterList', null, projectMasterLoadComplete, projectMasterLoadFailed);
            apiService.get('api/MakerMaster/GetMakerMasterList', null, makerMasterLoadComplete, makerMasterLoadFailed);
            apiService.get('api/PaymentTerms/GetPaymentTermsList', null, paymentTermsLoadComplete, paymentTermsLoadFailed);

        };
        function projectMasterLoadComplete(response) {
            $scope.projectMasterList = response.data;
        }
        function projectMasterLoadFailed() {
            notificationService.displayError("Unable to Get Project Master Data");
        }
        function makerMasterLoadComplete(response) {
            $rootScope.makerMasterList = response.data;
        }
        function makerMasterLoadFailed() {
            notificationService.displayError("Unable to Get Maker Master Data");
        }

        $scope.makersPopup1 = function () {
            var modalInstance = $modal.open({
                templateUrl: 'Scripts/Master/Makers/makersPopup.html',
                controller: 'makersPopupCtrl',
                scope: $scope,
            });
        };
        $scope.makersPopup2 = function () {
            var modalInstance = $modal.open({
                templateUrl: 'Scripts/Master/Makers/makersPopup.html',
                controller: 'makersPopupCtrl',
                scope: $scope,
            });
        };
        function paymentTermsLoadComplete(response) {
            $rootScope.paymentTermsList = response.data;
            console.log($rootScope.paymentTermsList = response.data);
        }
        function paymentTermsLoadFailed() {
            notificationService.displayError("Unable to Get Payment Terms Data");
        }

        $scope.paymentPopup1 = function () {
            var modalInstance = $modal.open({
                templateUrl: 'Scripts/Transactions/ProjectCreations/PaymentTerms/paymentPopup.html',
                controller: 'paymentPopupCtrl',
                scope: $scope,
            });
        };
        $scope.paymentPopup2 = function () {
            var modalInstance = $modal.open({
                templateUrl: 'Scripts/Transactions/ProjectCreations/PaymentTerms/paymentPopup.html',
                controller: 'paymentPopupCtrl',
                scope: $scope,
            });
        };



    }
})(angular.module('common.core'));