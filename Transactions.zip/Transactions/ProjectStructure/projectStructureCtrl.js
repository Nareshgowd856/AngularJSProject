﻿
(function (app) {
    'use strict';
    app.controller('projectStructureCtrl', projectStructureCtrl);
    projectStructureCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function projectStructureCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal, ) {


        $scope.aPGStructureList = [];
        $scope.projectMasterList = [];
        $scope.showGrid = true;
        $scope.showform = true;

        $scope.showform = function () {
            $scope.showGrid = false;
            $scope.showform = false;
        };
        $scope.hideForm = function () {
            $route.reload();
            $scope.showGrid = true;
            $scope.showform = true;
        };

        $scope.showPartListItemform = function () {
            $scope.showForm = true;
            $scope.showGrid = true;
        };

        $scope.closeProjectStructureMainmodal = function closeProjectStructureMainmodal() {
            $modalInstance.close();
        };


       

        LoadprojectStructureMainList();
        function LoadprojectStructureMainList() {
            apiService.get('api/ProjectStructure/GetProjectStructureMainList', null, projectStructureLoadComplete, projectStructureLoadFailed);
        };
        function projectStructureLoadComplete(response) {
            $scope.projectStructureMainList = response.data;
        }

        function projectStructureLoadFailed(response) {
            notificationService.displayError("Unable to Get Project Structure Data");
        }


    }

})(angular.module('common.core'));