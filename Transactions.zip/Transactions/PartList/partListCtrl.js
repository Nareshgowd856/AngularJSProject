﻿(function (app) {
    'use strict';
    app.controller('partListCtrl', partListCtrl);
    partListCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function partListCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal) {

        $scope.partListItem = {};
        $scope.PartListItemList = [];
        $scope.showform = true;
        $scope.showGrid = true;

        $scope.showPartListItemform = function () {
            $scope.showForm = true;
            $scope.showGrid = true;
        };


        $scope.showform = function () {
            $scope.showGrid = false;
            $scope.showform = false;
        };
        $scope.hideForm = function () {
            $scope.showGrid = true;
            $scope.showform = true;
        };
        $scope.hidePartListItemform = function () {
            $scope.partListItem = {};
            $scope.showForm = false;
            $scope.showGrid = true;
        };

        LoadPartListItemList();
        function LoadPartListItemList() {
            apiService.get('api/PartListItem/GetPartListItemList', null, partListItemLoadComplete, partListItemLoadFailed);
        };
        function partListItemLoadComplete(response) {
            $scope.PartListItemList = response.data;
        }
        function partListItemLoadFailed() {
            notificationService.displayError("Unable to Get Project Master Data");
        }

        //$scope.saveMakers = function saveMakers() {
        //    apiService.post('api/MakerMaster/CreateMakers', $scope.makerMaster, saveMakersComplete, saveMakersFailed);
        //};
        //function saveMakersComplete(response) {
        //    notificationService.displaySuccess("Maker created Successfully");
        //    $scope.makerMaster = {};
        //    LoadMakerMasterList();
        //}
        //function saveMakersFailed() {
        //    notificationService.displayError("Unable to Create Maker");
        //    $scope.showForm = true;
        //    $scope.showGrid = false;
        //}



    }
})(angular.module('common.core'));