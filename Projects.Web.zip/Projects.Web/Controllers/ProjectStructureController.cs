﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
    [RoutePrefix("api/ProjectStructure")]
    public class ProjectStructureController: ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_project_structure_main> _projectStructureMainRepository;

        public ProjectStructureController(IEntityBaseRepository<tbl_project_structure_main> projectStructureMainRepository,
            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _projectStructureMainRepository = projectStructureMainRepository;
        }


        [HttpGet]
        [Route("GetProjectStructureMainList")]
        public HttpResponseMessage GetProjectStructureMainList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var projectStructureMainList = _projectStructureMainRepository.GetAll().Distinct();
                IEnumerable<ProjectStructureMainViewModel> projectStructureMainVm = Mapper.Map<IEnumerable<tbl_project_structure_main>, IEnumerable<ProjectStructureMainViewModel>>(projectStructureMainList);
                response = request.CreateResponse<IEnumerable<ProjectStructureMainViewModel>>(HttpStatusCode.OK, projectStructureMainVm);
                return response;
            });
        }

        //[HttpPost]
        //[Route("CreatePro")]
        //public HttpResponseMessage CreateMakers(HttpRequestMessage request, MakerMasterViewModel maker)
        //{
        //    return CreateHttpResponse(request, () =>
        //    {
        //        HttpResponseMessage response = null;
        //        if (!ModelState.IsValid)
        //        {
        //            response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
        //        }
        //        else
        //        {
        //            tbl_Maker_Master newMakerMaster = new tbl_Maker_Master();
        //            newMakerMaster.Maker_No = maker.Maker_No;
        //            newMakerMaster.Maker_Description = maker.Maker_Description;
        //            newMakerMaster.tenant_id = maker.tenant_id;
        //            newMakerMaster.CompID = maker.CompID;
        //            newMakerMaster.Modified_On = null;
        //            newMakerMaster.Modified_By = null;
        //            newMakerMaster.Created_By = maker.Created_By;
        //            newMakerMaster.Created_On = DateTime.Now;
        //            _makerMasterRepository.Add(newMakerMaster);
        //            _unitOfWork.Commit();

        //            response = request.CreateResponse<MakerMasterViewModel>(HttpStatusCode.Created, maker);
        //        }

        //        return response;
        //    });
        //}



    }   
}