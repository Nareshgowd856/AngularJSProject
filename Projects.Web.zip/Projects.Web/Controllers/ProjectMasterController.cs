﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
    [RoutePrefix("api/ProjectMaster")]
    public class ProjectMasterController : ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_project_master> _projectMasterRepository;
        public readonly IEntityBaseRepository<tbl_project_master_child> _projectMasterChildRepository;

        public ProjectMasterController(IEntityBaseRepository<tbl_project_master> projectMasterRepository,
            IEntityBaseRepository<tbl_project_master_child> projectMasterChildRepository,
            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _projectMasterRepository = projectMasterRepository;
            _projectMasterChildRepository = projectMasterChildRepository;
        }

        [HttpGet]
        [Route("GetProjectMasterList")]
        public HttpResponseMessage GetProjectMasterList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var projectMasterList = _projectMasterRepository.GetAll();
                IEnumerable<ProjectMasterViewModel> projectMastervm = Mapper.Map<IEnumerable<tbl_project_master>, IEnumerable<ProjectMasterViewModel>>(projectMasterList);
                response = request.CreateResponse<IEnumerable<ProjectMasterViewModel>>(HttpStatusCode.OK, projectMastervm);
                return response;
            });
        }

        [HttpPost]
        [Route("CreateProjectMaster")]
        public HttpResponseMessage CreateProjectMaster(HttpRequestMessage request, ProjectMasterViewModel project)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    tbl_project_master newProjectMaster = new tbl_project_master();
                    newProjectMaster.Project_Code = project.Project_Code;
                    newProjectMaster.Project_Description = project.Project_Description;
                    newProjectMaster.Project_Client = project.Project_Client;
                    
                    newProjectMaster.tenant_id = project.tenant_id;
                    newProjectMaster.CompID = project.CompID;
                    newProjectMaster.Modified_On = null;
                    newProjectMaster.Modified_By = null;
                    newProjectMaster.Created_By = project.Created_By;
                    newProjectMaster.Created_On = DateTime.Now;
                    _projectMasterRepository.Add(newProjectMaster);
                    _unitOfWork.Commit();

                    response = request.CreateResponse<ProjectMasterViewModel>(HttpStatusCode.Created, project);
                }

                return response;
            });
        }






        [HttpGet]
        [Route("GetProjectMasterChildList")]
        public HttpResponseMessage GetProjectMasterChildList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var projectMasterChildList = _projectMasterChildRepository.GetAll();
                IEnumerable<ProjectMasterChildViewModel> projectMasterChildvm = Mapper.Map<IEnumerable<tbl_project_master_child>, IEnumerable<ProjectMasterChildViewModel>>(projectMasterChildList);
                response = request.CreateResponse<IEnumerable<ProjectMasterChildViewModel>>(HttpStatusCode.OK, projectMasterChildvm);
                return response;
            });
        }
        [Route("UpdateProjectMaster")]
        [HttpPost]
        public HttpResponseMessage UpdateProjectMaster(HttpRequestMessage request, ProjectMasterViewModel project)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingProject = _projectMasterRepository.GetSingle(project.id);
                    existingProject.Project_Code = project.Project_Code;
                    existingProject.Project_Name = project.Project_Name;
                    existingProject.Project_Client = project.Project_Client ;
                    existingProject.Project_DeliveryDate = DateTime.Now;
                    existingProject.Modified_On = DateTime.Now;
                    _projectMasterRepository.Edit(existingProject);
                    _unitOfWork.Commit();
                    response = request.CreateResponse(HttpStatusCode.OK);

                }
                return response;
            });

        }
        [HttpPost]
        [Route("DeleteProjectMaster/{id:int}")]
        public HttpResponseMessage DeleteProjectMaster(HttpRequestMessage request, int id)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    var existingProject = _projectMasterRepository.GetSingle(id);
                    if (existingProject != null)
                    {
                        _projectMasterRepository.Delete(existingProject);
                        _unitOfWork.Commit();
                        response = request.CreateResponse(HttpStatusCode.OK);
                    }
                }
                return response;
            });
        }

    }
}