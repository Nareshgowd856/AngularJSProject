﻿using AutoMapper;
using Projects.Data.Infrastructure;
using Projects.Data.Repositories;
using Projects.Entities.Membership;
using Projects.Entities.Projects;
using Projects.Web.Infrastructure.Core;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Projects.Web.Controllers
{
    [RoutePrefix("api/PartListItem")]
    public class PartListItemController : ApiControllerBase
    {
        public readonly IEntityBaseRepository<tbl_part_list_item> _partListItemRepository;

        public PartListItemController(IEntityBaseRepository<tbl_part_list_item> partListItemRepository,
            IEntityBaseRepository<tbl_error> _errorsRepository,
            IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _partListItemRepository = partListItemRepository;
        }


        //        [HttpGet]
        //        [Route("GetPartListItemList")]
        //        public HttpResponseMessage GetPartListItemList(HttpRequestMessage request)
        //        {
        //            return CreateHttpResponse(request, () =>
        //            {
        //                HttpResponseMessage response = null;
        //                var partListItemList = _partListItemRepository.GetAll();
        //                IEnumerable<PartListItemViewModel> PartListItemvm = Mapper.Map<IEnumerable<tbl_part_list_item>, IEnumerable<PartListItemViewModel>>(partListItemList);
        //                response = request.CreateResponse<IEnumerable<PartListItemViewModel>>(HttpStatusCode.OK, PartListItemvm);
        //                return response;
        //            });

        //        }

        //[HttpPost]
        //[Route("CreatePartListItem")]
        //public HttpResponseMessage CreatePartListItem(HttpRequestMessage request, PartListItemViewModel partListItem)
        //{
        //    return CreateHttpResponse(request, () =>
        //    {
        //        HttpResponseMessage response = null;
        //        if (!ModelState.IsValid)
        //        {
        //            response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
        //        }
        //        else
        //        {
        //            tbl_part_list_item newPartListItemForm = new tbl_part_list_item();
        //            newPartListItemForm.tenant_id = partListItem.tenant_id;
        //            newPartListItemForm.Project_Code = partListItem.Project_Code;
        //            newPartListItemForm.Activity_Part_No = partListItem.Activity_Part_No;
        //            newPartListItemForm.Apg_Name = partListItem.Apg_Name;
        //            newPartListItemForm.Maker_No = partListItem.Maker_No;
        //            newPartListItemForm.Apg_No = partListItem.Apg_No;
        //            newPartListItemForm.Drawing_NO = partListItem.Drawing_NO;
        //            newPartListItemForm.CompId = partListItem.CompId;
        //            newPartListItemForm.Main_Drwaing_No = partListItem.Main_Drwaing_No;
        //            newPartListItemForm.Material_Shape_Finished = partListItem.Material_Shape_Finished;
        //            newPartListItemForm.Material_Shape_RM = partListItem.Material_Shape_RM;
        //            newPartListItemForm.OD = partListItem.OD;
        //            newPartListItemForm.Partlist_No = partListItem.Partlist_No;
        //            newPartListItemForm.Part_Dai_Finished = partListItem.Part_Dai_Finished;
        //            newPartListItemForm.Part_Desription = partListItem.Part_Desription;
        //            newPartListItemForm.Part_Dia = partListItem.Part_Dia;
        //            newPartListItemForm.Part_D_Wt = partListItem.Part_D_Wt;
        //            newPartListItemForm.Part_Engg_Code = partListItem.Part_Engg_Code;
        //            newPartListItemForm.Part_EN_Cert = partListItem.Part_EN_Cert;
        //            newPartListItemForm.Part_Equipment_Name = partListItem.Part_Equipment_Name;
        //            newPartListItemForm.Part_Fg_wt = partListItem.Part_Fg_wt;
        //            newPartListItemForm.Part_Group = partListItem.Part_Group;
        //            newPartListItemForm.Part_IBR_Cert = partListItem.Part_IBR_Cert;
        //            newPartListItemForm.Part_Length = partListItem.Part_Length;
        //            newPartListItemForm.Part_Length_Finished = partListItem.Part_Length_Finished;
        //            newPartListItemForm.Part_Mtc_Cert = partListItem.Part_Mtc_Cert;
        //            newPartListItemForm.Part_Name = partListItem.Part_Name;
        //            newPartListItemForm.Part_OD_Finished = partListItem.Part_OD_Finished;
        //            newPartListItemForm.Part_RM_Code = partListItem.Part_RM_Code;
        //            newPartListItemForm.Part_Rm_Density = partListItem.Part_Rm_Density;
        //            newPartListItemForm.Part_Rm_Type = partListItem.Part_Rm_Type;
        //            newPartListItemForm.Part_Rm_Wt = partListItem.Part_Rm_Wt;
        //            newPartListItemForm.Part_Rm_WThick = partListItem.Part_Rm_WThick;
        //            newPartListItemForm.Part_Sl_No = partListItem.Part_Sl_No;
        //            newPartListItemForm.Part_Spec_Id = partListItem.Part_Spec_Id;
        //            newPartListItemForm.Part_Spl_Notes = partListItem.Part_Spl_Notes;
        //            newPartListItemForm.Part_UOM = partListItem.Part_UOM;
        //            newPartListItemForm.Part_variant = partListItem.Part_variant;
        //            newPartListItemForm.Part_W2 = partListItem.Part_W2;
        //            newPartListItemForm.Part_W2_Finished = partListItem.Part_W2_Finished;
        //            newPartListItemForm.Part_Wt = partListItem.Part_Wt;
        //            newPartListItemForm.Part_WThick_Finished = partListItem.Part_WThick_Finished;
        //            newPartListItemForm.PTS_NO = partListItem.PTS_NO;
        //            newPartListItemForm.Qty = partListItem.Qty;
        //            newPartListItemForm.Status = partListItem.Status;
        //            newPartListItemForm.Version_Change = partListItem.Version_Change;
        //            newPartListItemForm.Version_Date = partListItem.Version_Date;
        //            newPartListItemForm.Version_No = partListItem.Version_No;
        //            newPartListItemForm.Modified_On = null;
        //            newPartListItemForm.Modified_By = null;
        //            newPartListItemForm.Created_By = partListItem.Created_By;
        //            newPartListItemForm.Created_On = DateTime.Now;
        //            _partListItemRepository.Add(newPartListItemForm);
        //            _unitOfWork.Commit();

        //            response = request.CreateResponse<PartListItemViewModel>(HttpStatusCode.Created, partListItem);
        //        }

        //        return response;
        //    });
        //}



    }
}