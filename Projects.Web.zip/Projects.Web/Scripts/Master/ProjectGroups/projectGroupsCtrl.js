﻿(function (app) {
    'use strict';
    app.controller('projectGroupsCtrl', projectGroupsCtrl);
    projectGroupsCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function projectGroupsCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal) {

        $scope.aPGMasterList = [];
        $scope.aPGMaster = {};
        $scope.showform = false;
        $scope.showGrid = true;
        $scope.aPGMaster = {};

        $scope.showAPGform = function () {
            $scope.showForm = true;
            $scope.showGrid = false;
        };
        $scope.hideAPGform = function () {
            $scope.aPGMaster = {};
            $scope.showForm = false;
            $scope.showGrid = true;
        };

        LoadAPGMasterList();
        function LoadAPGMasterList() {
            apiService.get('api/APGMaster/GetAPGMasterList', null, aPGMasterLoadComplete, aPGMasterLoadFailed);
        };
        function aPGMasterLoadComplete(response) {
            $scope.aPGMasterList = response.data;
            if ($scope.aPGMasterList.length > 0) {
                $scope.showForm = false;
                $scope.showGrid = true;
            }
        }
        function aPGMasterLoadFailed(response) {
            notificationService.displayError("Unable to Get APG Master Data");
        }

        $scope.saveAPG = function saveAPG() {
            apiService.post('api/APGMaster/CreateAPG', $scope.aPGMaster, saveAPGComplete, saveAPGFailed);
        };
        function saveAPGComplete(response) {
            notificationService.displaySuccess("APG created Successfully");
            $scope.showForm = false;
            $scope.showGrid = true;
            $scope.aPGMaster = {};
            LoadAPGMasterList();
        }
        function saveAPGFailed() {
            notificationService.displayError("Unable to APG Maker");
            $scope.showForm = true;
            $scope.showGrid = false;
        }
        $scope.editCall = function (rowform) {
            if ($(".checkVisible").is(":visible")) {
                rowform.$cancel();
            }
            else {
                rowform.$show();
            }
        };

        $scope.updateUser = function (data, id) {
            angular.extend(data, { id: id });
            $scope.aPGMaster.id = data.id;
            $scope.aPGMaster.APG_No = data.apgno;
            $scope.aPGMaster.APG_Description = data.apgDescription;
            apiService.post('api/APGMaster/UpdateAPG', $scope.aPGMaster, UpdateUserComplete, UpdateUserFailed);

        };
        function UpdateUserComplete() {
            notificationService.displaySuccess("APG Updated Successfully");
            LoadAPGMasterList();
        }
        function UpdateUserFailed() {
            notificationService.displayError(" APG Update Failed !");
        }


        $scope.DeleteAPG = function (apg) {
            alertify.confirm("Delete", "Are You Sure to Delete APG", function () {
                apiService.post('api/APGMaster/DeleteAPG/' + apg.id, null, DeleteUserComplete, DeleteUserFailed);
            },
                function () { }).set('reverseButtons', false);
        }
        function DeleteUserComplete(response) {
            notificationService.displaySuccess('Deleted Successfully.');
            LoadAPGMasterList();
        }
        function DeleteUserFailed(response) {
            notificationService.displayError(' Deleted  Failed !');
        }

    }


    
})(angular.module('common.core'));