﻿(function (app) {
    'use strict';
    app.controller('itemMasterCtrl', itemMasterCtrl);
    itemMasterCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function itemMasterCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal) {
        $scope.partListItemList = [];
        $scope.partListItem = {};
        $scope.showform = true;
        $scope.showGrid = true;

        $scope.showPartListItemform = function () {
            $scope.showForm = true;
            $scope.showGrid = true;
        };

    }
})(angular.module('common.core'));