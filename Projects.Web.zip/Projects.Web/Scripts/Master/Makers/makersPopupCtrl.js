﻿(function (app) {
    'use strict';
    app.controller('makersPopupCtrl', makersPopupCtrl);
    makersPopupCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal', '$modalInstance'];
    function makersPopupCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal, $modalInstance) {

        $scope.makerMaster = {};


        $scope.closeMakerMastermodal = function closeMakerMastermodal() {
            $modalInstance.close();
        };

        $scope.saveMakers = function saveMakers() {
            apiService.post('api/MakerMaster/CreateMakers', $scope.makerMaster, saveMakersComplete, saveMakersFailed);
        };
        function saveMakersComplete(response) {
            notificationService.displaySuccess("Maker created Successfully");
            $scope.makerMaster = {};
            apiService.get('api/MakerMaster/GetMakerMasterList', null, makerMasterLoadComplete, makerMasterLoadFailed);
            $modalInstance.close();
        }
        function saveMakersFailed() {
            notificationService.displayError("Unable to Create Maker");
        }
        function makerMasterLoadComplete(response) {
            $rootScope.makerMasterList = response.data;
            $modalInstance.close();
        }
        function makerMasterLoadFailed() {
            notificationService.displayError("Unable to Get Maker Master Data");
            $modalInstance.close();
        }


    }
})(angular.module('common.core'));