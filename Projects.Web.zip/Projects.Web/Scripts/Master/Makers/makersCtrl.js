﻿(function (app) {
    'use strict';
    app.controller('makersCtrl', makersCtrl);
    makersCtrl.$inject = ['$scope', 'apiService', 'membershipService', 'notificationService', '$rootScope', '$location', '$filter', '$modal'];
    function makersCtrl($scope, apiService, membershipService, notificationService, $rootScope, $location, $filter, $modal) {

        $scope.makerMasterList = [];
        $scope.makerMaster = {};
        $scope.showform = false;
        $scope.showGrid = true;
        $scope.maker = {};

        $scope.showMakersform = function () {
            $scope.showForm = true;
            $scope.showGrid = false;
        };
        $scope.hideMakersform = function () {
            $scope.makerMaster = {};
            $scope.showForm = false;
            $scope.showGrid = true;
        };

        LoadMakerMasterList();
        function LoadMakerMasterList() {
            apiService.get('api/MakerMaster/GetMakerMasterList', null, makerMasterLoadComplete, makerMasterLoadFailed);
        };
        function makerMasterLoadComplete(response) {
            $scope.makerMasterList = response.data;
            if ($scope.makerMasterList.length > 0) {
                $scope.showForm = false;
                $scope.showGrid = true;
            }
        }
        function makerMasterLoadFailed(response) {
            notificationService.displayError("Unable to Get Maker Master Data");
        }

        $scope.saveMakers = function saveMakers() {
            apiService.post('api/MakerMaster/CreateMakers', $scope.makerMaster, saveMakersComplete, saveMakersFailed);
        };
        function saveMakersComplete(response) {
            notificationService.displaySuccess("Maker created Successfully");
            $scope.makerMaster = {};
            LoadMakerMasterList();
        }
        function saveMakersFailed() {
            notificationService.displayError("Unable to Create Maker");
            $scope.showForm = true;
            $scope.showGrid = false;
        }
        $scope.editCall = function (rowform) {
            if ($(".checkVisible").is(":visible")) {
                rowform.$cancel();
            }
            else {
                rowform.$show();
            }
        };

        $scope.updateUser = function (data, id) {
            angular.extend(data, { id: id });
            $scope.maker.id = data.id;
            $scope.maker.Maker_No = data.mmUserName;
            $scope.maker.Maker_Description = data.mmDescription;
            apiService.post('api/MakerMaster/UpdateMaker', $scope.maker, UpdateUserComplete, UpdateUserFailed);

        };
        function UpdateUserComplete() {
            notificationService.displaySuccess("Maker Updated Successfully");
            LoadMakerMasterList();
        }
        function UpdateUserFailed() {
            notificationService.displayError(" Maker Update Failed !");
        }
        $scope.DeleteMaker = function (mm) {
            alertify.confirm("Delete", "Are You Sure to Delete Maker", function () {
                apiService.post('api/MakerMaster/DeleteMaker/' + mm.id, null, DeleteUserComplete, DeleteUserFailed);
            },
                function () { }).set('reverseButtons', false);
        }
        function DeleteUserComplete(response) {
            notificationService.displaySuccess('Deleted Successfully.');
            LoadMakerMasterList();
        }
        function DeleteUserFailed(response) {
            notificationService.displayError(' Deleted  Failed !');
        }

    }
})(angular.module('common.core'));