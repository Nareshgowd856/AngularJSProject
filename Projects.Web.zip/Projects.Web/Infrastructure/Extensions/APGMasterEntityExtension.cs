﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class APGMasterEntityExtension
    {
        public static void AddAPGMaster(this tbl_APG_Master apgMaster, APGMasterViewModel apgMasterVm)
        {
            apgMaster.tenant_id = apgMasterVm.tenant_id;
            apgMaster.APG_ApplicableTo = apgMasterVm.APG_ApplicableTo;
            apgMaster.APG_Description = apgMasterVm.APG_Description;
            apgMaster.APG_No = apgMasterVm.APG_No;
            apgMaster.CompID = apgMasterVm.CompID;
            apgMaster.Created_On = DateTime.Now;
            apgMaster.Created_By = apgMasterVm.Created_By;
            apgMaster.Modified_On = DateTime.Now;
            apgMaster.Modified_By = apgMasterVm.Modified_By;
        }
    }
}