﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class PartListItemEntityExtension
    { 
    public static void AddPartListItem(this tbl_part_list_item PartListItem, PartListItemViewModel PartListItemvm)
    {
            PartListItem.tenant_id = PartListItemvm.tenant_id;
            PartListItem.Project_Code = PartListItemvm.Project_Code;
            PartListItem.Activity_Part_No = PartListItemvm.Activity_Part_No;
            PartListItem.Apg_Name = PartListItemvm.Apg_Name;
            PartListItem.Maker_No = PartListItemvm.Maker_No;
            PartListItem.Apg_No = PartListItemvm.Apg_No;
            PartListItem.Drawing_NO = PartListItemvm.Drawing_NO;
            PartListItem.CompId = PartListItemvm.CompId;
            PartListItem.Main_Drwaing_No = PartListItemvm.Main_Drwaing_No;
            PartListItem.Material_Shape_Finished = PartListItemvm.Material_Shape_Finished;
            PartListItem.Material_Shape_RM = PartListItemvm.Material_Shape_RM;
            PartListItem.OD = PartListItemvm.OD;
            PartListItem.Partlist_No = PartListItemvm.Partlist_No;
            PartListItem.Part_Dai_Finished = PartListItemvm.Part_Dai_Finished;
            PartListItem.Part_Desription = PartListItemvm.Part_Desription;
            PartListItem.Part_Dia = PartListItemvm.Part_Dia;
            PartListItem.Part_D_Wt = PartListItemvm.Part_D_Wt;
            PartListItem.Part_Engg_Code = PartListItemvm.Part_Engg_Code;
            PartListItem.Part_EN_Cert = PartListItemvm.Part_EN_Cert;
            PartListItem.Part_Equipment_Name = PartListItemvm.Part_Equipment_Name;
            PartListItem.Part_Fg_wt = PartListItemvm.Part_Fg_wt;
            PartListItem.Part_Group = PartListItemvm.Part_Group;
            PartListItem.Part_IBR_Cert = PartListItemvm.Part_IBR_Cert;
            PartListItem.Part_Length = PartListItemvm.Part_Length;
            PartListItem.Part_Length_Finished = PartListItemvm.Part_Length_Finished;
            PartListItem.Part_Mtc_Cert = PartListItemvm.Part_Mtc_Cert;
            PartListItem.Part_Name = PartListItemvm.Part_Name;
            PartListItem.Part_OD_Finished = PartListItemvm.Part_OD_Finished;
            PartListItem.Part_RM_Code = PartListItemvm.Part_RM_Code;
            PartListItem.Part_Rm_Density = PartListItemvm.Part_Rm_Density;
            PartListItem.Part_Rm_Type = PartListItemvm.Part_Rm_Type;
            PartListItem.Part_Rm_Wt = PartListItemvm.Part_Rm_Wt;
            PartListItem.Part_Rm_WThick = PartListItemvm.Part_Rm_WThick;
            PartListItem.Part_Sl_No = PartListItemvm.Part_Sl_No;
            PartListItem.Part_Spec_Id = PartListItemvm.Part_Spec_Id;
            PartListItem.Part_Spl_Notes = PartListItemvm.Part_Spl_Notes;
            PartListItem.Part_UOM = PartListItemvm.Part_UOM;
            PartListItem.Part_variant = PartListItemvm.Part_variant;
            PartListItem.Part_W2 = PartListItemvm.Part_W2;
            PartListItem.Part_W2_Finished = PartListItemvm.Part_W2_Finished;
            PartListItem.Part_Wt = PartListItemvm.Part_Wt;
            PartListItem.Part_WThick_Finished = PartListItemvm.Part_WThick_Finished;
            PartListItem.PTS_NO = PartListItemvm.PTS_NO;
            PartListItem.Qty = PartListItemvm.Qty;
            PartListItem.Status = PartListItemvm.Status;
            PartListItem.Version_Change = PartListItemvm.Version_Change;
            PartListItem.Version_Date = PartListItemvm.Version_Date;
            PartListItem.Version_No = PartListItemvm.Version_No;
            PartListItem.Created_On = DateTime.Now;
            PartListItem.Created_By = PartListItemvm.Created_By;
            PartListItem.Modified_On = DateTime.Now;
            PartListItem.Modified_By = PartListItemvm.Modified_By;
    }
}
}