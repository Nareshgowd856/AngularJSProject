﻿using Projects.Entities.Projects;
using Projects.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projects.Web.Infrastructure.Extensions
{
    public static class ItemRMCodesEntityExtension
    {
        public static void AddItemRMCodes(this tbl_Item_RM_Codes itemRMCodes, ItemRMCodesViewModel itemRMCodesVm)
        {
            itemRMCodes.tenant_id = itemRMCodesVm.tenant_id;
            itemRMCodes.Item_Code = itemRMCodesVm.Item_Code;
            itemRMCodes.Item_Description = itemRMCodesVm.Item_Description;
            itemRMCodes.Item_Dia = itemRMCodesVm.Item_Dia;
            itemRMCodes.Item_LongText = itemRMCodesVm.Item_LongText;
            itemRMCodes.CompID = itemRMCodesVm.CompID;
            itemRMCodes.Item_SchNo = itemRMCodesVm.Item_SchNo;
            itemRMCodes.Item_Spec = itemRMCodesVm.Item_Spec;
            itemRMCodes.Item_UWt = itemRMCodesVm.Item_UWt;
            itemRMCodes.Created_On = DateTime.Now;
            itemRMCodes.Created_By = itemRMCodesVm.Created_By;
            itemRMCodes.Modified_On = DateTime.Now;
            itemRMCodes.Modified_By = itemRMCodesVm.Modified_By;
            itemRMCodes.Item_WT = itemRMCodesVm.Item_WT;
            itemRMCodes.Part_List_No = itemRMCodesVm.Part_List_No;
            
        }
    }
}